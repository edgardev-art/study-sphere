import React, { useState } from 'react';
import {
  X,
  History,
  RotateCcw,
  Clock,
  FileText,
  Sparkles,
  Check,
  Calendar,
  Camera,
  ArrowRight,
  AlertCircle,
} from 'lucide-react';
import { Note, NoteVersion } from '../../types';
import { useApp } from '../../context/AppContext';

interface VersionHistoryModalProps {
  note: Note;
  isOpen: boolean;
  onClose: () => void;
}

export const VersionHistoryModal: React.FC<VersionHistoryModalProps> = ({
  note,
  isOpen,
  onClose,
}) => {
  const { restoreNoteVersion, createNoteSnapshot, awardXp } = useApp();

  const historyList = note.history || [];
  const [selectedVersionId, setSelectedVersionId] = useState<string>(
    historyList[0]?.id || ''
  );
  const [newSnapshotDesc, setNewSnapshotDesc] = useState('');
  const [isTakingSnapshot, setIsTakingSnapshot] = useState(false);
  const [restoredNotification, setRestoredNotification] = useState(false);

  if (!isOpen) return null;

  const selectedVersion =
    historyList.find(v => v.id === selectedVersionId) || historyList[0];

  const currentWords = note.content.trim().split(/\s+/).filter(Boolean).length;

  const handleRestore = (version: NoteVersion) => {
    if (
      confirm(
        `Are you sure you want to restore the version from ${new Date(
          version.timestamp
        ).toLocaleString()}? Your current edits will be auto-saved into version history so you can undo anytime.`
      )
    ) {
      restoreNoteVersion(note.id, version.id);
      awardXp(15, 'Restored previous note version');
      setRestoredNotification(true);
      setTimeout(() => {
        setRestoredNotification(false);
        onClose();
      }, 1500);
    }
  };

  const handleCreateSnapshot = (e: React.FormEvent) => {
    e.preventDefault();
    createNoteSnapshot(note.id, newSnapshotDesc.trim() || 'Manual study checkpoint');
    setNewSnapshotDesc('');
    setIsTakingSnapshot(false);
  };

  const formatTimestamp = (iso: string) => {
    try {
      const d = new Date(iso);
      const dateStr = d.toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
      const timeStr = d.toLocaleTimeString(undefined, {
        hour: '2-digit',
        minute: '2-digit',
      });
      return { dateStr, timeStr };
    } catch {
      return { dateStr: iso, timeStr: '' };
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-3xl p-5 sm:p-7 shadow-2xl text-slate-100 flex flex-col max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-violet-600 to-indigo-600 flex items-center justify-center text-white shadow-md">
              <History className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">Note Revision History</h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-violet-600/20 text-violet-300 font-semibold border border-violet-500/30">
                  {historyList.length} Versions Recorded
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate max-w-md">{note.title}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsTakingSnapshot(!isTakingSnapshot)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition cursor-pointer"
            >
              <Camera className="w-3.5 h-3.5 text-violet-400" />
              <span className="hidden sm:inline">Save Checkpoint</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Create Manual Checkpoint Banner */}
        {isTakingSnapshot && (
          <form
            onSubmit={handleCreateSnapshot}
            className="p-4 my-3 rounded-2xl bg-violet-950/30 border border-violet-500/40 flex items-center gap-3 shrink-0"
          >
            <input
              type="text"
              value={newSnapshotDesc}
              onChange={(e) => setNewSnapshotDesc(e.target.value)}
              placeholder="Label this version (e.g. Added enzyme diagram formulas)..."
              className="flex-1 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 outline-none focus:border-violet-500"
              autoFocus
            />
            <button
              type="submit"
              className="px-4 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold cursor-pointer"
            >
              Save Version
            </button>
            <button
              type="button"
              onClick={() => setIsTakingSnapshot(false)}
              className="text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </form>
        )}

        {/* Restored Toast */}
        {restoredNotification && (
          <div className="p-3 my-2 rounded-2xl bg-emerald-950/60 border border-emerald-500/50 flex items-center gap-2 text-xs text-emerald-200 shrink-0 animate-in fade-in">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>Version successfully restored! Your previous state was safely archived.</span>
          </div>
        )}

        {/* Content Body: Timeline list + Preview pane */}
        <div className="flex-1 flex flex-col md:flex-row gap-4 pt-4 overflow-hidden min-h-0">
          {/* Left Timeline List */}
          <div className="w-full md:w-72 flex flex-col rounded-2xl bg-slate-950/60 border border-slate-800 p-3 space-y-2 shrink-0 overflow-y-auto">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 px-1">
              Revision Timeline
            </span>

            {/* Current Working Version indicator */}
            <div className="p-3 rounded-xl bg-slate-900 border border-violet-500/40 text-xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-violet-300">Current Active Note</span>
                <span className="text-[9px] bg-emerald-500/20 text-emerald-400 font-bold px-1.5 py-0.2 rounded">
                  Live
                </span>
              </div>
              <p className="text-[11px] text-slate-400">{currentWords} words</p>
            </div>

            <div className="space-y-1.5 pt-1">
              {historyList.map((ver, idx) => {
                const isSelected = selectedVersion?.id === ver.id;
                const { dateStr, timeStr } = formatTimestamp(ver.timestamp);

                return (
                  <button
                    key={ver.id}
                    onClick={() => setSelectedVersionId(ver.id)}
                    className={`w-full p-3 rounded-2xl text-left text-xs border transition cursor-pointer flex flex-col gap-1 ${
                      isSelected
                        ? 'bg-violet-600/20 border-violet-500 text-white shadow-sm'
                        : 'bg-slate-900/60 border-slate-800/80 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-200">
                        {ver.changeDescription || `Revision #${historyList.length - idx}`}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">{timeStr}</span>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-500">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" /> {dateStr}
                      </span>
                      <span>{ver.wordCount} words</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Snapshot Content Preview */}
          {selectedVersion ? (
            <div className="flex-1 flex flex-col rounded-2xl bg-slate-950/80 border border-slate-800 p-4 sm:p-5 overflow-hidden">
              {/* Snapshot Metadata Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80 shrink-0">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">
                      Snapshot from {formatTimestamp(selectedVersion.timestamp).dateStr} at{' '}
                      {formatTimestamp(selectedVersion.timestamp).timeStr}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                      {selectedVersion.wordCount} words
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5 font-medium">
                    {selectedVersion.changeDescription || 'Study revision checkpoint'}
                  </p>
                </div>

                <button
                  onClick={() => handleRestore(selectedVersion)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs transition shadow-md shadow-violet-900/40 cursor-pointer self-start sm:self-auto shrink-0"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restore This Version</span>
                </button>
              </div>

              {/* Version Title Preview */}
              <div className="py-2 shrink-0">
                <span className="text-[10px] uppercase font-bold text-slate-500">Snapshot Title</span>
                <h4 className="text-sm font-bold text-white">{selectedVersion.title}</h4>
              </div>

              {/* Version AI Summary if present */}
              {selectedVersion.summary && (
                <div className="p-3 mb-2 rounded-xl bg-violet-950/20 border border-violet-500/30 text-xs shrink-0 max-h-28 overflow-y-auto space-y-1">
                  <span className="text-[10px] font-bold text-violet-300 flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Archived AI Executive Summary
                  </span>
                  <p className="text-slate-300 whitespace-pre-wrap">{selectedVersion.summary}</p>
                </div>
              )}

              {/* Version Content Body Preview */}
              <div className="flex-1 overflow-y-auto pt-2 border-t border-slate-800/60 font-sans">
                <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">
                  Content Preview
                </span>
                <div className="text-xs sm:text-sm text-slate-300 whitespace-pre-wrap leading-relaxed">
                  {selectedVersion.content}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-500 text-xs rounded-2xl bg-slate-950/80 border border-slate-800">
              <History className="w-10 h-10 text-slate-700 mb-2" />
              <span>Select a version to preview and compare.</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
