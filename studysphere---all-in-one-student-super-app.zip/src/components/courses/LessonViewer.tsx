import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, Clock, BookOpen, HelpCircle, ChevronRight, Bookmark } from 'lucide-react';
import { Course, Lesson } from '../../types';
import { useApp } from '../../context/AppContext';

interface LessonViewerProps {
  course: Course;
  lesson: Lesson;
  onBack: () => void;
  onSelectLesson: (id: string) => void;
}

export const LessonViewer: React.FC<LessonViewerProps> = ({
  course,
  lesson,
  onBack,
  onSelectLesson,
}) => {
  const { toggleLessonCompletion, toggleCourseBookmark, setActiveTab } = useApp();
  const [showHint, setShowHint] = useState(false);
  const [showAnswer, setShowAnswer] = useState(false);
  const [practiceInput, setPracticeInput] = useState('');

  const currentIndex = course.lessons.findIndex(l => l.id === lesson.id);
  const prevLesson = currentIndex > 0 ? course.lessons[currentIndex - 1] : null;
  const nextLesson = currentIndex < course.lessons.length - 1 ? course.lessons[currentIndex + 1] : null;

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Top Breadcrumb & Controls */}
      <div className="flex items-center justify-between gap-4">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-white transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Course Overview</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => toggleCourseBookmark(course.id)}
            className={`p-2 rounded-xl border transition ${
              course.isBookmarked
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
            }`}
            title="Bookmark Course"
          >
            <Bookmark className="w-4 h-4" />
          </button>

          <button
            onClick={() => toggleLessonCompletion(course.id, lesson.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition cursor-pointer ${
              lesson.isCompleted
                ? 'bg-emerald-600/20 border-emerald-500/50 text-emerald-300'
                : 'bg-violet-600 border-violet-500 text-white hover:bg-violet-500'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{lesson.isCompleted ? 'Completed (+50 XP)' : 'Mark as Complete'}</span>
          </button>
        </div>
      </div>

      {/* Lesson Header */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 text-xs text-violet-400 font-semibold">
          <BookOpen className="w-4 h-4" />
          <span>{course.subject} • Lesson {currentIndex + 1} of {course.lessons.length}</span>
        </div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-white">{lesson.title}</h1>
        <div className="flex items-center gap-4 text-xs text-slate-400">
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" /> {lesson.durationMinutes} minutes
          </span>
          <span>Instructor: {course.instructor}</span>
        </div>
      </div>

      {/* Learning Objectives */}
      <div className="p-5 rounded-2xl bg-violet-950/20 border border-violet-500/20 space-y-2">
        <h3 className="text-xs font-bold uppercase tracking-wider text-violet-300">Target Learning Objectives</h3>
        <ul className="space-y-1.5 text-xs text-slate-300">
          {lesson.objectives.map((obj, i) => (
            <li key={i} className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-violet-400 mt-1.5 shrink-0" />
              <span>{obj}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Lesson Body Content */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 border border-slate-800 text-slate-200 text-xs sm:text-sm leading-relaxed space-y-4 whitespace-pre-wrap font-sans">
        {lesson.content}
      </div>

      {/* Interactive Practice Exercise */}
      {lesson.practiceExercise && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
            <HelpCircle className="w-4 h-4" />
            <span>Interactive Knowledge Check</span>
          </div>

          <p className="text-xs sm:text-sm font-semibold text-white">{lesson.practiceExercise.prompt}</p>

          <textarea
            value={practiceInput}
            onChange={(e) => setPracticeInput(e.target.value)}
            rows={3}
            placeholder="Type your deduction or answer here to test active recall..."
            className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 outline-none focus:border-violet-500"
          />

          <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowHint(!showHint)}
                className="text-xs text-slate-400 hover:text-slate-200 underline"
              >
                {showHint ? 'Hide Hint' : '💡 Need a Hint?'}
              </button>

              <button
                type="button"
                onClick={() => setShowAnswer(!showAnswer)}
                className="text-xs text-violet-400 hover:text-violet-300 font-semibold ml-2"
              >
                {showAnswer ? 'Hide Sample Solution' : 'Reveal Sample Solution'}
              </button>
            </div>

            <button
              onClick={() => {
                alert('Great reflection! Your practice answer has been recorded.');
              }}
              className="px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold transition"
            >
              Verify My Answer
            </button>
          </div>

          {showHint && (
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200">
              <strong>Hint:</strong> {lesson.practiceExercise.hint}
            </div>
          )}

          {showAnswer && (
            <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-200 space-y-1">
              <strong>Sample Solution:</strong>
              <p>{lesson.practiceExercise.sampleAnswer}</p>
            </div>
          )}
        </div>
      )}

      {/* Bottom Navigation between lessons */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-800">
        {prevLesson ? (
          <button
            onClick={() => onSelectLesson(prevLesson.id)}
            className="flex items-center gap-2 text-xs font-semibold text-slate-300 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Previous: {prevLesson.title.slice(0, 24)}...</span>
          </button>
        ) : (
          <div />
        )}

        {nextLesson ? (
          <button
            onClick={() => onSelectLesson(nextLesson.id)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold transition"
          >
            <span>Next: {nextLesson.title.slice(0, 24)}...</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            onClick={() => setActiveTab('revision')}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition"
          >
            <span>Take Topic Quiz</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
