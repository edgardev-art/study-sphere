export type UserRole = 'student' | 'educator' | 'admin';
export type EducationLevel = 'high_school' | 'undergraduate' | 'postgraduate' | 'independent';
export type SubscriptionTier = 'free' | 'pro' | 'premium';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  role: UserRole;
  educationLevel: EducationLevel;
  institution?: string;
  subjects: string[];
  learningGoals: string[];
  preferredSchedule: 'morning' | 'afternoon' | 'evening' | 'night';
  dailyHoursTarget: number;
  academicChallenges: string[];
  streakDays: number;
  lastActiveDate: string;
  streakProtected: boolean;
  totalXp: number;
  level: number;
  tier: SubscriptionTier;
  subscriptionRenewalDate?: string;
  onboardingCompleted: boolean;
  createdAt: string;
}

export interface NoteVersion {
  id: string;
  timestamp: string;
  title: string;
  content: string;
  summary?: string;
  changeDescription?: string;
  wordCount: number;
}

export interface Note {
  id: string;
  userId: string;
  title: string;
  content: string;
  subject: string;
  folderId?: string;
  tags: string[];
  isPinned: boolean;
  isFavorite: boolean;
  summary?: string;
  history?: NoteVersion[];
  createdAt: string;
  updatedAt: string;
}

export interface NoteFolder {
  id: string;
  name: string;
  icon?: string;
  color?: string;
}

export interface Lesson {
  id: string;
  title: string;
  durationMinutes: number;
  objectives: string[];
  content: string;
  diagramSvg?: string;
  practiceExercise?: {
    prompt: string;
    sampleAnswer: string;
    hint: string;
  };
  isCompleted?: boolean;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  subject: string;
  level: EducationLevel;
  instructor: string;
  thumbnail: string;
  enrolledStudentsCount: number;
  rating: number;
  lessons: Lesson[];
  isBookmarked?: boolean;
  progressPercent?: number;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  subject: string;
  dueDate: string;
  estimatedMinutes: number;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  completed: boolean;
  type: 'assignment' | 'exam_prep' | 'reading' | 'revision';
}

export interface TimetableBlock {
  id: string;
  day: string;
  timeSlot: string;
  subject: string;
  activity: string;
  duration: string;
  priority: 'Low' | 'Medium' | 'High';
}

export interface Flashcard {
  id: string;
  subject: string;
  deckId: string;
  question: string;
  answer: string;
  lastReviewed?: string;
  intervalDays: number;
  easeFactor: number;
  reviewCount: number;
}

export interface FlashcardDeck {
  id: string;
  title: string;
  subject: string;
  description: string;
  cardCount: number;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface Quiz {
  id: string;
  title: string;
  subject: string;
  topic: string;
  difficulty: 'easy' | 'medium' | 'hard';
  timeLimitMinutes: number;
  questions: QuizQuestion[];
}

export interface QuizAttempt {
  id: string;
  quizId: string;
  quizTitle: string;
  subject: string;
  score: number;
  totalQuestions: number;
  date: string;
  weakTopics: string[];
}

export interface DailyMission {
  id: string;
  title: string;
  rewardXp: number;
  completed: boolean;
  icon: string;
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt?: string;
  category: 'streak' | 'pomodoro' | 'quiz' | 'notes' | 'community';
}

export interface CommunityComment {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorRole: string;
  content: string;
  createdAt: string;
  likes: number;
}

export interface CommunityPost {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorRole: string;
  channel: string;
  subject: string;
  title: string;
  content: string;
  tags: string[];
  likes: number;
  hasLiked?: boolean;
  comments: CommunityComment[];
  isBookmarked?: boolean;
  isReported?: boolean;
  createdAt: string;
}

export interface StudyRoom {
  id: string;
  name: string;
  subject: string;
  description: string;
  activeCount: number;
  maxMembers: number;
  isPrivate: boolean;
  currentTopic: string;
  timerMinutes: number;
  members: Array<{
    name: string;
    avatar: string;
    status: string;
  }>;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'streak' | 'reminder' | 'exam' | 'achievement' | 'community' | 'billing';
  timestamp: string;
  read: boolean;
  actionUrl?: string;
}
