import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Bot,
  User,
  Sparkles,
  HelpCircle,
  BookOpen,
  FileText,
  RotateCcw,
  Lightbulb,
  CheckCircle,
  Copy,
  PlusCircle,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { askAITutor, TutorMessage } from '../../services/aiService';

export const AITutor: React.FC = () => {
  const { user, selectedSubject, setSelectedSubject, addNote, addFlashcard, awardXp } = useApp();

  const [messages, setMessages] = useState<TutorMessage[]>([
    {
      sender: 'ai',
      text: `Hello ${user?.name || 'Scholar'}! I am **StudySphere AI**, your academic tutor.
I can explain complex proofs, generate analogies, drill exam traps, or guide you via **Socratic Questioning** where we deduce the answer together.

What concept in **${selectedSubject}** would you like to explore today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [input, setInput] = useState('');
  const [style, setStyle] = useState<'simple' | 'detailed' | 'exam_prep' | 'socratic'>('socratic');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = async (messageText?: string) => {
    const textToSend = (messageText || input).trim();
    if (!textToSend || isLoading) return;

    const userMessage: TutorMessage = {
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      style,
      subject: selectedSubject,
    };

    setMessages(prev => [...prev, userMessage]);
    if (!messageText) setInput('');
    setIsLoading(true);

    try {
      const res = await askAITutor({
        message: textToSend,
        style,
        subject: selectedSubject,
        history: messages,
        educationLevel: user?.educationLevel || 'Undergraduate',
      });

      const aiMessage: TutorMessage = {
        sender: 'ai',
        text: res.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        style,
        subject: selectedSubject,
      };

      setMessages(prev => [...prev, aiMessage]);
      awardXp(30, 'Studied with AI Tutor');
    } catch {
      setMessages(prev => [
        ...prev,
        {
          sender: 'ai',
          text: 'I ran into an issue connecting to the knowledge network. Please verify your query or try rephrasing.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleSaveToNotes = (text: string) => {
    addNote({
      title: `AI Tutor: ${selectedSubject} Insight`,
      content: text,
      subject: selectedSubject,
      tags: ['ai-tutor', 'study-session', selectedSubject.toLowerCase()],
      isPinned: false,
      isFavorite: true,
    });
    alert('Saved AI explanation to your Digital Notebook!');
  };

  const handleSaveAsFlashcard = (text: string) => {
    const lines = text.split('\n').filter(l => l.trim().length > 0);
    const question = lines[0]?.replace(/[#*]/g, '') || `Concept in ${selectedSubject}`;
    const answer = lines.slice(1, 4).join(' ').replace(/[#*]/g, '') || text.slice(0, 150);

    addFlashcard({
      subject: selectedSubject,
      deckId: 'deck-ai',
      question,
      answer,
    });
    alert('Added to your Flashcard Deck for spaced repetition!');
  };

  const promptSuggestions = [
    `Give me a real-world analogy for the hardest concept in ${selectedSubject}`,
    `Generate 3 challenging multiple-choice practice questions with trap answers`,
    `Walk me through a step-by-step proof or mechanism in ${selectedSubject}`,
    `What are the most common exam mistakes students make here?`,
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] max-w-5xl mx-auto p-3 sm:p-6">
      {/* Top Controls Header */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shrink-0 space-y-3 mb-3 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-violet-600 to-cyan-500 p-0.5">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <Bot className="w-5 h-5 text-violet-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-white">StudySphere AI Tutor</h2>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
                  Gemini 3.8 Engine
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Contextualized for {user?.educationLevel || 'Undergraduate'} level</p>
            </div>
          </div>

          {/* Subject Dropdown */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Subject:</span>
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-semibold text-violet-300 outline-none focus:border-violet-500 cursor-pointer"
            >
              {(user?.subjects && user.subjects.length > 0 ? user.subjects : ['Cellular Biology', 'Calculus II', 'Data Structures', 'Microeconomics']).map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Cognitive Mode Selector */}
        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2 overflow-x-auto text-xs">
          <span className="text-slate-400 text-[11px] font-medium shrink-0">Explanation Style:</span>
          <div className="flex items-center gap-1.5 shrink-0">
            {[
              { id: 'socratic', label: '🏛️ Socratic Deduction', desc: 'Prompts you with guiding questions' },
              { id: 'simple', label: '💡 Simple Analogy', desc: 'Everyday intuitive terms' },
              { id: 'detailed', label: '🔬 Detailed & Rigorous', desc: 'University-grade academic steps' },
              { id: 'exam_prep', label: '🎯 Exam Prep High-Yield', desc: 'Focus on high-yield traps & formulas' },
            ].map(m => (
              <button
                key={m.id}
                onClick={() => setStyle(m.id as any)}
                className={`px-3 py-1.5 rounded-xl font-medium transition cursor-pointer text-xs ${
                  style === m.id
                    ? 'bg-violet-600 text-white shadow-md shadow-violet-900/40 font-bold'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
                title={m.desc}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Messages Stream */}
      <div className="flex-1 overflow-y-auto p-4 rounded-3xl bg-slate-900/50 border border-slate-800/80 space-y-4 mb-3">
        {messages.map((msg, index) => {
          const isAi = msg.sender === 'ai';

          return (
            <div
              key={index}
              className={`flex gap-3 max-w-[88%] ${isAi ? 'mr-auto' : 'ml-auto flex-row-reverse'}`}
            >
              <div
                className={`w-8 h-8 rounded-full shrink-0 flex items-center justify-center text-xs ${
                  isAi
                    ? 'bg-gradient-to-tr from-violet-600 to-indigo-600 text-white shadow-sm'
                    : 'bg-slate-800 border border-slate-700 text-slate-300'
                }`}
              >
                {isAi ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
              </div>

              <div
                className={`p-4 rounded-3xl text-xs sm:text-sm leading-relaxed space-y-2 relative group ${
                  isAi
                    ? 'bg-slate-900 border border-slate-800 text-slate-100 rounded-tl-sm'
                    : 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white rounded-tr-sm shadow-md'
                }`}
              >
                {/* Message text with basic markdown formatting */}
                <div className="whitespace-pre-wrap font-sans">{msg.text}</div>

                <div className="flex items-center justify-between pt-1 border-t border-white/10 text-[10px] text-slate-400">
                  <span>{msg.timestamp}</span>

                  {isAi && (
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => handleCopy(msg.text, index)}
                        className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white"
                        title="Copy Response"
                      >
                        {copiedIndex === index ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>

                      <button
                        onClick={() => handleSaveToNotes(msg.text)}
                        className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white"
                        title="Save as Study Note"
                      >
                        <FileText className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleSaveAsFlashcard(msg.text)}
                        className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white"
                        title="Create Flashcard"
                      >
                        <PlusCircle className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex gap-3 max-w-[85%] mr-auto">
            <div className="w-8 h-8 rounded-full bg-violet-600/30 text-violet-400 flex items-center justify-center animate-pulse">
              <Bot className="w-4 h-4" />
            </div>
            <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 rounded-tl-sm text-xs text-violet-300 flex items-center gap-2">
              <Sparkles className="w-4 h-4 animate-spin text-violet-400" />
              <span>StudySphere AI is reasoning through your concept...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Prompts */}
      {messages.length <= 3 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-2 shrink-0">
          {promptSuggestions.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(p)}
              className="px-3 py-1.5 rounded-full bg-slate-900/90 border border-slate-800 hover:border-violet-500/50 hover:bg-slate-800 text-slate-300 text-[11px] whitespace-nowrap transition cursor-pointer"
            >
              {p}
            </button>
          ))}
        </div>
      )}

      {/* Input Box */}
      <div className="p-2 sm:p-3 rounded-2xl bg-slate-900 border border-slate-800 shrink-0 flex items-center gap-2 shadow-xl">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleSend();
            }
          }}
          rows={1}
          placeholder={`Ask anything about ${selectedSubject}... (e.g. Socratic mode will guide your thinking)`}
          className="flex-1 bg-transparent px-3 py-2 text-xs sm:text-sm text-white placeholder-slate-500 outline-none resize-none"
        />

        <button
          onClick={() => handleSend()}
          disabled={!input.trim() || isLoading}
          className="p-2.5 sm:px-4 sm:py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 disabled:opacity-50 text-white font-semibold text-xs transition flex items-center gap-1.5 cursor-pointer shadow-md shadow-violet-900/40"
        >
          <span className="hidden sm:inline">Ask</span>
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
