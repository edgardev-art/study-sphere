import React, { useState } from 'react';
import {
  X,
  Download,
  FileText,
  Sparkles,
  FileCheck,
  Check,
  FileType,
} from 'lucide-react';
import { Note } from '../../types';
import { exportNoteToPdf, exportNoteToMarkdown } from '../../utils/exportUtils';

interface ExportModalProps {
  note: Note;
  authorName?: string;
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  note,
  authorName = 'Alex Rivera',
  isOpen,
  onClose,
}) => {
  const [format, setFormat] = useState<'pdf' | 'markdown'>('pdf');
  const [scope, setScope] = useState<'full' | 'summary_only' | 'content_only'>(
    note.summary ? 'full' : 'content_only'
  );
  const [isExporting, setIsExporting] = useState(false);

  if (!isOpen) return null;

  const handleExport = () => {
    setIsExporting(true);
    setTimeout(() => {
      if (format === 'pdf') {
        exportNoteToPdf({
          title: note.title,
          subject: note.subject,
          content: note.content,
          summary: note.summary,
          authorName,
          tags: note.tags,
          createdAt: note.createdAt,
          scope,
        });
      } else {
        exportNoteToMarkdown({
          title: note.title,
          subject: note.subject,
          content: note.content,
          summary: note.summary,
          authorName,
          tags: note.tags,
          createdAt: note.createdAt,
          scope,
        });
      }
      setIsExporting(false);
      onClose();
    }, 400);
  };

  const previewFilename = `${note.title.replace(/[^a-zA-Z0-9_-]/g, '_')}${
    scope === 'summary_only' ? '_Summary' : ''
  }.${format === 'pdf' ? 'pdf' : 'md'}`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-7 shadow-2xl text-slate-100 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-violet-600/30 text-violet-400 flex items-center justify-center">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Export Study Document</h3>
              <p className="text-[11px] text-slate-400 truncate max-w-[240px]">{note.title}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 1. Format Selection */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
            Export Format
          </label>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setFormat('pdf')}
              className={`p-3.5 rounded-2xl border text-left transition cursor-pointer flex items-center gap-3 ${
                format === 'pdf'
                  ? 'bg-violet-600/20 border-violet-500 text-white shadow-md'
                  : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <div
                className={`p-2 rounded-xl ${
                  format === 'pdf' ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-400'
                }`}
              >
                <FileType className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-white">PDF Document</p>
                <p className="text-[10px] text-slate-400">Structured print & reading</p>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setFormat('markdown')}
              className={`p-3.5 rounded-2xl border text-left transition cursor-pointer flex items-center gap-3 ${
                format === 'markdown'
                  ? 'bg-violet-600/20 border-violet-500 text-white shadow-md'
                  : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <div
                className={`p-2 rounded-xl ${
                  format === 'markdown' ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-400'
                }`}
              >
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-white">Markdown File</p>
                <p className="text-[10px] text-slate-400">Plain text & Obsidian sync</p>
              </div>
            </button>
          </div>
        </div>

        {/* 2. Scope Selection */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
            Content Scope
          </label>
          <div className="space-y-2 text-xs">
            {/* Full */}
            <button
              type="button"
              onClick={() => setScope('full')}
              className={`w-full p-3 rounded-2xl border text-left transition cursor-pointer flex items-center justify-between ${
                scope === 'full'
                  ? 'bg-violet-950/30 border-violet-500 text-white'
                  : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <div>
                <p className="font-semibold text-white">Complete Note + AI Summary</p>
                <p className="text-[10px] text-slate-400">
                  Full text, subject header, tags, and AI executive summary block
                </p>
              </div>
              {scope === 'full' && <Check className="w-4 h-4 text-violet-400 shrink-0" />}
            </button>

            {/* AI Summary Only */}
            <button
              type="button"
              disabled={!note.summary}
              onClick={() => setScope('summary_only')}
              className={`w-full p-3 rounded-2xl border text-left transition cursor-pointer flex items-center justify-between ${
                !note.summary
                  ? 'opacity-40 cursor-not-allowed border-slate-800 bg-slate-950/30'
                  : scope === 'summary_only'
                  ? 'bg-violet-950/30 border-violet-500 text-white'
                  : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <div>
                <div className="flex items-center gap-1.5">
                  <p className="font-semibold text-white">AI-Generated Summary Sheet Only</p>
                  <Sparkles className="w-3 h-3 text-violet-400" />
                </div>
                <p className="text-[10px] text-slate-400">
                  {note.summary
                    ? '1-page concise executive revision takeaway sheet'
                    : 'Summarize note first with StudySphere AI to enable this'}
                </p>
              </div>
              {scope === 'summary_only' && <Check className="w-4 h-4 text-violet-400 shrink-0" />}
            </button>

            {/* Note Content Only */}
            <button
              type="button"
              onClick={() => setScope('content_only')}
              className={`w-full p-3 rounded-2xl border text-left transition cursor-pointer flex items-center justify-between ${
                scope === 'content_only'
                  ? 'bg-violet-950/30 border-violet-500 text-white'
                  : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <div>
                <p className="font-semibold text-white">Notes Only (Without AI Summary)</p>
                <p className="text-[10px] text-slate-400">Clean original student notes and equations</p>
              </div>
              {scope === 'content_only' && <Check className="w-4 h-4 text-violet-400 shrink-0" />}
            </button>
          </div>
        </div>

        {/* 3. Output Preview Card */}
        <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800/80 text-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span>Target Output:</span>
            <span className="font-mono text-violet-300 font-semibold">{previewFilename}</span>
          </div>
          <p className="text-[10px] text-slate-500">
            Formatted with StudySphere academic typography, page margins, and timestamps.
          </p>
        </div>

        {/* 4. Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={isExporting}
            onClick={handleExport}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 disabled:opacity-50 text-white font-bold text-xs transition shadow-md shadow-violet-900/40 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>{isExporting ? 'Generating Document...' : `Download ${format.toUpperCase()}`}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
