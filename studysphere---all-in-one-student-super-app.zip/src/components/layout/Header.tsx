import React from 'react';
import {
  Search,
  Flame,
  Bell,
  Sun,
  Moon,
  Smartphone,
  Monitor,
  Sparkles,
  ShieldAlert,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PWAInstallButton } from '../common/PWAInstallButton';

export const Header: React.FC = () => {
  const {
    user,
    theme,
    setTheme,
    viewMode,
    setViewMode,
    setIsSearchOpen,
    isNotificationsOpen,
    setIsNotificationsOpen,
    notifications,
    setIsLandingPage,
    setActiveTab,
    setIsAuthModalOpen,
  } = useApp();

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <header className="h-16 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between z-20 shrink-0 sticky top-0">
      {/* Left side: Logo & Branding / Mobile view */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => { setIsLandingPage(false); setActiveTab('dashboard'); }}
          className="flex items-center gap-2.5 text-left group cursor-pointer"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-violet-600 via-indigo-600 to-cyan-400 p-0.5 shadow-md shadow-violet-900/30 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-violet-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-white tracking-tight text-base font-sans">StudySphere</span>
              <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded-full bg-violet-500/20 text-violet-300 border border-violet-500/30">
                {user?.tier || 'Pro'}
              </span>
            </div>
            <p className="text-[10px] text-slate-400 hidden sm:block">AI Student Super App</p>
          </div>
        </button>

        {/* Global Search Trigger */}
        <button
          onClick={() => setIsSearchOpen(true)}
          className="hidden md:flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 text-xs hover:border-slate-700 hover:text-slate-200 transition-all cursor-pointer ml-4 w-60"
        >
          <Search className="w-3.5 h-3.5" />
          <span className="flex-1 text-left">Search courses, notes, AI...</span>
          <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-[10px] font-mono text-slate-400">⌘K</kbd>
        </button>
      </div>

      {/* Right controls: PWA, Streak, XP, Notifications, Theme, Android Mode, Profile */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Mobile Search button */}
        <button
          onClick={() => setIsSearchOpen(true)}
          className="md:hidden p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-900"
          title="Search"
        >
          <Search className="w-4 h-4" />
        </button>

        {/* View Mode Toggle: Android Frame vs Responsive */}
        <button
          onClick={() => setViewMode(viewMode === 'android' ? 'responsive' : 'android')}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-medium transition cursor-pointer ${
            viewMode === 'android'
              ? 'bg-violet-600/20 border-violet-500/50 text-violet-300'
              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
          }`}
          title={viewMode === 'android' ? 'Switch to Full-Width Responsive View' : 'Simulate Android Smartphone View'}
        >
          {viewMode === 'android' ? (
            <>
              <Smartphone className="w-3.5 h-3.5 text-violet-400" />
              <span className="hidden sm:inline">Android View</span>
            </>
          ) : (
            <>
              <Monitor className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Responsive</span>
            </>
          )}
        </button>

        {/* PWA Install Button */}
        <PWAInstallButton compact />

        {/* Streak Flame */}
        <div
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold"
          title={`${user?.streakDays || 7} Days Learning Streak`}
        >
          <Flame className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
          <span>{user?.streakDays || 7}d</span>
        </div>

        {/* Level & XP */}
        <div
          className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-violet-500/10 border border-violet-500/20 text-violet-300 text-xs font-medium"
          title={`Total XP: ${user?.totalXp || 1850}`}
        >
          <span className="font-semibold text-white">Lvl {user?.level || 6}</span>
          <span className="text-violet-400 font-mono">({user?.totalXp || 1850} XP)</span>
        </div>

        {/* Notifications Icon */}
        <div className="relative">
          <button
            onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-900 border border-slate-800 transition relative cursor-pointer"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-violet-600 text-white text-[10px] font-bold flex items-center justify-center animate-bounce">
                {unreadCount}
              </span>
            )}
          </button>
        </div>

        {/* Theme Toggle */}
        <button
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-900 border border-slate-800 transition cursor-pointer"
          title="Toggle Theme"
        >
          {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-400" />}
        </button>

        {/* User Profile Avatar / Sign In */}
        {user ? (
          <button
            onClick={() => setActiveTab('profile')}
            className="flex items-center gap-2 pl-1 cursor-pointer group"
            title="View Profile & Settings"
          >
            <img
              src={user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
              alt={user.name}
              className="w-8 h-8 rounded-full border border-violet-500/40 object-cover ring-2 ring-transparent group-hover:ring-violet-500/50 transition-all"
            />
          </button>
        ) : (
          <button
            onClick={() => setIsAuthModalOpen(true)}
            className="px-3 py-1.5 rounded-xl bg-violet-600 text-white text-xs font-semibold hover:bg-violet-500 transition"
          >
            Sign In
          </button>
        )}
      </div>
    </header>
  );
};
