import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  UserProfile,
  Course,
  Note,
  NoteVersion,
  Task,
  Flashcard,
  Quiz,
  QuizAttempt,
  CommunityPost,
  StudyRoom,
  Badge,
  DailyMission,
  NotificationItem,
  SubscriptionTier,
} from '../types';
import {
  INITIAL_USER,
  INITIAL_COURSES,
  INITIAL_NOTES,
  INITIAL_TASKS,
  INITIAL_FLASHCARDS,
  INITIAL_QUIZZES,
  INITIAL_COMMUNITY_POSTS,
  INITIAL_STUDY_ROOMS,
  INITIAL_BADGES,
  INITIAL_DAILY_MISSIONS,
  INITIAL_NOTIFICATIONS,
} from '../data/seedData';

export type ActiveTab =
  | 'dashboard'
  | 'tutor'
  | 'courses'
  | 'notes'
  | 'planner'
  | 'revision'
  | 'community'
  | 'study-rooms'
  | 'pricing'
  | 'profile'
  | 'admin';

interface AppContextType {
  user: UserProfile | null;
  isAuthenticated: boolean;
  isLandingPage: boolean;
  setIsLandingPage: (val: boolean) => void;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  viewMode: 'responsive' | 'android';
  setViewMode: (mode: 'responsive' | 'android') => void;
  theme: 'dark' | 'light';
  setTheme: (theme: 'dark' | 'light') => void;

  // Data
  notes: Note[];
  courses: Course[];
  tasks: Task[];
  flashcards: Flashcard[];
  quizzes: Quiz[];
  quizAttempts: QuizAttempt[];
  communityPosts: CommunityPost[];
  studyRooms: StudyRoom[];
  badges: Badge[];
  dailyMissions: DailyMission[];
  notifications: NotificationItem[];

  // Actions
  addNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt' | 'userId'>) => Note;
  updateNote: (id: string, updates: Partial<Note>, description?: string) => void;
  deleteNote: (id: string) => void;
  togglePinNote: (id: string) => void;
  toggleFavoriteNote: (id: string) => void;
  restoreNoteVersion: (noteId: string, versionId: string) => void;
  createNoteSnapshot: (noteId: string, description?: string) => void;

  addTask: (task: Omit<Task, 'id' | 'completed'>) => void;
  toggleTask: (id: string) => void;
  deleteTask: (id: string) => void;

  reviewFlashcard: (cardId: string, rating: 'again' | 'hard' | 'good' | 'easy') => void;
  addFlashcard: (card: Omit<Flashcard, 'id' | 'intervalDays' | 'easeFactor' | 'reviewCount'>) => void;

  addQuizAttempt: (attempt: Omit<QuizAttempt, 'id' | 'date'>) => void;
  addQuiz: (quiz: Quiz) => void;

  toggleLessonCompletion: (courseId: string, lessonId: string) => void;
  toggleCourseBookmark: (courseId: string) => void;
  createCourse: (course: Omit<Course, 'id' | 'enrolledStudentsCount' | 'rating'>) => void;

  likePost: (postId: string) => void;
  addComment: (postId: string, text: string) => void;
  createPost: (post: Omit<CommunityPost, 'id' | 'likes' | 'hasLiked' | 'comments' | 'createdAt' | 'authorId' | 'authorName' | 'authorAvatar' | 'authorRole'>) => void;
  reportPost: (postId: string) => void;

  awardXp: (amount: number, reason?: string) => void;
  markNotificationRead: (id: string) => void;
  clearAllNotifications: () => void;

  // Auth & Profile
  login: (email: string, role?: 'student' | 'educator' | 'admin') => void;
  register: (name: string, email: string) => void;
  demoLogin: (role: 'student' | 'educator' | 'admin') => void;
  logout: () => void;
  updateProfile: (updates: Partial<UserProfile>) => void;
  completeOnboarding: (data: Partial<UserProfile>) => void;
  updateSubscription: (tier: SubscriptionTier) => void;

  // Modals
  isSearchOpen: boolean;
  setIsSearchOpen: (val: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (val: boolean) => void;
  isOnboardingModalOpen: boolean;
  setIsOnboardingModalOpen: (val: boolean) => void;
  isCheckoutModalOpen: boolean;
  setIsCheckoutModalOpen: (val: boolean) => void;
  targetCheckoutTier: SubscriptionTier;
  setTargetCheckoutTier: (tier: SubscriptionTier) => void;
  isNotificationsOpen: boolean;
  setIsNotificationsOpen: (val: boolean) => void;

  // Quick Action
  selectedSubject: string;
  setSelectedSubject: (subj: string) => void;
  selectedCourseId: string | null;
  setSelectedCourseId: (id: string | null) => void;
  selectedLessonId: string | null;
  setSelectedLessonId: (id: string | null) => void;
  resetAllData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Persistence state helpers
  const getStored = <T,>(key: string, fallback: T): T => {
    try {
      const item = localStorage.getItem(`studysphere_${key}`);
      return item ? JSON.parse(item) : fallback;
    } catch {
      return fallback;
    }
  };

  const setStored = (key: string, val: unknown) => {
    try {
      localStorage.setItem(`studysphere_${key}`, JSON.stringify(val));
    } catch {
      // storage quota or private browsing
    }
  };

  const [user, setUser] = useState<UserProfile | null>(() => getStored('user', INITIAL_USER));
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => !!getStored('user', INITIAL_USER));
  const [isLandingPage, setIsLandingPage] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [viewMode, setViewMode] = useState<'responsive' | 'android'>(() => getStored('viewMode', 'responsive'));
  const [theme, setTheme] = useState<'dark' | 'light'>(() => getStored('theme', 'dark'));

  const [notes, setNotes] = useState<Note[]>(() => getStored('notes', INITIAL_NOTES));
  const [courses, setCourses] = useState<Course[]>(() => getStored('courses', INITIAL_COURSES));
  const [tasks, setTasks] = useState<Task[]>(() => getStored('tasks', INITIAL_TASKS));
  const [flashcards, setFlashcards] = useState<Flashcard[]>(() => getStored('flashcards', INITIAL_FLASHCARDS));
  const [quizzes, setQuizzes] = useState<Quiz[]>(() => getStored('quizzes', INITIAL_QUIZZES));
  const [quizAttempts, setQuizAttempts] = useState<QuizAttempt[]>(() => getStored('quizAttempts', []));
  const [communityPosts, setCommunityPosts] = useState<CommunityPost[]>(() => getStored('communityPosts', INITIAL_COMMUNITY_POSTS));
  const [studyRooms, setStudyRooms] = useState<StudyRoom[]>(() => getStored('studyRooms', INITIAL_STUDY_ROOMS));
  const [badges, setBadges] = useState<Badge[]>(() => getStored('badges', INITIAL_BADGES));
  const [dailyMissions, setDailyMissions] = useState<DailyMission[]>(() => getStored('dailyMissions', INITIAL_DAILY_MISSIONS));
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => getStored('notifications', INITIAL_NOTIFICATIONS));

  // Selection states
  const [selectedSubject, setSelectedSubject] = useState<string>('Cellular Biology');
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  const [selectedLessonId, setSelectedLessonId] = useState<string | null>(null);

  // Modals
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isOnboardingModalOpen, setIsOnboardingModalOpen] = useState(false);
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
  const [targetCheckoutTier, setTargetCheckoutTier] = useState<SubscriptionTier>('pro');
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  // Sync to localStorage
  useEffect(() => { setStored('user', user); }, [user]);
  useEffect(() => { setStored('viewMode', viewMode); }, [viewMode]);
  useEffect(() => { setStored('theme', theme); }, [theme]);
  useEffect(() => { setStored('notes', notes); }, [notes]);
  useEffect(() => { setStored('courses', courses); }, [courses]);
  useEffect(() => { setStored('tasks', tasks); }, [tasks]);
  useEffect(() => { setStored('flashcards', flashcards); }, [flashcards]);
  useEffect(() => { setStored('quizzes', quizzes); }, [quizzes]);
  useEffect(() => { setStored('quizAttempts', quizAttempts); }, [quizAttempts]);
  useEffect(() => { setStored('communityPosts', communityPosts); }, [communityPosts]);
  useEffect(() => { setStored('studyRooms', studyRooms); }, [studyRooms]);
  useEffect(() => { setStored('badges', badges); }, [badges]);
  useEffect(() => { setStored('dailyMissions', dailyMissions); }, [dailyMissions]);
  useEffect(() => { setStored('notifications', notifications); }, [notifications]);

  // Handle HTML dark mode class
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  // Award XP & trigger level-up check
  const awardXp = (amount: number, reason?: string) => {
    if (!user) return;
    const newTotal = user.totalXp + amount;
    const currentLevel = user.level;
    const newLevel = Math.floor(newTotal / 300) + 1;

    setUser(prev => prev ? {
      ...prev,
      totalXp: newTotal,
      level: newLevel,
    } : null);

    if (newLevel > currentLevel) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
      // Push notification
      setNotifications(prev => [
        {
          id: 'notif-' + Date.now(),
          title: `🎉 Level Up! You are now Level ${newLevel}!`,
          message: `Congratulations! Your dedication unlocked Level ${newLevel} Scholar privileges.`,
          type: 'achievement',
          timestamp: 'Just now',
          read: false,
        },
        ...prev,
      ]);
    } else if (reason) {
      // Optional subtle feedback
    }
  };

  // Notes Actions
  const addNote = (noteData: Omit<Note, 'id' | 'createdAt' | 'updatedAt' | 'userId'>): Note => {
    const words = noteData.content.trim().split(/\s+/).filter(Boolean).length;
    const initialVersion: NoteVersion = {
      id: 'v-' + Date.now(),
      timestamp: new Date().toISOString(),
      title: noteData.title,
      content: noteData.content,
      summary: noteData.summary,
      wordCount: words,
      changeDescription: 'Initial draft created',
    };

    const newNote: Note = {
      ...noteData,
      id: 'note-' + Date.now(),
      userId: user?.id || 'guest',
      history: [initialVersion],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setNotes(prev => [newNote, ...prev]);
    awardXp(35, 'Created a study note');
    return newNote;
  };

  const updateNote = (id: string, updates: Partial<Note>, description?: string) => {
    setNotes(prev => prev.map(n => {
      if (n.id === id) {
        let updatedHistory = n.history || [];

        // If title or content changed, or description was specified, record snapshot
        const contentChanged = updates.content !== undefined && updates.content !== n.content;
        const titleChanged = updates.title !== undefined && updates.title !== n.title;
        const summaryChanged = updates.summary !== undefined && updates.summary !== n.summary;

        if (contentChanged || titleChanged || summaryChanged || description) {
          const currentWords = n.content.trim().split(/\s+/).filter(Boolean).length;
          const autoSnapshot: NoteVersion = {
            id: 'v-' + Date.now(),
            timestamp: new Date().toISOString(),
            title: n.title,
            content: n.content,
            summary: n.summary,
            wordCount: currentWords,
            changeDescription: description || (summaryChanged ? 'AI summary applied' : 'Edited content'),
          };
          // Keep up to 30 snapshots
          updatedHistory = [autoSnapshot, ...updatedHistory].slice(0, 30);
        }

        return {
          ...n,
          ...updates,
          history: updatedHistory,
          updatedAt: new Date().toISOString(),
        };
      }
      return n;
    }));
  };

  const createNoteSnapshot = (id: string, description?: string) => {
    setNotes(prev => prev.map(n => {
      if (n.id === id) {
        const words = n.content.trim().split(/\s+/).filter(Boolean).length;
        const newSnapshot: NoteVersion = {
          id: 'v-' + Date.now(),
          timestamp: new Date().toISOString(),
          title: n.title,
          content: n.content,
          summary: n.summary,
          wordCount: words,
          changeDescription: description || 'Manual snapshot checkpoint',
        };
        return {
          ...n,
          history: [newSnapshot, ...(n.history || [])].slice(0, 30),
        };
      }
      return n;
    }));
  };

  const restoreNoteVersion = (noteId: string, versionId: string) => {
    setNotes(prev => prev.map(n => {
      if (n.id === noteId && n.history) {
        const targetVersion = n.history.find(v => v.id === versionId);
        if (!targetVersion) return n;

        // Save current note state as a snapshot before restoring so restore itself is undoable
        const currentWords = n.content.trim().split(/\s+/).filter(Boolean).length;
        const safetySnapshot: NoteVersion = {
          id: 'v-before-restore-' + Date.now(),
          timestamp: new Date().toISOString(),
          title: n.title,
          content: n.content,
          summary: n.summary,
          wordCount: currentWords,
          changeDescription: `Auto-saved prior to restoring version from ${new Date(targetVersion.timestamp).toLocaleDateString()}`,
        };

        const updatedHistory = [safetySnapshot, ...n.history.filter(v => v.id !== versionId)];

        return {
          ...n,
          title: targetVersion.title,
          content: targetVersion.content,
          summary: targetVersion.summary,
          history: updatedHistory,
          updatedAt: new Date().toISOString(),
        };
      }
      return n;
    }));
  };

  const deleteNote = (id: string) => {
    setNotes(prev => prev.filter(n => n.id !== id));
  };

  const togglePinNote = (id: string) => {
    setNotes(prev => prev.map(n => n.id === id ? { ...n, isPinned: !n.isPinned } : n));
  };

  const toggleFavoriteNote = (id: string) => {
    setNotes(prev => prev.map(n => n.id === id ? { ...n, isFavorite: !n.isFavorite } : n));
  };

  // Task Actions
  const addTask = (taskData: Omit<Task, 'id' | 'completed'>) => {
    const newTask: Task = {
      ...taskData,
      id: 'task-' + Date.now(),
      completed: false,
    };
    setTasks(prev => [newTask, ...prev]);
    awardXp(15, 'Added a study task');
  };

  const toggleTask = (id: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id === id) {
        const nextState = !t.completed;
        if (nextState) {
          awardXp(40, 'Completed study task');
        }
        return { ...t, completed: nextState };
      }
      return t;
    }));
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  // Flashcards Spaced Repetition
  const reviewFlashcard = (cardId: string, rating: 'again' | 'hard' | 'good' | 'easy') => {
    setFlashcards(prev => prev.map(fc => {
      if (fc.id === cardId) {
        let newInterval = 1;
        let newEase = fc.easeFactor;

        if (rating === 'again') {
          newInterval = 1;
          newEase = Math.max(1.3, fc.easeFactor - 0.2);
        } else if (rating === 'hard') {
          newInterval = Math.max(1, Math.round(fc.intervalDays * 1.2));
          newEase = Math.max(1.3, fc.easeFactor - 0.15);
        } else if (rating === 'good') {
          newInterval = Math.round(fc.intervalDays * fc.easeFactor);
          newEase = fc.easeFactor;
        } else if (rating === 'easy') {
          newInterval = Math.round(fc.intervalDays * fc.easeFactor * 1.3);
          newEase = Math.min(2.8, fc.easeFactor + 0.15);
        }

        return {
          ...fc,
          intervalDays: newInterval,
          easeFactor: newEase,
          reviewCount: fc.reviewCount + 1,
          lastReviewed: new Date().toISOString().split('T')[0],
        };
      }
      return fc;
    }));

    awardXp(15, 'Reviewed flashcard');
  };

  const addFlashcard = (card: Omit<Flashcard, 'id' | 'intervalDays' | 'easeFactor' | 'reviewCount'>) => {
    const newFc: Flashcard = {
      ...card,
      id: 'fc-' + Date.now(),
      intervalDays: 1,
      easeFactor: 2.5,
      reviewCount: 0,
    };
    setFlashcards(prev => [newFc, ...prev]);
    awardXp(20, 'Added a flashcard');
  };

  // Quizzes
  const addQuizAttempt = (attempt: Omit<QuizAttempt, 'id' | 'date'>) => {
    const newAttempt: QuizAttempt = {
      ...attempt,
      id: 'qa-' + Date.now(),
      date: new Date().toISOString(),
    };
    setQuizAttempts(prev => [newAttempt, ...prev]);
    awardXp(attempt.score * 20, 'Quiz completed');
    if (attempt.score >= attempt.totalQuestions) {
      confetti({ particleCount: 60, spread: 60, origin: { y: 0.5 } });
    }
  };

  const addQuiz = (quiz: Quiz) => {
    setQuizzes(prev => [quiz, ...prev]);
    awardXp(30, 'Created custom quiz');
  };

  // Courses
  const toggleLessonCompletion = (courseId: string, lessonId: string) => {
    setCourses(prev => prev.map(c => {
      if (c.id === courseId) {
        const updatedLessons = c.lessons.map(l => l.id === lessonId ? { ...l, isCompleted: !l.isCompleted } : l);
        const completedCount = updatedLessons.filter(l => l.isCompleted).length;
        const progress = Math.round((completedCount / updatedLessons.length) * 100);
        return {
          ...c,
          lessons: updatedLessons,
          progressPercent: progress,
        };
      }
      return c;
    }));
    awardXp(50, 'Completed lesson');
  };

  const toggleCourseBookmark = (courseId: string) => {
    setCourses(prev => prev.map(c => c.id === courseId ? { ...c, isBookmarked: !c.isBookmarked } : c));
  };

  const createCourse = (courseData: Omit<Course, 'id' | 'enrolledStudentsCount' | 'rating'>) => {
    const newCourse: Course = {
      ...courseData,
      id: 'course-' + Date.now(),
      enrolledStudentsCount: 1,
      rating: 5.0,
      isBookmarked: false,
      progressPercent: 0,
    };
    setCourses(prev => [newCourse, ...prev]);
    awardXp(100, 'Published a course curriculum');
  };

  // Community
  const likePost = (postId: string) => {
    setCommunityPosts(prev => prev.map(p => {
      if (p.id === postId) {
        const hasLiked = !!p.hasLiked;
        return {
          ...p,
          hasLiked: !hasLiked,
          likes: hasLiked ? p.likes - 1 : p.likes + 1,
        };
      }
      return p;
    }));
  };

  const addComment = (postId: string, text: string) => {
    if (!text.trim()) return;
    const newComment = {
      id: 'comment-' + Date.now(),
      authorId: user?.id || 'guest',
      authorName: user?.name || 'Anonymous Scholar',
      authorAvatar: user?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      authorRole: user?.role === 'educator' ? 'Instructor' : 'Student',
      content: text.trim(),
      createdAt: new Date().toISOString(),
      likes: 0,
    };

    setCommunityPosts(prev => prev.map(p => {
      if (p.id === postId) {
        return {
          ...p,
          comments: [...p.comments, newComment],
        };
      }
      return p;
    }));
    awardXp(25, 'Contributed comment to community');
  };

  const createPost = (postData: Omit<CommunityPost, 'id' | 'likes' | 'hasLiked' | 'comments' | 'createdAt' | 'authorId' | 'authorName' | 'authorAvatar' | 'authorRole'>) => {
    const newPost: CommunityPost = {
      ...postData,
      id: 'post-' + Date.now(),
      authorId: user?.id || 'guest',
      authorName: user?.name || 'Student',
      authorAvatar: user?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      authorRole: user?.role || 'Student',
      likes: 1,
      hasLiked: true,
      comments: [],
      createdAt: new Date().toISOString(),
    };
    setCommunityPosts(prev => [newPost, ...prev]);
    awardXp(50, 'Shared study resource with community');
  };

  const reportPost = (postId: string) => {
    setCommunityPosts(prev => prev.map(p => p.id === postId ? { ...p, isReported: true } : p));
    setNotifications(prev => [
      {
        id: 'notif-report-' + Date.now(),
        title: 'Report Received',
        message: 'Thank you for keeping StudySphere safe. Our moderation team has flagged this post for review.',
        type: 'community',
        timestamp: 'Just now',
        read: false,
      },
      ...prev,
    ]);
  };

  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const clearAllNotifications = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  // Authentication
  const login = (email: string, role: 'student' | 'educator' | 'admin' = 'student') => {
    const existing = INITIAL_USER;
    const updatedUser: UserProfile = {
      ...existing,
      email,
      role,
      name: email.split('@')[0].replace('.', ' ').replace(/\b\w/g, l => l.toUpperCase()),
    };
    setUser(updatedUser);
    setIsAuthenticated(true);
    setIsLandingPage(false);
    setIsAuthModalOpen(false);
  };

  const register = (name: string, email: string) => {
    const newUser: UserProfile = {
      id: 'usr-' + Date.now(),
      name,
      email,
      role: 'student',
      educationLevel: 'undergraduate',
      subjects: ['Cellular Biology', 'Calculus II'],
      learningGoals: ['Master concepts', 'Improve exam scores'],
      preferredSchedule: 'evening',
      dailyHoursTarget: 3,
      academicChallenges: ['Time management'],
      streakDays: 1,
      lastActiveDate: new Date().toISOString().split('T')[0],
      streakProtected: true,
      totalXp: 100,
      level: 1,
      tier: 'free',
      onboardingCompleted: false,
      createdAt: new Date().toISOString(),
      avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(name)}`,
    };
    setUser(newUser);
    setIsAuthenticated(true);
    setIsLandingPage(false);
    setIsAuthModalOpen(false);
    setIsOnboardingModalOpen(true);
  };

  const demoLogin = (role: 'student' | 'educator' | 'admin') => {
    let demoUser: UserProfile = { ...INITIAL_USER, role };
    if (role === 'educator') {
      demoUser = {
        ...INITIAL_USER,
        id: 'usr-educator-1',
        name: 'Dr. Evelyn Reed',
        email: 'evelyn.reed@faculty.edu',
        role: 'educator',
        educationLevel: 'postgraduate',
        institution: 'Institute of Applied Sciences',
        avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
        tier: 'premium',
      };
    } else if (role === 'admin') {
      demoUser = {
        ...INITIAL_USER,
        id: 'usr-admin-1',
        name: 'System Admin (Jordan Lee)',
        email: 'admin@studysphere.internal',
        role: 'admin',
        tier: 'premium',
        avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
      };
    }
    setUser(demoUser);
    setIsAuthenticated(true);
    setIsLandingPage(false);
    setIsAuthModalOpen(false);
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    setIsLandingPage(true);
    localStorage.removeItem('studysphere_user');
  };

  const updateProfile = (updates: Partial<UserProfile>) => {
    setUser(prev => prev ? { ...prev, ...updates } : null);
  };

  const completeOnboarding = (data: Partial<UserProfile>) => {
    setUser(prev => prev ? {
      ...prev,
      ...data,
      onboardingCompleted: true,
      totalXp: prev.totalXp + 150,
    } : null);
    setIsOnboardingModalOpen(false);
    confetti({ particleCount: 70, spread: 65, origin: { y: 0.6 } });
  };

  const updateSubscription = (tier: SubscriptionTier) => {
    setUser(prev => prev ? {
      ...prev,
      tier,
      subscriptionRenewalDate: new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString().split('T')[0],
    } : null);

    setNotifications(prev => [
      {
        id: 'notif-sub-' + Date.now(),
        title: `⚡ Upgraded to StudySphere ${tier.toUpperCase()}`,
        message: `Your account is now activated with unlimited AI tutor reasoning and premium features.`,
        type: 'billing',
        timestamp: 'Just now',
        read: false,
      },
      ...prev,
    ]);

    confetti({ particleCount: 100, spread: 80, origin: { y: 0.5 } });
  };

  const resetAllData = () => {
    setUser(INITIAL_USER);
    setNotes(INITIAL_NOTES);
    setCourses(INITIAL_COURSES);
    setTasks(INITIAL_TASKS);
    setFlashcards(INITIAL_FLASHCARDS);
    setQuizzes(INITIAL_QUIZZES);
    setQuizAttempts([]);
    setCommunityPosts(INITIAL_COMMUNITY_POSTS);
    setStudyRooms(INITIAL_STUDY_ROOMS);
    setBadges(INITIAL_BADGES);
    setDailyMissions(INITIAL_DAILY_MISSIONS);
    setNotifications(INITIAL_NOTIFICATIONS);
    localStorage.clear();
  };

  return (
    <AppContext.Provider
      value={{
        user,
        isAuthenticated,
        isLandingPage,
        setIsLandingPage,
        activeTab,
        setActiveTab,
        viewMode,
        setViewMode,
        theme,
        setTheme,
        notes,
        courses,
        tasks,
        flashcards,
        quizzes,
        quizAttempts,
        communityPosts,
        studyRooms,
        badges,
        dailyMissions,
        notifications,
        addNote,
        updateNote,
        deleteNote,
        togglePinNote,
        toggleFavoriteNote,
        restoreNoteVersion,
        createNoteSnapshot,
        addTask,
        toggleTask,
        deleteTask,
        reviewFlashcard,
        addFlashcard,
        addQuizAttempt,
        addQuiz,
        toggleLessonCompletion,
        toggleCourseBookmark,
        createCourse,
        likePost,
        addComment,
        createPost,
        reportPost,
        awardXp,
        markNotificationRead,
        clearAllNotifications,
        login,
        register,
        demoLogin,
        logout,
        updateProfile,
        completeOnboarding,
        updateSubscription,
        isSearchOpen,
        setIsSearchOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isOnboardingModalOpen,
        setIsOnboardingModalOpen,
        isCheckoutModalOpen,
        setIsCheckoutModalOpen,
        targetCheckoutTier,
        setTargetCheckoutTier,
        isNotificationsOpen,
        setIsNotificationsOpen,
        selectedSubject,
        setSelectedSubject,
        selectedCourseId,
        setSelectedCourseId,
        selectedLessonId,
        setSelectedLessonId,
        resetAllData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
