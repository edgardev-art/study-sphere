import React, { useState } from 'react';
import {
  Users,
  MessageSquare,
  Heart,
  Bookmark,
  Share2,
  Send,
  Plus,
  Hash,
  Flag,
  Search,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CommunityPost } from '../../types';

export const CommunityHub: React.FC = () => {
  const {
    communityPosts,
    likePost,
    addComment,
    createPost,
    reportPost,
    user,
  } = useApp();

  const [activeChannel, setActiveChannel] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [isCreatingPost, setIsCreatingPost] = useState(false);

  // New post form state
  const [postTitle, setPostTitle] = useState('');
  const [postContent, setPostContent] = useState('');
  const [postChannel, setPostChannel] = useState('#general-study');
  const [postSubject, setPostSubject] = useState(user?.subjects[0] || 'Cellular Biology');
  const [postTags, setPostTags] = useState('ExamTips, HighYield');

  const channels = ['All', '#general-study', '#biology-squad', '#tech-coders', '#calculus-grind'];

  const filteredPosts = communityPosts.filter(p => {
    const matchesChannel = activeChannel === 'All' || p.channel === activeChannel;
    const matchesSearch = p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.tags.some(t => t.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesChannel && matchesSearch;
  });

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!postTitle.trim() || !postContent.trim()) return;

    createPost({
      channel: postChannel,
      subject: postSubject,
      title: postTitle,
      content: postContent,
      tags: postTags.split(',').map(t => t.trim()).filter(Boolean),
    });

    setPostTitle('');
    setPostContent('');
    setIsCreatingPost(false);
  };

  const handleSendComment = (postId: string) => {
    const text = commentInputs[postId];
    if (!text || !text.trim()) return;
    addComment(postId, text);
    setCommentInputs(prev => ({ ...prev, [postId]: '' }));
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Users className="w-6 h-6 text-cyan-400" />
            <span>Student Community & Academic Forum</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Exchange study hacks, ask challenging homework questions, and discuss solutions with verified classmates.
          </p>
        </div>

        <button
          onClick={() => setIsCreatingPost(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition shadow-md shadow-cyan-900/40 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Post Discussion (+50 XP)</span>
        </button>
      </div>

      {/* Channel Filters and Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 text-xs">
          {channels.map(ch => (
            <button
              key={ch}
              onClick={() => setActiveChannel(ch)}
              className={`px-3 py-1.5 rounded-xl font-medium transition cursor-pointer whitespace-nowrap ${
                activeChannel === ch
                  ? 'bg-cyan-600 text-white shadow-xs'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {ch}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search questions or tags..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* New Post Form Modal/Inline */}
      {isCreatingPost && (
        <form onSubmit={handleCreatePost} className="p-6 rounded-3xl bg-slate-900 border border-cyan-500/50 space-y-4">
          <h3 className="text-sm font-bold text-white">Create Academic Discussion</h3>

          <div>
            <input
              type="text"
              required
              value={postTitle}
              onChange={(e) => setPostTitle(e.target.value)}
              placeholder="What question or study concept would you like to discuss?"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 outline-none focus:border-cyan-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <label className="block text-[10px] text-slate-400 mb-1">Channel</label>
              <select
                value={postChannel}
                onChange={(e) => setPostChannel(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none"
              >
                {channels.filter(c => c !== 'All').map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-[10px] text-slate-400 mb-1">Subject</label>
              <input
                type="text"
                required
                value={postSubject}
                onChange={(e) => setPostSubject(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] text-slate-400 mb-1">Tags (comma-separated)</label>
              <input
                type="text"
                value={postTags}
                onChange={(e) => setPostTags(e.target.value)}
                placeholder="Krebs, Formulas, ExamHelp"
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none"
              />
            </div>
          </div>

          <div>
            <textarea
              required
              rows={4}
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              placeholder="Write the detailed context, equations, or helpful breakdown here..."
              className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 outline-none focus:border-cyan-500 font-sans"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setIsCreatingPost(false)}
              className="px-4 py-2 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition shadow-md shadow-cyan-900/40"
            >
              Publish Post
            </button>
          </div>
        </form>
      )}

      {/* Discussion Posts Feed */}
      <div className="space-y-4 max-w-4xl mx-auto">
        {filteredPosts.map(post => (
          <div
            key={post.id}
            className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 hover:border-slate-700 transition"
          >
            {/* Author Bar */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={post.authorAvatar}
                  alt={post.authorName}
                  className="w-9 h-9 rounded-full object-cover border border-cyan-500/30"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">{post.authorName}</span>
                    <span className="text-[10px] text-cyan-400 px-2 py-0.2 rounded-full bg-cyan-950/40 border border-cyan-500/20">
                      {post.authorRole}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                    <span>{post.channel}</span>
                    <span>• {post.subject}</span>
                    <span>• {post.createdAt.split('T')[0]}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => reportPost(post.id)}
                className="text-slate-500 hover:text-rose-400 p-1"
                title="Report Inappropriate Content"
              >
                <Flag className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Post Title & Content */}
            <div className="space-y-2">
              <h3 className="text-base font-bold text-white leading-snug">{post.title}</h3>
              <div className="text-xs sm:text-sm text-slate-300 whitespace-pre-wrap leading-relaxed font-sans">
                {post.content}
              </div>
            </div>

            {/* Tags */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {post.tags.map(t => (
                <span key={t} className="text-[10px] px-2 py-0.5 rounded-md bg-slate-950 text-slate-400 font-mono">
                  #{t}
                </span>
              ))}
            </div>

            {/* Reactions & Actions */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-800 text-xs text-slate-400">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => likePost(post.id)}
                  className={`flex items-center gap-1.5 transition ${
                    post.hasLiked ? 'text-rose-400 font-bold' : 'hover:text-white'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${post.hasLiked ? 'fill-rose-400' : ''}`} />
                  <span>{post.likes}</span>
                </button>

                <span className="flex items-center gap-1.5">
                  <MessageSquare className="w-4 h-4" />
                  <span>{post.comments.length} Comments</span>
                </span>
              </div>
            </div>

            {/* Comments List */}
            {post.comments.length > 0 && (
              <div className="space-y-2.5 pt-2 pl-4 border-l-2 border-slate-800">
                {post.comments.map(c => (
                  <div key={c.id} className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800/80 text-xs space-y-1">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-semibold text-white">{c.authorName}</span>
                      <span className="text-[10px] text-slate-500">{c.createdAt.split('T')[0]}</span>
                    </div>
                    <p className="text-slate-300 leading-relaxed">{c.content}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Comment Input */}
            <div className="flex items-center gap-2 pt-2">
              <input
                type="text"
                value={commentInputs[post.id] || ''}
                onChange={(e) => setCommentInputs({ ...commentInputs, [post.id]: e.target.value })}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSendComment(post.id);
                }}
                placeholder="Write an encouraging reply or explanation..."
                className="flex-1 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 outline-none focus:border-cyan-500"
              />
              <button
                onClick={() => handleSendComment(post.id)}
                className="p-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white transition"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
