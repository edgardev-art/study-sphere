import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  Star,
  Users,
  Clock,
  Plus,
  Play,
  CheckCircle2,
  Bookmark,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { LessonViewer } from './LessonViewer';
import { CreateCourseModal } from './CreateCourseModal';

export const CourseCatalog: React.FC = () => {
  const {
    courses,
    selectedCourseId,
    setSelectedCourseId,
    selectedLessonId,
    setSelectedLessonId,
    toggleCourseBookmark,
    user,
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState('All');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const subjects = ['All', ...new Set(courses.map(c => c.subject))];

  const filteredCourses = courses.filter(c => {
    const matchesSubject = selectedSubjectFilter === 'All' || c.subject === selectedSubjectFilter;
    const matchesSearch = c.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          c.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSubject && matchesSearch;
  });

  const selectedCourse = courses.find(c => c.id === selectedCourseId);
  const activeLesson = selectedCourse?.lessons.find(l => l.id === selectedLessonId);

  // If a lesson is actively open in the course, render LessonViewer
  if (selectedCourse && activeLesson) {
    return (
      <LessonViewer
        course={selectedCourse}
        lesson={activeLesson}
        onBack={() => setSelectedLessonId(null)}
        onSelectLesson={(lessonId) => setSelectedLessonId(lessonId)}
      />
    );
  }

  // If a course is selected (overview mode)
  if (selectedCourse) {
    return (
      <div className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        <button
          onClick={() => setSelectedCourseId(null)}
          className="text-xs text-slate-400 hover:text-white font-semibold transition cursor-pointer"
        >
          ← Back to All Courses
        </button>

        {/* Hero Card */}
        <div className="relative rounded-3xl overflow-hidden border border-slate-800 bg-slate-900">
          <img
            src={selectedCourse.thumbnail}
            alt={selectedCourse.title}
            className="w-full h-48 sm:h-64 object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-transparent p-6 sm:p-8 flex flex-col justify-end">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-violet-600/30 text-violet-300 border border-violet-500/40">
                {selectedCourse.subject}
              </span>
              <span className="text-xs text-slate-300">• {selectedCourse.instructor}</span>
            </div>
            <h1 className="text-xl sm:text-3xl font-extrabold text-white mb-2">{selectedCourse.title}</h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">{selectedCourse.description}</p>
          </div>
        </div>

        {/* Course Progress & Lessons List */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Course Syllabus ({selectedCourse.lessons.length} Modules)</h3>
            <span className="text-xs font-semibold text-violet-400">{selectedCourse.progressPercent || 0}% Completed</span>
          </div>

          <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-violet-600 to-indigo-500 rounded-full"
              style={{ width: `${selectedCourse.progressPercent || 0}%` }}
            />
          </div>

          <div className="space-y-2.5 pt-3">
            {selectedCourse.lessons.map((lesson, idx) => (
              <div
                key={lesson.id}
                onClick={() => setSelectedLessonId(lesson.id)}
                className={`flex items-center justify-between p-4 rounded-2xl border transition cursor-pointer ${
                  lesson.isCompleted
                    ? 'bg-slate-950/40 border-slate-800/80 hover:border-slate-700'
                    : 'bg-slate-950/80 border-slate-800 hover:border-violet-500/50'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-bold ${
                      lesson.isCompleted
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {lesson.isCompleted ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-semibold text-white">{lesson.title}</h4>
                    <p className="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5">
                      <Clock className="w-3 h-3" /> {lesson.durationMinutes} mins • {lesson.objectives.length} objectives
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  className="px-3 py-1.5 rounded-xl bg-violet-600/20 text-violet-300 text-xs font-semibold hover:bg-violet-600 hover:text-white transition flex items-center gap-1"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{lesson.isCompleted ? 'Review' : 'Start'}</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-violet-400" />
            <span>Courses & Learning Library</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Structured modular lessons with learning objectives, practice checks, and topic quizzes.
          </p>
        </div>

        {(user?.role === 'educator' || user?.role === 'admin') && (
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-violet-600 hover:bg-violet-500 text-white font-semibold text-xs transition shadow-md shadow-violet-900/40 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create Curriculum</span>
          </button>
        )}
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search courses or topics..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 text-xs">
          {subjects.map(subj => (
            <button
              key={subj}
              onClick={() => setSelectedSubjectFilter(subj)}
              className={`px-3 py-1.5 rounded-xl font-medium transition cursor-pointer whitespace-nowrap ${
                selectedSubjectFilter === subj
                  ? 'bg-violet-600 text-white shadow-xs'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {subj}
            </button>
          ))}
        </div>
      </div>

      {/* Course Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.map(course => (
          <div
            key={course.id}
            className="rounded-3xl bg-slate-900 border border-slate-800 overflow-hidden hover:border-violet-500/40 transition group flex flex-col justify-between shadow-lg"
          >
            <div>
              {/* Thumbnail */}
              <div className="relative h-44 overflow-hidden">
                <img
                  src={course.thumbnail}
                  alt={course.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />

                <button
                  onClick={() => toggleCourseBookmark(course.id)}
                  className={`absolute top-3 right-3 p-2 rounded-xl backdrop-blur-md transition ${
                    course.isBookmarked
                      ? 'bg-amber-500/30 text-amber-300 border border-amber-500/50'
                      : 'bg-slate-900/60 text-slate-300 hover:text-white'
                  }`}
                >
                  <Bookmark className="w-4 h-4" />
                </button>

                <div className="absolute bottom-3 left-3 flex items-center gap-1.5">
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-violet-600 text-white shadow-xs">
                    {course.subject}
                  </span>
                  <span className="text-[10px] text-slate-300 font-semibold px-2 py-0.5 rounded-full bg-slate-900/80 backdrop-blur-md">
                    {course.lessons.length} Lessons
                  </span>
                </div>
              </div>

              {/* Course Info */}
              <div className="p-5 space-y-2.5">
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span className="flex items-center gap-1 text-amber-400 font-semibold">
                    <Star className="w-3.5 h-3.5 fill-amber-400" /> {course.rating}
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="w-3 h-3" /> {course.enrolledStudentsCount} students
                  </span>
                </div>

                <h3 className="text-sm font-bold text-white group-hover:text-violet-300 transition-colors line-clamp-1">
                  {course.title}
                </h3>
                <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                  {course.description}
                </p>

                {/* Progress bar if started */}
                {(course.progressPercent || 0) > 0 && (
                  <div className="pt-2">
                    <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                      <span>Progress</span>
                      <span>{course.progressPercent}%</span>
                    </div>
                    <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-violet-500 rounded-full" style={{ width: `${course.progressPercent}%` }} />
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Action */}
            <div className="p-5 pt-0">
              <button
                onClick={() => setSelectedCourseId(course.id)}
                className="w-full py-2.5 rounded-2xl bg-slate-800 hover:bg-violet-600 text-white font-semibold text-xs transition flex items-center justify-center gap-1.5 group-hover:bg-violet-600 cursor-pointer shadow-sm"
              >
                <span>{(course.progressPercent || 0) > 0 ? 'Continue Curriculum' : 'View Syllabus & Enroll'}</span>
                <Play className="w-3.5 h-3.5 fill-current" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <CreateCourseModal isOpen={isCreateModalOpen} onClose={() => setIsCreateModalOpen(false)} />
    </div>
  );
};
