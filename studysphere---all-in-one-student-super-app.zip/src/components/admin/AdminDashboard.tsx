import React, { useState } from 'react';
import {
  ShieldAlert,
  Users,
  Clock,
  Bot,
  CheckCircle2,
  AlertTriangle,
  Trash2,
  TrendingUp,
  Activity,
  Cpu,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AdminDashboard: React.FC = () => {
  const { user, communityPosts } = useApp();

  const [activeTab, setActiveTab] = useState<'users' | 'moderation' | 'ai_metrics'>('users');

  const reportedPosts = communityPosts.filter(p => p.isReported);

  // Sample managed users
  const [usersList, setUsersList] = useState([
    { id: '1', name: 'Alex Rivera', email: 'alex.rivera@campus.edu', role: 'student', tier: 'pro', active: '2 mins ago' },
    { id: '2', name: 'Dr. Sarah Chen', email: 'schen@faculty.edu', role: 'educator', tier: 'premium', active: '1 hour ago' },
    { id: '3', name: 'Charlotte Bennett', email: 'c.bennett@campus.edu', role: 'student', tier: 'pro', active: '4 hours ago' },
    { id: '4', name: 'Marcus Vance', email: 'm.vance@campus.edu', role: 'student', tier: 'free', active: 'Yesterday' },
  ]);

  const handleRoleChange = (id: string, newRole: string) => {
    setUsersList(prev => prev.map(u => u.id === id ? { ...u, role: newRole } : u));
    alert(`Updated user role to ${newRole}`);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-amber-400" />
            <h1 className="text-2xl font-extrabold text-white tracking-tight">System Administrator Console</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time platform analytics, user role validation, community content moderation, and AI engine telemetry.
          </p>
        </div>

        <div className="flex rounded-2xl bg-slate-900 p-1 border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('users')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition ${activeTab === 'users' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            User Roles
          </button>
          <button
            onClick={() => setActiveTab('moderation')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition ${activeTab === 'moderation' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            Flagged Content ({reportedPosts.length})
          </button>
          <button
            onClick={() => setActiveTab('ai_metrics')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition ${activeTab === 'ai_metrics' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            AI Engine Telemetry
          </button>
        </div>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Active Students</span>
            <Users className="w-4 h-4 text-violet-400" />
          </div>
          <p className="text-2xl font-extrabold text-white font-mono">14,820</p>
          <span className="text-[10px] text-emerald-400 font-semibold">+12% this week</span>
        </div>

        <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Study Hours Logged</span>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-2xl font-extrabold text-white font-mono">84,210h</p>
          <span className="text-[10px] text-emerald-400 font-semibold">98.4% Pomodoro completion</span>
        </div>

        <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>AI Tutor Questions</span>
            <Bot className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-extrabold text-white font-mono">320,400</p>
          <span className="text-[10px] text-violet-300 font-semibold">Gemini 3.8 Flash model</span>
        </div>

        <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Quiz Pass Rate</span>
            <TrendingUp className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-extrabold text-white font-mono">84.6%</p>
          <span className="text-[10px] text-emerald-400 font-semibold">+4.2% diagnostic mastery</span>
        </div>
      </div>

      {/* Tab 1: User Roles Management Table */}
      {activeTab === 'users' && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">User Accounts & Access Control (RBAC)</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead>
                <tr className="border-b border-slate-800 text-slate-500">
                  <th className="pb-3">Student / User</th>
                  <th className="pb-3">Role</th>
                  <th className="pb-3">Subscription</th>
                  <th className="pb-3">Last Active</th>
                  <th className="pb-3">Permissions Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {usersList.map(u => (
                  <tr key={u.id}>
                    <td className="py-3">
                      <p className="font-semibold text-white">{u.name}</p>
                      <p className="text-[10px] text-slate-400">{u.email}</p>
                    </td>
                    <td className="py-3 capitalize">
                      <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">{u.role}</span>
                    </td>
                    <td className="py-3 uppercase font-semibold text-violet-400">{u.tier}</td>
                    <td className="py-3 text-slate-400">{u.active}</td>
                    <td className="py-3">
                      <select
                        value={u.role}
                        onChange={(e) => handleRoleChange(u.id, e.target.value)}
                        className="px-2 py-1 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white"
                      >
                        <option value="student">Student</option>
                        <option value="educator">Educator</option>
                        <option value="admin">Administrator</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Community Moderation Queue */}
      {activeTab === 'moderation' && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Flagged Discussions for Review</h3>
          {reportedPosts.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-xs">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
              <span>Community moderation queue is completely clear. All posts adhere to academic integrity standards.</span>
            </div>
          ) : (
            <div className="space-y-3">
              {reportedPosts.map(p => (
                <div key={p.id} className="p-4 rounded-2xl bg-slate-950 border border-rose-500/40 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-white">{p.title}</span>
                    <p className="text-slate-400 mt-1 line-clamp-1">{p.content}</p>
                    <span className="text-[10px] text-slate-500">By {p.authorName} in {p.channel}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white">Dismiss Report</button>
                    <button className="px-3 py-1.5 rounded-lg bg-rose-600 text-white font-semibold">Remove Content</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: AI Telemetry */}
      {activeTab === 'ai_metrics' && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Gemini 3.8 Flash AI Diagnostics</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-slate-400">Average Latency</span>
              <p className="text-xl font-bold font-mono text-emerald-400">340 ms</p>
              <p className="text-[10px] text-slate-500">Server-side proxy execution</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-slate-400">Socratic Reasoning Mode</span>
              <p className="text-xl font-bold font-mono text-violet-400">62% of queries</p>
              <p className="text-[10px] text-slate-500">Highest student engagement rate</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-slate-400">Knowledge Fallback Mode</span>
              <p className="text-xl font-bold font-mono text-cyan-400">Active & Resilient</p>
              <p className="text-[10px] text-slate-500">Safe offline academic deduction</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
