import React, { useState } from 'react';
import {
  Video,
  Users,
  Clock,
  Plus,
  Play,
  Volume2,
  Lock,
  Globe,
  Sparkles,
  Send,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { StudyRoom } from '../../types';

export const StudyRooms: React.FC = () => {
  const { studyRooms, user, awardXp } = useApp();
  const [activeRoom, setActiveRoom] = useState<StudyRoom | null>(studyRooms[0] || null);
  const [roomChat, setRoomChat] = useState<Array<{ sender: string; text: string; time: string }>>([
    { sender: 'Charlotte B.', text: 'Reviewing question #4 from yesterday’s problem set.', time: '12:01' },
    { sender: 'David Kim', text: 'Focus interval started! Good luck everyone.', time: '12:03' },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isJoined, setIsJoined] = useState(false);

  const handleSendMessage = () => {
    if (!chatInput.trim()) return;
    setRoomChat(prev => [
      ...prev,
      {
        sender: user?.name || 'You',
        text: chatInput.trim(),
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setChatInput('');
    awardXp(15, 'Collaborated in study room');
  };

  const handleJoinRoom = (room: StudyRoom) => {
    setActiveRoom(room);
    setIsJoined(true);
    awardXp(25, 'Joined virtual study room');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Video className="w-6 h-6 text-rose-400" />
            <span>Shared Virtual Study Rooms</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Study collaboratively with classmates in synchronized focus rooms with shared Pomodoro timers.
          </p>
        </div>

        <button
          onClick={() => alert('New study room creation initialized! Configure subjects and room capacity.')}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs transition shadow-md shadow-rose-900/40 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Create Study Room</span>
        </button>
      </div>

      {/* Main Grid: Active Room Interactive View + Rooms Catalog */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Study Room (2 Columns) */}
        {activeRoom ? (
          <div className="lg:col-span-2 rounded-3xl bg-slate-900 border border-slate-800 p-6 space-y-6 flex flex-col justify-between shadow-xl">
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold text-white">{activeRoom.name}</h2>
                    <span className="flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full font-bold">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      Live Synchronized
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">{activeRoom.description}</p>
                </div>

                <div className="text-right">
                  <span className="text-xs text-slate-400 block">Room Timer</span>
                  <span className="text-lg font-mono font-bold text-rose-400">{activeRoom.timerMinutes}:24</span>
                </div>
              </div>

              {/* Participants Grid */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  Connected Students ({activeRoom.members.length + (isJoined ? 1 : 0)} / {activeRoom.maxMembers})
                </h4>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {activeRoom.members.map((member, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center gap-3"
                    >
                      <img
                        src={member.avatar}
                        alt={member.name}
                        className="w-8 h-8 rounded-full object-cover border border-slate-700 shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-white truncate">{member.name}</p>
                        <p className="text-[10px] text-emerald-400 truncate">{member.status}</p>
                      </div>
                    </div>
                  ))}

                  {isJoined && (
                    <div className="p-3 rounded-2xl bg-violet-950/40 border border-violet-500/50 flex items-center gap-3">
                      <img
                        src={user?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                        alt="You"
                        className="w-8 h-8 rounded-full object-cover border border-violet-400 shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-white truncate">{user?.name} (You)</p>
                        <p className="text-[10px] text-violet-300 truncate">Deep Focus Active</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* In-Room Group Discussion Stream */}
            <div className="space-y-3 pt-4 border-t border-slate-800">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Silent Room Chat</h4>

              <div className="h-36 overflow-y-auto p-3 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-2 text-xs">
                {roomChat.map((msg, i) => (
                  <div key={i} className="flex items-start justify-between gap-2">
                    <div>
                      <span className="font-semibold text-violet-300">{msg.sender}: </span>
                      <span className="text-slate-300">{msg.text}</span>
                    </div>
                    <span className="text-[10px] text-slate-500 shrink-0">{msg.time}</span>
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') handleSendMessage(); }}
                  placeholder="Share focus goal or question with the room..."
                  className="flex-1 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 outline-none focus:border-rose-500"
                />
                <button
                  onClick={handleSendMessage}
                  className="p-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white transition"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ) : null}

        {/* Available Rooms Sidebar List */}
        <div className="space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Active Study Rooms</h3>

          <div className="space-y-3">
            {studyRooms.map(room => {
              const isSelected = activeRoom?.id === room.id;

              return (
                <div
                  key={room.id}
                  onClick={() => handleJoinRoom(room)}
                  className={`p-5 rounded-3xl border transition cursor-pointer space-y-3 ${
                    isSelected
                      ? 'bg-rose-950/20 border-rose-500/60 shadow-lg'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">{room.name}</span>
                    <span className="text-[10px] text-rose-300 font-semibold px-2 py-0.5 rounded-full bg-rose-500/10">
                      {room.subject}
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 line-clamp-2">{room.description}</p>

                  <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800/80">
                    <span className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-slate-400" /> {room.activeCount} studying now
                    </span>
                    <span className="text-violet-400 font-semibold">Join Room →</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
