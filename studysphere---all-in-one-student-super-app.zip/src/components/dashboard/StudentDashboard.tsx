import React from 'react';
import {
  Flame,
  Award,
  Sparkles,
  Bot,
  FilePlus,
  Play,
  Calendar,
  BookOpen,
  ArrowRight,
  CheckCircle2,
  Clock,
  TrendingUp,
  Brain,
  FileText,
  AlertTriangle,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const StudentDashboard: React.FC = () => {
  const {
    user,
    courses,
    notes,
    tasks,
    toggleTask,
    setActiveTab,
    setSelectedCourseId,
    setSelectedSubject,
    dailyMissions,
  } = useApp();

  // Urgent and pending tasks
  const pendingTasks = tasks.filter(t => !t.completed).slice(0, 4);

  // Weekly study time distribution (mock realistic minutes for chart)
  const weeklyStudyData = [
    { day: 'Mon', hours: 3.5 },
    { day: 'Tue', hours: 4.2 },
    { day: 'Wed', hours: 2.8 },
    { day: 'Thu', hours: 4.5 },
    { day: 'Fri', hours: 3.0 },
    { day: 'Sat', hours: 5.2 },
    { day: 'Sun (Today)', hours: 2.5 },
  ];

  const maxHours = Math.max(...weeklyStudyData.map(d => d.hours));

  // Mastery percentage by subject
  const subjectsMastery = [
    { subject: 'Cellular Biology', mastery: 82, color: 'bg-emerald-500' },
    { subject: 'Calculus II', mastery: 68, color: 'bg-violet-500' },
    { subject: 'Data Structures', mastery: 88, color: 'bg-cyan-500' },
    { subject: 'Microeconomics', mastery: 74, color: 'bg-amber-500' },
  ];

  const greetingTime = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* 1. Welcome & Gamification Banner */}
      <div className="relative rounded-3xl p-6 sm:p-8 bg-gradient-to-r from-violet-950/70 via-indigo-950/60 to-slate-900 border border-violet-500/30 overflow-hidden shadow-xl">
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-violet-600/15 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 relative z-10">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-violet-500/20 text-violet-300 border border-violet-500/30">
                {user?.educationLevel ? user.educationLevel.replace('_', ' ') : 'Undergraduate'}
              </span>
              <span className="text-xs text-slate-400">• {user?.institution || 'Academic Scholar'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {greetingTime()}, {user?.name || 'Alex'}! 👋
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
              You are on a <span className="text-amber-400 font-bold">{user?.streakDays || 7}-day learning streak</span>. Maintain momentum to reach Level {(user?.level || 6) + 1} Scholar!
            </p>
          </div>

          {/* Gamification Stats Card */}
          <div className="flex items-center gap-3 sm:gap-4 shrink-0 bg-slate-950/70 p-3.5 sm:p-4 rounded-2xl border border-slate-800">
            {/* Streak */}
            <div className="text-center px-2 sm:px-3 border-r border-slate-800">
              <div className="flex items-center justify-center gap-1 text-amber-400 mb-0.5">
                <Flame className="w-5 h-5 fill-amber-400" />
                <span className="text-base font-extrabold">{user?.streakDays || 7}</span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">Streak</p>
            </div>

            {/* Level & XP */}
            <div className="text-center px-2 sm:px-3">
              <div className="flex items-center justify-center gap-1 text-violet-400 mb-0.5">
                <Award className="w-5 h-5" />
                <span className="text-base font-extrabold">Lvl {user?.level || 6}</span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">{user?.totalXp || 1850} XP</p>
            </div>

            {/* Next Level Progress */}
            <div className="w-24 hidden sm:block">
              <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                <span>Lvl {(user?.level || 6) + 1}</span>
                <span>{((user?.totalXp || 1850) % 300)}/300</span>
              </div>
              <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-violet-500 to-cyan-400 rounded-full"
                  style={{ width: `${Math.min(100, (((user?.totalXp || 1850) % 300) / 300) * 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-6 mt-6 border-t border-slate-800/80">
          <button
            onClick={() => setActiveTab('tutor')}
            className="flex items-center gap-2.5 p-2.5 rounded-xl bg-violet-600/20 border border-violet-500/30 text-violet-300 hover:bg-violet-600/30 transition text-xs font-semibold cursor-pointer"
          >
            <Bot className="w-4 h-4 text-violet-400" />
            <span>Ask AI Tutor</span>
          </button>

          <button
            onClick={() => setActiveTab('notes')}
            className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-200 hover:bg-slate-800 transition text-xs font-semibold cursor-pointer"
          >
            <FilePlus className="w-4 h-4 text-emerald-400" />
            <span>New Note</span>
          </button>

          <button
            onClick={() => setActiveTab('planner')}
            className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-200 hover:bg-slate-800 transition text-xs font-semibold cursor-pointer"
          >
            <Play className="w-4 h-4 text-rose-400" />
            <span>Start Pomodoro</span>
          </button>

          <button
            onClick={() => setActiveTab('revision')}
            className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-200 hover:bg-slate-800 transition text-xs font-semibold cursor-pointer"
          >
            <Brain className="w-4 h-4 text-amber-400" />
            <span>Flashcard Review</span>
          </button>
        </div>
      </div>

      {/* 2. Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols wide on desktop): Study Plan & Tasks & Weekly Analytics */}
        <div className="lg:col-span-2 space-y-6">
          {/* Today's Study Plan & Focus Schedule */}
          <div className="p-5 sm:p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-violet-400" />
                <h3 className="text-sm font-bold text-white">Today&apos;s High-Priority Study Plan</h3>
              </div>
              <button
                onClick={() => setActiveTab('planner')}
                className="text-xs text-violet-400 hover:text-violet-300 flex items-center gap-1 font-semibold"
              >
                <span>View Full Calendar</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2.5">
              {pendingTasks.map(t => (
                <div
                  key={t.id}
                  className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80 hover:border-slate-700 transition"
                >
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => toggleTask(t.id)}
                      className={`w-5 h-5 rounded-lg border flex items-center justify-center transition cursor-pointer ${
                        t.completed
                          ? 'bg-emerald-500 border-emerald-500 text-white'
                          : 'border-slate-700 hover:border-violet-500 text-transparent'
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    </button>
                    <div>
                      <p className={`text-xs font-semibold ${t.completed ? 'line-through text-slate-500' : 'text-slate-100'}`}>
                        {t.title}
                      </p>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                        <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-300">{t.subject}</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-slate-500" /> {t.estimatedMinutes} min
                        </span>
                      </div>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded-full capitalize ${
                      t.priority === 'urgent'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : t.priority === 'high'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {t.priority}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Weekly Study-Time Distribution Chart */}
          <div className="p-5 sm:p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-bold text-white">Weekly Focus Time (25.7 Hours Total)</h3>
              </div>
              <span className="text-[11px] text-emerald-400 font-semibold bg-emerald-500/10 px-2 py-0.5 rounded-full">
                +18% vs last week
              </span>
            </div>

            {/* Visual Bar Graph */}
            <div className="pt-4 flex items-end justify-between gap-2 h-36 border-b border-slate-800 pb-2">
              {weeklyStudyData.map(item => {
                const heightPercent = (item.hours / maxHours) * 100;
                const isToday = item.day.includes('Today');

                return (
                  <div key={item.day} className="flex-1 flex flex-col items-center gap-1 group">
                    <span className="text-[10px] font-mono text-slate-400 opacity-0 group-hover:opacity-100 transition">
                      {item.hours}h
                    </span>
                    <div className="w-full max-w-[36px] bg-slate-800 rounded-t-xl overflow-hidden h-24 flex items-end">
                      <div
                        className={`w-full rounded-t-xl transition-all duration-500 ${
                          isToday
                            ? 'bg-gradient-to-t from-violet-600 to-cyan-400'
                            : 'bg-gradient-to-t from-indigo-700 to-violet-500 group-hover:from-violet-500 group-hover:to-cyan-400'
                        }`}
                        style={{ height: `${heightPercent}%` }}
                      />
                    </div>
                    <span className={`text-[10px] mt-1 font-medium ${isToday ? 'text-violet-400 font-bold' : 'text-slate-500'}`}>
                      {item.day.slice(0, 3)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Recently Opened Notes & Courses */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Notes */}
            <div className="p-4 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-emerald-400" /> Recent Study Notes
                </span>
                <button onClick={() => setActiveTab('notes')} className="text-[10px] text-violet-400 hover:underline">
                  All ({notes.length})
                </button>
              </div>

              <div className="space-y-2">
                {notes.slice(0, 2).map(n => (
                  <div
                    key={n.id}
                    onClick={() => setActiveTab('notes')}
                    className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                  >
                    <p className="text-xs font-semibold text-slate-200 truncate">{n.title}</p>
                    <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
                      <span>{n.subject}</span>
                      <span>{n.updatedAt.split('T')[0]}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Courses */}
            <div className="p-4 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-indigo-400" /> Active Course
                </span>
                <button onClick={() => setActiveTab('courses')} className="text-[10px] text-violet-400 hover:underline">
                  Catalog
                </button>
              </div>

              {courses[0] && (
                <div
                  onClick={() => {
                    setSelectedCourseId(courses[0].id);
                    setActiveTab('courses');
                  }}
                  className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                >
                  <p className="text-xs font-semibold text-slate-200 truncate">{courses[0].title}</p>
                  <div className="mt-2">
                    <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                      <span>Progress</span>
                      <span>{courses[0].progressPercent}%</span>
                    </div>
                    <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${courses[0].progressPercent}%` }} />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Subject Mastery & Daily Missions & Exam Alerts */}
        <div className="space-y-6">
          {/* Upcoming Examinations Countdown */}
          <div className="p-5 rounded-3xl bg-gradient-to-br from-rose-950/40 via-slate-900 to-slate-900 border border-rose-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-rose-300 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-rose-400" /> Examination Countdown
              </span>
              <span className="text-[10px] bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded-full font-bold">5 Days Left</span>
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Cellular Biology Midterm</h4>
              <p className="text-xs text-slate-400 mt-0.5">Enzyme Kinetics, Glycolysis, and ETC Chemiosmosis.</p>
            </div>
            <button
              onClick={() => {
                setSelectedSubject('Cellular Biology');
                setActiveTab('revision');
              }}
              className="w-full py-2 rounded-xl bg-rose-600/30 hover:bg-rose-600/40 border border-rose-500/40 text-rose-200 text-xs font-semibold transition"
            >
              Start High-Yield Revision Session
            </button>
          </div>

          {/* Subject Mastery Radar / Bars */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Subject Mastery Tracker</h3>
            <div className="space-y-3">
              {subjectsMastery.map(sm => (
                <div key={sm.subject} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-200">{sm.subject}</span>
                    <span className="font-mono text-slate-400">{sm.mastery}%</span>
                  </div>
                  <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className={`h-full ${sm.color} rounded-full`} style={{ width: `${sm.mastery}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Daily Missions */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Daily Missions</h3>
              <span className="text-[10px] text-amber-400 font-bold">+180 XP Available</span>
            </div>
            <div className="space-y-2">
              {dailyMissions.map(m => (
                <div
                  key={m.id}
                  className={`p-2.5 rounded-xl border flex items-center justify-between text-xs ${
                    m.completed
                      ? 'bg-slate-950/40 border-slate-800 text-slate-500'
                      : 'bg-slate-950/80 border-slate-800 text-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span>{m.icon}</span>
                    <span className={m.completed ? 'line-through' : ''}>{m.title}</span>
                  </div>
                  <span className={`text-[10px] font-bold ${m.completed ? 'text-slate-600' : 'text-amber-400'}`}>
                    +{m.rewardXp} XP
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
