import React, { useState, useEffect } from 'react';
import { Search, X, BookOpen, FileText, Brain, Users, ArrowRight } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const GlobalSearchModal: React.FC = () => {
  const {
    isSearchOpen,
    setIsSearchOpen,
    courses,
    notes,
    flashcards,
    communityPosts,
    setActiveTab,
    setSelectedCourseId,
  } = useApp();

  const [query, setQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'courses' | 'notes' | 'flashcards' | 'community'>('all');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(!isSearchOpen);
      }
      if (e.key === 'Escape') {
        setIsSearchOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSearchOpen, setIsSearchOpen]);

  if (!isSearchOpen) return null;

  const q = query.toLowerCase().trim();

  const matchedCourses = courses.filter(
    c => c.title.toLowerCase().includes(q) || c.subject.toLowerCase().includes(q) || c.description.toLowerCase().includes(q)
  );

  const matchedNotes = notes.filter(
    n => n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q) || n.subject.toLowerCase().includes(q)
  );

  const matchedFlashcards = flashcards.filter(
    f => f.question.toLowerCase().includes(q) || f.answer.toLowerCase().includes(q) || f.subject.toLowerCase().includes(q)
  );

  const matchedPosts = communityPosts.filter(
    p => p.title.toLowerCase().includes(q) || p.content.toLowerCase().includes(q) || p.subject.toLowerCase().includes(q)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-black/70 backdrop-blur-sm" onClick={() => setIsSearchOpen(false)}>
      <div
        className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl overflow-hidden flex flex-col text-slate-100 max-h-[80vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-800 flex items-center gap-3">
          <Search className="w-5 h-5 text-violet-400 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search courses, lessons, notes, flashcards, discussions..."
            autoFocus
            className="w-full bg-transparent text-sm sm:text-base outline-none text-white placeholder-slate-500 font-sans"
          />
          {query && (
            <button onClick={() => setQuery('')} className="text-slate-400 hover:text-white p-1">
              <X className="w-4 h-4" />
            </button>
          )}
          <kbd className="hidden sm:inline-block px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-400 border border-slate-700">ESC</kbd>
        </div>

        {/* Filter Chips */}
        <div className="px-4 py-2 border-b border-slate-800/80 bg-slate-950/40 flex items-center gap-2 overflow-x-auto text-xs">
          {(['all', 'courses', 'notes', 'flashcards', 'community'] as const).map(type => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-3 py-1 rounded-xl capitalize font-medium transition cursor-pointer shrink-0 ${
                filterType === type
                  ? 'bg-violet-600 text-white shadow-sm'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {type}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {(!query && filterType === 'all') && (
            <div className="text-center py-10 text-slate-500 text-xs">
              Type keywords like &quot;Cellular&quot;, &quot;Calculus&quot;, &quot;Enzyme&quot;, or &quot;Algorithms&quot; to search the StudySphere ecosystem.
            </div>
          )}

          {/* Courses */}
          {(filterType === 'all' || filterType === 'courses') && matchedCourses.length > 0 && (
            <div>
              <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-indigo-400" /> Courses ({matchedCourses.length})
              </p>
              <div className="space-y-1.5">
                {matchedCourses.map(course => (
                  <button
                    key={course.id}
                    onClick={() => {
                      setSelectedCourseId(course.id);
                      setActiveTab('courses');
                      setIsSearchOpen(false);
                    }}
                    className="w-full flex items-center justify-between p-3 rounded-2xl bg-slate-950/60 border border-slate-800 hover:border-violet-500/50 hover:bg-slate-800/50 transition group text-left"
                  >
                    <div>
                      <p className="text-xs font-semibold text-white group-hover:text-violet-300 transition-colors">{course.title}</p>
                      <p className="text-[11px] text-slate-400 line-clamp-1">{course.description}</p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-violet-400 shrink-0 ml-2" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Notes */}
          {(filterType === 'all' || filterType === 'notes') && matchedNotes.length > 0 && (
            <div>
              <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-emerald-400" /> Notes ({matchedNotes.length})
              </p>
              <div className="space-y-1.5">
                {matchedNotes.map(note => (
                  <button
                    key={note.id}
                    onClick={() => {
                      setActiveTab('notes');
                      setIsSearchOpen(false);
                    }}
                    className="w-full flex items-center justify-between p-3 rounded-2xl bg-slate-950/60 border border-slate-800 hover:border-emerald-500/50 hover:bg-slate-800/50 transition group text-left"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-xs font-semibold text-white group-hover:text-emerald-300 transition-colors">{note.title}</p>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">{note.subject}</span>
                      </div>
                      <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">{note.content.slice(0, 100)}</p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 shrink-0 ml-2" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Flashcards */}
          {(filterType === 'all' || filterType === 'flashcards') && matchedFlashcards.length > 0 && (
            <div>
              <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Brain className="w-3.5 h-3.5 text-amber-400" /> Flashcards ({matchedFlashcards.length})
              </p>
              <div className="space-y-1.5">
                {matchedFlashcards.map(fc => (
                  <button
                    key={fc.id}
                    onClick={() => {
                      setActiveTab('revision');
                      setIsSearchOpen(false);
                    }}
                    className="w-full flex items-center justify-between p-3 rounded-2xl bg-slate-950/60 border border-slate-800 hover:border-amber-500/50 hover:bg-slate-800/50 transition group text-left"
                  >
                    <div>
                      <p className="text-xs font-semibold text-white group-hover:text-amber-300 transition-colors">{fc.question}</p>
                      <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">{fc.answer}</p>
                    </div>
                    <span className="text-[10px] text-slate-500 shrink-0 ml-2">{fc.subject}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Community */}
          {(filterType === 'all' || filterType === 'community') && matchedPosts.length > 0 && (
            <div>
              <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-cyan-400" /> Community Discussions ({matchedPosts.length})
              </p>
              <div className="space-y-1.5">
                {matchedPosts.map(post => (
                  <button
                    key={post.id}
                    onClick={() => {
                      setActiveTab('community');
                      setIsSearchOpen(false);
                    }}
                    className="w-full flex items-center justify-between p-3 rounded-2xl bg-slate-950/60 border border-slate-800 hover:border-cyan-500/50 hover:bg-slate-800/50 transition group text-left"
                  >
                    <div>
                      <p className="text-xs font-semibold text-white group-hover:text-cyan-300 transition-colors">{post.title}</p>
                      <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">By {post.authorName} • {post.likes} likes</p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 shrink-0 ml-2" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {query && matchedCourses.length === 0 && matchedNotes.length === 0 && matchedFlashcards.length === 0 && matchedPosts.length === 0 && (
            <div className="text-center py-12 text-slate-500 text-xs">
              No matching records found for &quot;{query}&quot;. Try broadening your keywords.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
