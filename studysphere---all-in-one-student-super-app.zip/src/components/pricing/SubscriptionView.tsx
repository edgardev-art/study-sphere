import React, { useState } from 'react';
import {
  CreditCard,
  CheckCircle2,
  Sparkles,
  Smartphone,
  ShieldCheck,
  Zap,
  HelpCircle,
  FileCheck,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { SubscriptionTier } from '../../types';

export const SubscriptionView: React.FC = () => {
  const { user, updateSubscription } = useApp();

  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [currency, setCurrency] = useState<'USD' | 'KES' | 'EUR' | 'GBP'>('USD');
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionTier>('pro');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'mpesa'>('card');
  const [mpesaPhone, setMpesaPhone] = useState('254712345678');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  const rates: Record<string, { symbol: string; rate: number }> = {
    USD: { symbol: '$', rate: 1 },
    KES: { symbol: 'KSh ', rate: 130 },
    EUR: { symbol: '€', rate: 0.92 },
    GBP: { symbol: '£', rate: 0.78 },
  };

  const getPrice = (usdAmount: number) => {
    const adjusted = billingCycle === 'yearly' ? usdAmount * 0.8 : usdAmount;
    const converted = Math.round(adjusted * rates[currency].rate);
    return `${rates[currency].symbol}${converted.toLocaleString()}`;
  };

  const handleOpenCheckout = (tier: SubscriptionTier) => {
    setSelectedPlan(tier);
    setIsCheckoutOpen(true);
    setPaymentSuccess(false);
  };

  const handleSimulatePayment = () => {
    setIsProcessingPayment(true);
    setTimeout(() => {
      setIsProcessingPayment(false);
      setPaymentSuccess(true);
      updateSubscription(selectedPlan);
      setTimeout(() => {
        setIsCheckoutOpen(false);
      }, 2000);
    }, 2000);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <span className="text-xs font-bold uppercase tracking-wider text-violet-400">Upgrade Your Academic Arsenal</span>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
          Flexible Plans for Every Student
        </h1>
        <p className="text-xs sm:text-sm text-slate-300">
          Unlock unlimited Socratic reasoning, advanced timetable generation, and deep performance analytics.
        </p>

        {/* Controls: Billing Cycle + Currency */}
        <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
          <div className="flex rounded-2xl bg-slate-900 p-1 border border-slate-800 text-xs">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-4 py-1.5 rounded-xl font-semibold transition cursor-pointer ${
                billingCycle === 'monthly' ? 'bg-violet-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Monthly Billing
            </button>
            <button
              onClick={() => setBillingCycle('yearly')}
              className={`px-4 py-1.5 rounded-xl font-semibold transition cursor-pointer flex items-center gap-1 ${
                billingCycle === 'yearly' ? 'bg-violet-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>Annual (Save 20%)</span>
              <span className="text-[10px] text-amber-300">🎁</span>
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Currency:</span>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as any)}
              className="px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs outline-none"
            >
              <option value="USD">USD ($)</option>
              <option value="KES">KES (M-Pesa KSh)</option>
              <option value="EUR">EUR (€)</option>
              <option value="GBP">GBP (£)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Pricing Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Free Plan */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div>
              <h3 className="text-base font-bold text-white">Free Plan</h3>
              <p className="text-xs text-slate-400">Core study tools for independent learners.</p>
            </div>
            <div className="text-3xl font-extrabold text-white">
              {rates[currency].symbol}0
              <span className="text-xs text-slate-400 font-normal"> / {billingCycle === 'monthly' ? 'mo' : 'yr'}</span>
            </div>

            <ul className="space-y-2.5 text-xs text-slate-300">
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Basic course access</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Standard AI tutor answers</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Unlimited digital notes</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Spaced repetition flashcards</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Public community access</li>
            </ul>
          </div>

          <button
            disabled={user?.tier === 'free'}
            onClick={() => handleOpenCheckout('free')}
            className="w-full py-2.5 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition disabled:opacity-50"
          >
            {user?.tier === 'free' ? 'Current Active Plan' : 'Downgrade to Free'}
          </button>
        </div>

        {/* Pro Plan */}
        <div className="p-6 rounded-3xl bg-gradient-to-b from-violet-950/70 to-slate-900 border-2 border-violet-500 flex flex-col justify-between space-y-6 relative shadow-xl shadow-violet-900/40">
          <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-violet-600 text-white text-[10px] font-bold uppercase tracking-wider">
            Most Popular
          </span>

          <div className="space-y-4">
            <div>
              <h3 className="text-base font-bold text-white">Pro Scholar</h3>
              <p className="text-xs text-violet-300">Targeted for college & exam candidates.</p>
            </div>
            <div className="text-3xl font-extrabold text-white">
              {getPrice(9.99)}
              <span className="text-xs text-slate-400 font-normal"> / {billingCycle === 'monthly' ? 'mo' : 'yr'}</span>
            </div>

            <ul className="space-y-2.5 text-xs text-slate-200">
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-violet-400" /> Everything in Free</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-violet-400" /> Higher AI tutor quota & reasoning</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-violet-400" /> AI-generated revision timetables</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-violet-400" /> Instant quiz & flashcard extraction</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-violet-400" /> Weakness diagnostic analytics</li>
            </ul>
          </div>

          <button
            onClick={() => handleOpenCheckout('pro')}
            className="w-full py-3 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold transition shadow-lg shadow-violet-900/50 cursor-pointer"
          >
            {user?.tier === 'pro' ? 'Current Active Plan' : 'Upgrade to Pro'}
          </button>
        </div>

        {/* Premium Plan */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div>
              <h3 className="text-base font-bold text-white">Ultimate Academic</h3>
              <p className="text-xs text-slate-400">For multi-subject mastery & grad entry.</p>
            </div>
            <div className="text-3xl font-extrabold text-white">
              {getPrice(19.99)}
              <span className="text-xs text-slate-400 font-normal"> / {billingCycle === 'monthly' ? 'mo' : 'yr'}</span>
            </div>

            <ul className="space-y-2.5 text-xs text-slate-300">
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Everything in Pro</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Unlimited AI tutor requests</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Full mock exam predictor drills</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Private virtual study room hosting</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Priority educator support</li>
            </ul>
          </div>

          <button
            onClick={() => handleOpenCheckout('premium')}
            className="w-full py-2.5 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition"
          >
            {user?.tier === 'premium' ? 'Current Active Plan' : 'Upgrade to Ultimate'}
          </button>
        </div>
      </div>

      {/* Billing History Record Table */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Recent Payment & Invoicing History</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead>
              <tr className="border-b border-slate-800 text-slate-500">
                <th className="pb-2">Invoice ID</th>
                <th className="pb-2">Date</th>
                <th className="pb-2">Plan</th>
                <th className="pb-2">Amount</th>
                <th className="pb-2">Method</th>
                <th className="pb-2">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              <tr>
                <td className="py-2.5 font-mono text-slate-400">INV-2026-904</td>
                <td className="py-2.5">2026-10-01</td>
                <td className="py-2.5">Pro Scholar (Monthly)</td>
                <td className="py-2.5 font-mono">$9.99</td>
                <td className="py-2.5">Card •••• 4242</td>
                <td className="py-2.5 text-emerald-400 font-semibold">Paid (Verified)</td>
              </tr>
              <tr>
                <td className="py-2.5 font-mono text-slate-400">INV-2026-812</td>
                <td className="py-2.5">2026-09-01</td>
                <td className="py-2.5">Pro Scholar (Monthly)</td>
                <td className="py-2.5 font-mono">$9.99</td>
                <td className="py-2.5">M-Pesa STK Push</td>
                <td className="py-2.5 text-emerald-400 font-semibold">Paid (Verified)</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Simulated Checkout Modal */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={() => setIsCheckoutOpen(false)}>
          <div
            className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 shadow-2xl text-slate-100 space-y-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold text-white">Secure Checkout Simulator</h3>
              </div>
              <button onClick={() => setIsCheckoutOpen(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            {paymentSuccess ? (
              <div className="py-8 text-center space-y-3">
                <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
                <h4 className="text-base font-bold text-white">Payment Verified!</h4>
                <p className="text-xs text-slate-400">
                  Your account has been upgraded to StudySphere {selectedPlan.toUpperCase()}. Happy studying!
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-3.5 rounded-2xl bg-violet-950/30 border border-violet-500/30 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-white">Selected Plan: {selectedPlan.toUpperCase()}</span>
                    <p className="text-[10px] text-slate-400">Billed {billingCycle}</p>
                  </div>
                  <span className="text-base font-bold text-violet-300 font-mono">
                    {selectedPlan === 'free' ? '$0' : selectedPlan === 'pro' ? getPrice(9.99) : getPrice(19.99)}
                  </span>
                </div>

                {/* Method Switch: Card vs M-Pesa */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">Payment Method</label>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('card')}
                      className={`p-2.5 rounded-xl border flex items-center justify-center gap-2 font-semibold transition cursor-pointer ${
                        paymentMethod === 'card'
                          ? 'bg-violet-600/30 border-violet-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      <CreditCard className="w-4 h-4" />
                      <span>Credit Card</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('mpesa')}
                      className={`p-2.5 rounded-xl border flex items-center justify-center gap-2 font-semibold transition cursor-pointer ${
                        paymentMethod === 'mpesa'
                          ? 'bg-emerald-600/30 border-emerald-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      <Smartphone className="w-4 h-4 text-emerald-400" />
                      <span>M-Pesa Express</span>
                    </button>
                  </div>
                </div>

                {paymentMethod === 'card' ? (
                  <div className="space-y-2.5 text-xs">
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-1">Card Number (Simulated)</label>
                      <input
                        type="text"
                        defaultValue="4242 •••• •••• 4242"
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        defaultValue="12/28"
                        placeholder="MM/YY"
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono"
                      />
                      <input
                        type="text"
                        defaultValue="888"
                        placeholder="CVC"
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2.5 text-xs">
                    <label className="block text-[10px] text-slate-400 mb-1">M-Pesa Mobile Number for STK Push</label>
                    <input
                      type="text"
                      value={mpesaPhone}
                      onChange={(e) => setMpesaPhone(e.target.value)}
                      placeholder="e.g. 254712345678"
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono"
                    />
                    <p className="text-[10px] text-slate-400">
                      An STK PIN prompt will be sent to this phone to authorize payment.
                    </p>
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleSimulatePayment}
                  disabled={isProcessingPayment}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 disabled:opacity-50 text-white font-bold text-xs transition shadow-lg shadow-violet-900/40 cursor-pointer flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{isProcessingPayment ? 'Verifying with Provider...' : 'Confirm Simulated Payment'}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
