import React, { useState } from 'react';
import {
  LayoutDashboard,
  Bot,
  BookOpen,
  FileText,
  CalendarCheck,
  MoreHorizontal,
  Brain,
  Users,
  Video,
  CreditCard,
  Settings,
  ShieldAlert,
  X,
} from 'lucide-react';
import { useApp, ActiveTab } from '../../context/AppContext';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, user } = useApp();
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  const primaryTabs: Array<{ id: ActiveTab; label: string; icon: React.FC<{ className?: string }> }> = [
    { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
    { id: 'tutor', label: 'AI Tutor', icon: Bot },
    { id: 'courses', label: 'Courses', icon: BookOpen },
    { id: 'notes', label: 'Notes', icon: FileText },
    { id: 'planner', label: 'Planner', icon: CalendarCheck },
  ];

  const moreItems: Array<{ id: ActiveTab; label: string; icon: React.FC<{ className?: string }> }> = [
    { id: 'revision', label: 'Flashcards & Quizzes', icon: Brain },
    { id: 'community', label: 'Student Community', icon: Users },
    { id: 'study-rooms', label: 'Live Study Rooms', icon: Video },
    { id: 'pricing', label: 'Subscription & Plans', icon: CreditCard },
    { id: 'profile', label: 'Profile & Settings', icon: Settings },
  ];

  if (user?.role === 'admin') {
    moreItems.push({ id: 'admin', label: 'Admin Console', icon: ShieldAlert });
  }

  const handleSelect = (tab: ActiveTab) => {
    setActiveTab(tab);
    setShowMoreMenu(false);
  };

  const isMoreActive = moreItems.some(i => i.id === activeTab);

  return (
    <>
      {/* Bottom Sheet for "More" menu */}
      {showMoreMenu && (
        <div className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs flex items-end justify-center" onClick={() => setShowMoreMenu(false)}>
          <div
            className="w-full max-w-lg bg-slate-900 border-t border-slate-700/80 rounded-t-3xl p-5 shadow-2xl space-y-4 animate-in slide-in-from-bottom-5 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-sm font-semibold text-white">More StudySphere Modules</span>
              <button
                onClick={() => setShowMoreMenu(false)}
                className="p-1 rounded-full text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {moreItems.map(item => {
                const Icon = item.icon;
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelect(item.id)}
                    className={`flex items-center gap-3 p-3 rounded-2xl text-left text-xs font-medium border transition ${
                      active
                        ? 'bg-violet-600/20 border-violet-500/50 text-violet-300'
                        : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div className="p-2 rounded-xl bg-slate-800 text-violet-400">
                      <Icon className="w-4 h-4" />
                    </div>
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Persistent Bottom Bar */}
      <nav className="h-16 border-t border-slate-800/80 bg-slate-950/95 backdrop-blur-lg px-2 flex items-center justify-around z-30 shrink-0 select-none">
        {primaryTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id && !showMoreMenu;

          return (
            <button
              key={tab.id}
              onClick={() => { setShowMoreMenu(false); setActiveTab(tab.id); }}
              className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer ${
                isActive ? 'text-violet-400 scale-105' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon className="w-5 h-5" />
                {tab.id === 'tutor' && (
                  <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-violet-500 animate-ping" />
                )}
              </div>
              <span className={`text-[10px] mt-1 font-medium ${isActive ? 'font-semibold text-white' : ''}`}>
                {tab.label}
              </span>
            </button>
          );
        })}

        {/* More Tab */}
        <button
          onClick={() => setShowMoreMenu(!showMoreMenu)}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer ${
            showMoreMenu || isMoreActive ? 'text-violet-400 scale-105' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <MoreHorizontal className="w-5 h-5" />
          <span className={`text-[10px] mt-1 font-medium ${showMoreMenu || isMoreActive ? 'font-semibold text-white' : ''}`}>
            More
          </span>
        </button>
      </nav>
    </>
  );
};
