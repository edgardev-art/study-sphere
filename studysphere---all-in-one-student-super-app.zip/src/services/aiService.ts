export interface TutorMessage {
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  style?: string;
  subject?: string;
}

export async function askAITutor(params: {
  message: string;
  style: 'simple' | 'detailed' | 'exam_prep' | 'socratic';
  subject: string;
  history?: TutorMessage[];
  educationLevel?: string;
}): Promise<{ reply: string; isFallback: boolean }> {
  try {
    const res = await fetch('/api/gemini/tutor', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });

    if (!res.ok) {
      throw new Error(`Server returned ${res.status}`);
    }

    const data = await res.json();
    return {
      reply: data.reply || 'No answer generated.',
      isFallback: !!data.isFallback,
    };
  } catch (err) {
    console.warn('AI tutor request fell back to local generation:', err);
    // Graceful offline/local answer
    return {
      reply: `I analyzed your question regarding **${params.subject}**:\n\n"${params.message}"\n\n### Core Academic Insight:\nWhen approaching this concept, examine the fundamental governing principles first. In ${params.subject}, break down the equation or biological mechanism into individual stages.\n\n*Would you like to test this with a practice problem or delve into a specific proof?*`,
      isFallback: true,
    };
  }
}

export async function generateNotesSummary(params: {
  noteTitle: string;
  noteContent: string;
  subject: string;
}): Promise<{
  summary: string;
  keyPoints: string[];
  flashcards: Array<{ question: string; answer: string }>;
  isFallback: boolean;
}> {
  try {
    const res = await fetch('/api/gemini/generate-notes-summary', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });

    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('Notes summary fell back to local fallback:', err);
    return {
      summary: `### Executive Study Summary: ${params.noteTitle}\nThese notes detail fundamental laws and operational definitions in ${params.subject}. Key emphasis should be placed on relationship equations and analytical deductions.`,
      keyPoints: [
        'Review the key definitions and formulas in these notes',
        'Check boundary conditions and common exam edge cases',
        'Solve 2 practice problems utilizing these concepts'
      ],
      flashcards: [
        { question: `What is the core premise of "${params.noteTitle}"?`, answer: 'The fundamental relationship between the underlying variables and their active application.' }
      ],
      isFallback: true,
    };
  }
}

export async function generateQuizFromAI(params: {
  topic: string;
  subject: string;
  difficulty?: 'easy' | 'medium' | 'hard';
  count?: number;
}): Promise<{
  topic: string;
  questions: Array<{
    id: string;
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  }>;
  isFallback: boolean;
}> {
  try {
    const res = await fetch('/api/gemini/generate-quiz', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });

    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('Quiz generator fell back:', err);
    return {
      topic: params.topic,
      questions: [
        {
          id: 'fb-q1',
          question: `In ${params.subject}, what is the critical relationship involved in ${params.topic}?`,
          options: [
            'Proportional response with negative feedback loop',
            'Independent random divergence',
            'Constant invariant dissipation',
            'None of the above'
          ],
          correctIndex: 0,
          explanation: 'Standard systems rely on proportional response and homeostatic or stable equilibrium.'
        },
        {
          id: 'fb-q2',
          question: `Which methodology provides the highest retention when reviewing ${params.topic}?`,
          options: [
            'Re-reading highlighted notes passively',
            'Active recall testing and flashcard spaced repetition',
            'Skimming textbook summaries',
            'Listening to lecture audio while asleep'
          ],
          correctIndex: 1,
          explanation: 'Active recall and spaced repetition are supported by extensive cognitive research as the most durable study methods.'
        }
      ],
      isFallback: true,
    };
  }
}

export async function generateStudyPlanFromAI(params: {
  subjects: string[];
  dailyHours: number;
  exams: string[];
  targetGoal: string;
}) {
  try {
    const res = await fetch('/api/gemini/generate-study-plan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });

    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('Study plan generator fell back:', err);
    return {
      planTitle: 'Smart High-Yield Academic Schedule',
      strategy: `Balanced distribution of ${params.dailyHours} hours/day across target subjects with built-in active recall and rest buffers.`,
      blocks: [
        { day: 'Monday', focus: params.subjects[0] || 'Core Subject 1', duration: '90 mins', activity: 'In-depth conceptual study & problem sets', priority: 'High' },
        { day: 'Tuesday', focus: params.subjects[1] || 'Core Subject 2', duration: '90 mins', activity: 'Flashcard revision & past paper drills', priority: 'High' },
        { day: 'Wednesday', focus: params.subjects[0] || 'Core Subject 1', duration: '60 mins', activity: 'Timed quiz and error log review', priority: 'Medium' },
        { day: 'Thursday', focus: params.subjects[2] || 'Humanities / Electives', duration: '90 mins', activity: 'Essay structure & practice questions', priority: 'Medium' },
        { day: 'Friday', focus: 'Synthesis Review', duration: '60 mins', activity: 'Cross-subject flashcards & summary synthesis', priority: 'Medium' },
        { day: 'Saturday', focus: 'Exam Simulation', duration: '120 mins', activity: 'Full mock exam under real timed conditions', priority: 'High' },
        { day: 'Sunday', focus: 'Weekly Reset & Planning', duration: '30 mins', activity: 'Organize upcoming priorities and clear backlogs', priority: 'Low' },
      ],
      recommendations: [
        'Use Pomodoro 25/5 intervals to prevent cognitive fatigue',
        'Log errors in your StudySphere digital notebook immediately',
        'Review flashcards during daily commutes or transition breaks'
      ],
      isFallback: true,
    };
  }
}
