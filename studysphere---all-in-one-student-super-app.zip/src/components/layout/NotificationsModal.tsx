import React from 'react';
import { X, CheckCheck, Flame, Calendar, Award, MessageSquare, CreditCard, Bell } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const NotificationsModal: React.FC = () => {
  const {
    isNotificationsOpen,
    setIsNotificationsOpen,
    notifications,
    markNotificationRead,
    clearAllNotifications,
    setActiveTab,
  } = useApp();

  if (!isNotificationsOpen) return null;

  const getIcon = (type: string) => {
    switch (type) {
      case 'streak': return <Flame className="w-4 h-4 text-amber-400" />;
      case 'exam': return <Calendar className="w-4 h-4 text-rose-400" />;
      case 'achievement': return <Award className="w-4 h-4 text-violet-400" />;
      case 'community': return <MessageSquare className="w-4 h-4 text-cyan-400" />;
      case 'billing': return <CreditCard className="w-4 h-4 text-emerald-400" />;
      default: return <Bell className="w-4 h-4 text-indigo-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-end pt-16 pr-4 sm:pr-8 bg-black/40 backdrop-blur-xs" onClick={() => setIsNotificationsOpen(false)}>
      <div
        className="w-full max-w-sm bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col text-slate-100 max-h-[75vh]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-violet-400" />
            <span className="text-sm font-semibold text-white">Notifications</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={clearAllNotifications}
              className="text-[11px] text-violet-400 hover:text-violet-300 flex items-center gap-1"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>Mark all read</span>
            </button>
            <button onClick={() => setIsNotificationsOpen(false)} className="text-slate-400 hover:text-white p-1">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {notifications.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-xs">
              All caught up! No new notifications.
            </div>
          ) : (
            notifications.map(n => (
              <div
                key={n.id}
                onClick={() => {
                  markNotificationRead(n.id);
                  if (n.actionUrl) {
                    setActiveTab(n.actionUrl as any);
                    setIsNotificationsOpen(false);
                  }
                }}
                className={`p-3 rounded-2xl border transition cursor-pointer ${
                  n.read
                    ? 'bg-slate-950/40 border-slate-800/80 opacity-70'
                    : 'bg-violet-950/20 border-violet-500/30 shadow-xs'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  <div className="p-2 rounded-xl bg-slate-800/80 shrink-0 mt-0.5">
                    {getIcon(n.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <p className="text-xs font-semibold text-white truncate">{n.title}</p>
                      <span className="text-[10px] text-slate-500 shrink-0">{n.timestamp}</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{n.message}</p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
