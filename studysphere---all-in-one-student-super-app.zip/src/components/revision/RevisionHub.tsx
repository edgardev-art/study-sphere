import React, { useState } from 'react';
import {
  Brain,
  HelpCircle,
  Sparkles,
  RotateCw,
  CheckCircle2,
  XCircle,
  Plus,
  Play,
  Clock,
  ArrowRight,
  TrendingUp,
  Award,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Flashcard, Quiz, QuizQuestion } from '../../types';
import { generateQuizFromAI } from '../../services/aiService';

export const RevisionHub: React.FC = () => {
  const {
    flashcards,
    reviewFlashcard,
    addFlashcard,
    quizzes,
    addQuiz,
    quizAttempts,
    addQuizAttempt,
    user,
  } = useApp();

  const [activeSection, setActiveSection] = useState<'flashcards' | 'quizzes' | 'ai_generator'>('flashcards');

  // Flashcard review state
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [isAddCardOpen, setIsAddCardOpen] = useState(false);
  const [newCardQ, setNewCardQ] = useState('');
  const [newCardA, setNewCardA] = useState('');
  const [newCardSubject, setNewCardSubject] = useState(user?.subjects[0] || 'General Studies');

  // Quiz active test state
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);

  // AI Quiz Generator state
  const [aiTopic, setAiTopic] = useState('');
  const [aiSubject, setAiSubject] = useState(user?.subjects[0] || 'Cellular Biology');
  const [aiDifficulty, setAiDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [isAiGenerating, setIsAiGenerating] = useState(false);

  const currentCard: Flashcard | undefined = flashcards[currentCardIndex];

  const handleNextCard = (rating: 'again' | 'hard' | 'good' | 'easy') => {
    if (currentCard) {
      reviewFlashcard(currentCard.id, rating);
    }
    setIsFlipped(false);
    if (currentCardIndex < flashcards.length - 1) {
      setCurrentCardIndex(prev => prev + 1);
    } else {
      setCurrentCardIndex(0);
      alert('🎉 Flashcard deck review completed! Great job strengthening your long-term memory.');
    }
  };

  const handleCreateCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCardQ.trim() || !newCardA.trim()) return;

    addFlashcard({
      subject: newCardSubject,
      deckId: 'deck-custom',
      question: newCardQ,
      answer: newCardA,
    });

    setNewCardQ('');
    setNewCardA('');
    setIsAddCardOpen(false);
  };

  const handleStartQuiz = (q: Quiz) => {
    setActiveQuiz(q);
    setSelectedAnswers({});
    setQuizSubmitted(false);
  };

  const handleSubmitQuiz = () => {
    if (!activeQuiz) return;
    let score = 0;
    const weakTopics: string[] = [];

    activeQuiz.questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctIndex) {
        score++;
      } else {
        weakTopics.push(activeQuiz.topic);
      }
    });

    addQuizAttempt({
      quizId: activeQuiz.id,
      quizTitle: activeQuiz.title,
      subject: activeQuiz.subject,
      score,
      totalQuestions: activeQuiz.questions.length,
      weakTopics: [...new Set(weakTopics)],
    });

    setQuizSubmitted(true);
  };

  const handleGenerateAiQuiz = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiTopic.trim()) return;
    setIsAiGenerating(true);

    try {
      const generated = await generateQuizFromAI({
        topic: aiTopic,
        subject: aiSubject,
        difficulty: aiDifficulty,
        count: 4,
      });

      const newQuiz: Quiz = {
        id: 'quiz-ai-' + Date.now(),
        title: `AI Assessment: ${generated.topic}`,
        subject: aiSubject,
        topic: generated.topic,
        difficulty: aiDifficulty,
        timeLimitMinutes: 10,
        questions: generated.questions,
      };

      addQuiz(newQuiz);
      setActiveQuiz(newQuiz);
      setSelectedAnswers({});
      setQuizSubmitted(false);
      setActiveSection('quizzes');
    } catch {
      alert('Failed to generate AI quiz.');
    } finally {
      setIsAiGenerating(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Brain className="w-6 h-6 text-violet-400" />
            <span>Quizzes, Flashcards & Exam Prep</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Active recall with spaced repetition intervals, timed practice exams, and weakness diagnostics.
          </p>
        </div>

        {/* Section Tabs */}
        <div className="flex rounded-2xl bg-slate-900 p-1 border border-slate-800 text-xs">
          <button
            onClick={() => { setActiveSection('flashcards'); setActiveQuiz(null); }}
            className={`px-4 py-2 rounded-xl font-semibold transition cursor-pointer ${
              activeSection === 'flashcards' ? 'bg-violet-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            Spaced Flashcards
          </button>
          <button
            onClick={() => setActiveSection('quizzes')}
            className={`px-4 py-2 rounded-xl font-semibold transition cursor-pointer ${
              activeSection === 'quizzes' ? 'bg-violet-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            Practice Tests
          </button>
          <button
            onClick={() => { setActiveSection('ai_generator'); setActiveQuiz(null); }}
            className={`px-4 py-2 rounded-xl font-semibold transition cursor-pointer flex items-center gap-1.5 ${
              activeSection === 'ai_generator' ? 'bg-violet-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-violet-400" />
            <span>AI Quiz Generator</span>
          </button>
        </div>
      </div>

      {/* 1. Flashcards View */}
      {activeSection === 'flashcards' && (
        <div className="max-w-3xl mx-auto space-y-6">
          <div className="flex items-center justify-between">
            <div className="text-xs text-slate-400">
              Card <strong className="text-white">{currentCardIndex + 1}</strong> of <strong className="text-white">{flashcards.length}</strong>
              <span className="ml-2 px-2 py-0.5 rounded-full bg-slate-900 border border-slate-800 text-violet-300">
                {currentCard?.subject}
              </span>
            </div>

            <button
              onClick={() => setIsAddCardOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-xs font-semibold transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Flashcard</span>
            </button>
          </div>

          {/* 3D Flip Card */}
          {currentCard ? (
            <div
              onClick={() => setIsFlipped(!isFlipped)}
              className="perspective-1000 min-h-[300px] sm:min-h-[360px] cursor-pointer"
            >
              <div
                className={`relative w-full h-full min-h-[300px] sm:min-h-[360px] transition-transform duration-500 transform-style-preserve-3d rounded-3xl p-8 border ${
                  isFlipped
                    ? 'rotate-y-180 bg-gradient-to-br from-violet-950/80 to-slate-900 border-violet-500/50 shadow-2xl shadow-violet-900/30'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700 shadow-xl'
                } flex flex-col justify-between`}
              >
                {/* Front (Question) */}
                <div className={`space-y-4 ${isFlipped ? 'hidden' : 'block'}`}>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">
                    Front • Question
                  </span>
                  <h3 className="text-base sm:text-xl font-bold text-white leading-relaxed">
                    {currentCard.question}
                  </h3>
                </div>

                {/* Back (Answer) */}
                <div className={`space-y-4 ${isFlipped ? 'block rotate-y-180' : 'hidden'}`}>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-violet-400">
                    Back • High-Yield Answer
                  </span>
                  <p className="text-sm sm:text-base text-slate-200 leading-relaxed font-sans">
                    {currentCard.answer}
                  </p>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 pt-4 border-t border-slate-800/80">
                  <span className="flex items-center gap-1.5">
                    <RotateCw className="w-3.5 h-3.5" /> Tap card to flip
                  </span>
                  <span>Interval: {currentCard.intervalDays} days • Reviewed {currentCard.reviewCount}x</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-16 text-slate-500 text-xs">No flashcards found. Create your first card!</div>
          )}

          {/* Spaced Repetition Rating Buttons */}
          <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-2 text-center">
            <p className="text-xs text-slate-400">How accurately did you retrieve this concept from memory?</p>
            <div className="grid grid-cols-4 gap-2 pt-1 text-xs">
              <button
                onClick={() => handleNextCard('again')}
                className="py-2.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 font-semibold transition"
              >
                Again (1d)
              </button>
              <button
                onClick={() => handleNextCard('hard')}
                className="py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-semibold transition"
              >
                Hard (2d)
              </button>
              <button
                onClick={() => handleNextCard('good')}
                className="py-2.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-indigo-300 font-semibold transition"
              >
                Good (4d)
              </button>
              <button
                onClick={() => handleNextCard('easy')}
                className="py-2.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 font-semibold transition"
              >
                Easy (7d)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. Practice Quizzes View */}
      {activeSection === 'quizzes' && (
        <div className="space-y-6">
          {activeQuiz ? (
            /* Active Test Mode */
            <div className="max-w-3xl mx-auto space-y-6">
              <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-900 border border-slate-800">
                <div>
                  <h3 className="text-sm font-bold text-white">{activeQuiz.title}</h3>
                  <p className="text-xs text-slate-400">{activeQuiz.subject} • {activeQuiz.questions.length} Questions</p>
                </div>
                <button
                  onClick={() => setActiveQuiz(null)}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  Exit Quiz
                </button>
              </div>

              {/* Questions List */}
              <div className="space-y-4">
                {activeQuiz.questions.map((q, qIndex) => {
                  const userAnswer = selectedAnswers[qIndex];
                  const isCorrect = userAnswer === q.correctIndex;

                  return (
                    <div key={q.id} className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
                      <div className="flex items-start gap-3">
                        <span className="w-6 h-6 rounded-full bg-violet-600/30 text-violet-300 flex items-center justify-center text-xs font-bold shrink-0">
                          {qIndex + 1}
                        </span>
                        <h4 className="text-xs sm:text-sm font-semibold text-white leading-relaxed">{q.question}</h4>
                      </div>

                      {/* Options */}
                      <div className="space-y-2 pt-2">
                        {q.options.map((opt, optIndex) => {
                          const isSelected = userAnswer === optIndex;
                          let optionClass = 'bg-slate-950/70 border-slate-800 text-slate-300 hover:border-slate-700';

                          if (quizSubmitted) {
                            if (optIndex === q.correctIndex) {
                              optionClass = 'bg-emerald-950/40 border-emerald-500 text-emerald-200 font-semibold';
                            } else if (isSelected) {
                              optionClass = 'bg-rose-950/40 border-rose-500 text-rose-200';
                            }
                          } else if (isSelected) {
                            optionClass = 'bg-violet-600/20 border-violet-500 text-white font-semibold';
                          }

                          return (
                            <button
                              key={optIndex}
                              disabled={quizSubmitted}
                              onClick={() => setSelectedAnswers(prev => ({ ...prev, [qIndex]: optIndex }))}
                              className={`w-full p-3 rounded-2xl border text-left text-xs transition flex items-center justify-between ${optionClass}`}
                            >
                              <span>{opt}</span>
                              {quizSubmitted && optIndex === q.correctIndex && (
                                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 ml-2" />
                              )}
                              {quizSubmitted && isSelected && optIndex !== q.correctIndex && (
                                <XCircle className="w-4 h-4 text-rose-400 shrink-0 ml-2" />
                              )}
                            </button>
                          );
                        })}
                      </div>

                      {/* Explanation box after submit */}
                      {quizSubmitted && (
                        <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs space-y-1">
                          <span className={`font-bold ${isCorrect ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {isCorrect ? '✓ Correct Answer' : '✕ Review Concept'}
                          </span>
                          <p className="text-slate-300 leading-relaxed">{q.explanation}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Submit or Result Button */}
              {!quizSubmitted ? (
                <button
                  onClick={handleSubmitQuiz}
                  className="w-full py-3 rounded-2xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs transition shadow-lg shadow-violet-900/40"
                >
                  Submit & Score Practice Test
                </button>
              ) : (
                <div className="p-6 rounded-3xl bg-slate-900 border border-violet-500/40 text-center space-y-3">
                  <Award className="w-10 h-10 text-amber-400 mx-auto" />
                  <h4 className="text-lg font-bold text-white">Assessment Complete!</h4>
                  <p className="text-xs text-slate-300">
                    You scored{' '}
                    <strong className="text-emerald-400 text-base">
                      {Object.keys(selectedAnswers).filter(k => selectedAnswers[Number(k)] === activeQuiz.questions[Number(k)].correctIndex).length}
                    </strong>{' '}
                    out of {activeQuiz.questions.length} questions.
                  </p>
                  <button
                    onClick={() => setActiveQuiz(null)}
                    className="px-6 py-2.5 rounded-xl bg-violet-600 text-white text-xs font-semibold"
                  >
                    Done & Return to Bank
                  </button>
                </div>
              )}
            </div>
          ) : (
            /* Quiz Cards Catalog */
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {quizzes.map(q => (
                  <div
                    key={q.id}
                    className="p-6 rounded-3xl bg-slate-900 border border-slate-800 hover:border-violet-500/40 transition flex flex-col justify-between space-y-4"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="px-2.5 py-0.5 rounded-full bg-violet-600/20 text-violet-300 font-semibold">
                          {q.subject}
                        </span>
                        <span className="text-slate-400 font-mono flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" /> {q.timeLimitMinutes} min
                        </span>
                      </div>
                      <h3 className="text-base font-bold text-white">{q.title}</h3>
                      <p className="text-xs text-slate-400">Target Concept: {q.topic}</p>
                    </div>

                    <button
                      onClick={() => handleStartQuiz(q)}
                      className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-violet-600 text-white font-semibold text-xs transition flex items-center justify-center gap-1.5"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Start Timed Exam</span>
                    </button>
                  </div>
                ))}
              </div>

              {/* Historical Scores & Weak Topics */}
              {quizAttempts.length > 0 && (
                <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Recent Test Performance & Diagnostics</h3>
                  <div className="space-y-2">
                    {quizAttempts.slice(0, 3).map(att => (
                      <div key={att.id} className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                        <div>
                          <p className="font-semibold text-white">{att.quizTitle}</p>
                          <p className="text-[10px] text-slate-400">{att.subject} • {att.date.split('T')[0]}</p>
                        </div>
                        <span className="font-mono font-bold text-emerald-400">
                          {att.score}/{att.totalQuestions} ({Math.round((att.score / att.totalQuestions) * 100)}%)
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 3. AI Custom Quiz Generator View */}
      {activeSection === 'ai_generator' && (
        <div className="max-w-2xl mx-auto p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-violet-400" />
              <span>Instant AI Quiz Generator</span>
            </h3>
            <p className="text-xs text-slate-400">
              Enter any subject or syllabus subtopic and Gemini AI will synthesize custom multiple-choice questions with answer keys and trap rationales.
            </p>
          </div>

          <form onSubmit={handleGenerateAiQuiz} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Topic or Concept Focus</label>
              <input
                type="text"
                required
                value={aiTopic}
                onChange={(e) => setAiTopic(e.target.value)}
                placeholder="e.g. Lineweaver-Burk Inhibitor Plots or Integration by Partial Fractions"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Subject</label>
                <select
                  value={aiSubject}
                  onChange={(e) => setAiSubject(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none"
                >
                  {user?.subjects.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Difficulty</label>
                <select
                  value={aiDifficulty}
                  onChange={(e) => setAiDifficulty(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none"
                >
                  <option value="easy">Easy (Foundations)</option>
                  <option value="medium">Medium (Standard Exam)</option>
                  <option value="hard">Hard (Advanced Traps)</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={isAiGenerating}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 disabled:opacity-50 text-white font-bold text-xs transition shadow-lg shadow-violet-900/40 cursor-pointer flex items-center justify-center gap-2"
            >
              <Sparkles className={`w-4 h-4 ${isAiGenerating ? 'animate-spin' : ''}`} />
              <span>{isAiGenerating ? 'Generating Assessment Questions...' : 'Generate AI Assessment'}</span>
            </button>
          </form>
        </div>
      )}

      {/* Add Flashcard Modal */}
      {isAddCardOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={() => setIsAddCardOpen(false)}>
          <div
            className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-3xl p-6 shadow-2xl text-slate-100 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-base font-bold text-white">Create Flashcard</h3>
            <form onSubmit={handleCreateCard} className="space-y-3">
              <div>
                <label className="block text-xs text-slate-300 mb-1">Subject</label>
                <input
                  type="text"
                  required
                  value={newCardSubject}
                  onChange={(e) => setNewCardSubject(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-300 mb-1">Front: Question or Term</label>
                <textarea
                  required
                  rows={2}
                  value={newCardQ}
                  onChange={(e) => setNewCardQ(e.target.value)}
                  placeholder="e.g. What is the Michaelis constant (Km)?"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-300 mb-1">Back: Answer & Mechanism</label>
                <textarea
                  required
                  rows={3}
                  value={newCardA}
                  onChange={(e) => setNewCardA(e.target.value)}
                  placeholder="e.g. Substrate concentration at which initial velocity is half of Vmax..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddCardOpen(false)}
                  className="px-4 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold"
                >
                  Save Flashcard (+20 XP)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
