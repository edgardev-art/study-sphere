import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  Bot,
  FileText,
  CalendarCheck,
  Brain,
  Users,
  CheckCircle2,
  ChevronDown,
  ShieldCheck,
  Zap,
  Star,
  Smartphone,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const LandingPage: React.FC = () => {
  const {
    setIsLandingPage,
    setIsAuthModalOpen,
    setActiveTab,
    demoLogin,
    setViewMode,
  } = useApp();

  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const faqs = [
    {
      q: 'How does StudySphere’s AI Tutor assist with difficult topics?',
      a: 'The AI Tutor offers four distinct cognitive modes: Simple (intuitive analogies for rapid grasp), Detailed (rigorous step-by-step academic proofs), Exam Preparation (high-yield facts and trap avoidance), and Socratic (guiding you to solve the problem yourself through thought-provoking questions).',
    },
    {
      q: 'Can I use StudySphere offline on my Android device?',
      a: 'Yes! StudySphere is architected as an installable Progressive Web App (PWA). You can tap "Install App" to add it directly to your Android home screen as a standalone application. Your notes, flashcard decks, and study timetable remain accessible offline.',
    },
    {
      q: 'How does the flashcard spaced repetition algorithm work?',
      a: 'StudySphere uses a modified SM-2 spaced repetition system. When you review a flashcard and grade it (Again, Hard, Good, Easy), the system dynamically computes the optimal interval in days before scheduling your next review, ensuring maximum memory retention before decay.',
    },
    {
      q: 'Are educator and admin tools available?',
      a: 'Yes. Authorized educators and administrators have access to the Course Builder interface to author curriculum modules, lesson objectives, and topic quizzes, as well as the moderation console for community safety.',
    },
  ];

  const sampleTestimonials = [
    {
      name: 'Maya Lin',
      role: '2nd Year Pre-Med Student',
      institution: 'Johns Hopkins University (Sample Profile)',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      comment: 'Converting my biochemical pathway notes directly into active recall flashcards with the Socratic AI mode cut my study time in half while improving my exam scores.',
    },
    {
      name: 'Julian Vance',
      role: 'Computer Science Major',
      institution: 'Polytechnic Institute (Sample Profile)',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      comment: 'The integrated Pomodoro timer synced with subject study rooms keeps me focused late into the night. It feels like studying with my closest classmates in a modern cyber library.',
    },
    {
      name: 'Sarah Adeyemi',
      role: 'A-Level & Secondary Scholar',
      institution: 'St. George Academy (Sample Profile)',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      comment: 'The step-by-step calculus explanations never feel judgmental. If I get stuck on integration by parts, it breaks it down into bite-sized questions until I get it.',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-violet-600 selection:text-white">
      {/* Top Navbar */}
      <nav className="border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-md px-6 py-4 sticky top-0 z-40 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-violet-600 to-cyan-400 p-0.5">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-violet-400" />
            </div>
          </div>
          <span className="font-extrabold text-lg tracking-tight text-white font-sans">StudySphere</span>
        </div>

        <div className="hidden md:flex items-center gap-8 text-xs font-semibold text-slate-400">
          <a href="#features" className="hover:text-white transition">Features</a>
          <a href="#how-it-works" className="hover:text-white transition">How it Works</a>
          <a href="#pricing" className="hover:text-white transition">Pricing</a>
          <a href="#community" className="hover:text-white transition">Community</a>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => demoLogin('student')}
            className="hidden sm:inline-flex px-3 py-1.5 rounded-xl border border-violet-500/40 bg-violet-950/30 text-violet-300 text-xs font-semibold hover:bg-violet-900/40 transition cursor-pointer"
          >
            ⚡ Student Demo
          </button>
          <button
            onClick={() => setIsAuthModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold transition shadow-md shadow-violet-900/30 cursor-pointer"
          >
            Get Started Free
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-16 pb-20 px-6 max-w-6xl mx-auto text-center relative overflow-hidden">
        {/* Glow Effects */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-violet-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/3 left-1/4 w-64 h-64 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-violet-950/60 border border-violet-500/30 text-violet-300 text-xs font-semibold mb-6 animate-pulse">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>The Next-Generation Digital Learning Ecosystem</span>
        </div>

        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-tight max-w-4xl mx-auto mb-6">
          Your Entire Academic Life. <br />
          <span className="bg-gradient-to-r from-violet-400 via-indigo-300 to-cyan-300 bg-clip-text text-transparent">
            One Intelligent Platform.
          </span>
        </h1>

        <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto mb-10 leading-relaxed">
          Study smarter with an adaptive AI tutor, organize notes, plan exam revision with spaced repetition, and collaborate in live study rooms with classmates worldwide.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-14">
          <button
            onClick={() => {
              demoLogin('student');
              setIsLandingPage(false);
            }}
            className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-violet-600 via-indigo-600 to-violet-700 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-sm shadow-xl shadow-violet-900/50 flex items-center justify-center gap-2 transition cursor-pointer"
          >
            <span>Start Learning for Free</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              setViewMode('android');
              demoLogin('student');
              setIsLandingPage(false);
            }}
            className="w-full sm:w-auto px-6 py-3.5 rounded-2xl border border-slate-700 bg-slate-900/80 hover:bg-slate-800 text-slate-200 font-semibold text-sm flex items-center justify-center gap-2 transition cursor-pointer"
          >
            <Smartphone className="w-4 h-4 text-violet-400" />
            <span>Launch in Android View</span>
          </button>
        </div>

        {/* Interactive Dashboard Live Preview */}
        <div className="relative mx-auto max-w-5xl rounded-3xl p-2 bg-gradient-to-b from-slate-700/60 to-slate-900/80 shadow-2xl border border-slate-700">
          <div className="rounded-2xl bg-slate-950 overflow-hidden border border-slate-800 text-left p-6 sm:p-8">
            <div className="flex items-center justify-between pb-6 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                <span className="text-xs text-slate-400 font-mono ml-2">studysphere.app/dashboard</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-violet-400 font-semibold">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>Live Student Workspace</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6">
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-300">🔥 7-Day Study Streak</span>
                  <span className="text-[10px] text-amber-400 font-bold bg-amber-400/10 px-2 py-0.5 rounded-full">+50 XP Today</span>
                </div>
                <p className="text-xs text-slate-400">Consistency shield active. Next milestone: 10-day streak badge.</p>
                <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-400 w-3/4 rounded-full" />
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-300">🤖 AI Tutor Question</span>
                  <span className="text-[10px] text-violet-300 font-bold bg-violet-400/10 px-2 py-0.5 rounded-full">Socratic Mode</span>
                </div>
                <p className="text-xs text-slate-300 italic">&quot;Explain why the rate-limiting step of glycolysis is catalyzed by PFK-1?&quot;</p>
                <p className="text-[11px] text-violet-300">AI: What happens to PFK-1 when ATP levels rise?</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-300">⏱️ Pomodoro Active</span>
                  <span className="text-[10px] text-emerald-400 font-bold bg-emerald-400/10 px-2 py-0.5 rounded-full">Interval 2/4</span>
                </div>
                <div className="text-2xl font-mono font-bold text-white">21:40</div>
                <p className="text-xs text-slate-400">Target: Cellular Respiration practice drills</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Cards Section */}
      <section id="features" className="py-20 px-6 max-w-6xl mx-auto">
        <div className="text-center mb-16 space-y-3">
          <h2 className="text-xs font-bold uppercase tracking-wider text-violet-400">Core Pillars</h2>
          <h3 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            Engineered for Academic Excellence
          </h3>
          <p className="text-slate-400 text-xs sm:text-sm max-w-xl mx-auto">
            Everything secondary school and university students need to excel in exams, retain difficult formulas, and keep track of academic goals.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800 hover:border-violet-500/40 transition group">
            <div className="w-12 h-12 rounded-2xl bg-violet-600/20 text-violet-400 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
              <Bot className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-white mb-2">Adaptive Socratic AI Tutor</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Never get stuck on proofs. Switch between Simple analogies, university-grade Detailed mechanisms, high-yield Exam Prep, or Socratic inquiry that guides your thinking.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800 hover:border-indigo-500/40 transition group">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
              <Brain className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-white mb-2">Spaced Repetition & Quizzes</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Convert notes into 3D flashcards with interval scheduling (Again/Hard/Good/Easy). Take timed mock assessments with weak-topic error tracking.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800 hover:border-cyan-500/40 transition group">
            <div className="w-12 h-12 rounded-2xl bg-cyan-600/20 text-cyan-400 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
              <CalendarCheck className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-white mb-2">Smart Timetable & Pomodoro</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              AI-generated study schedule based on upcoming exam dates and daily available hours. Built-in 25/5 Pomodoro focus timer with ambient soundscapes.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800 hover:border-emerald-500/40 transition group">
            <div className="w-12 h-12 rounded-2xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
              <FileText className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-white mb-2">Distraction-Free Digital Notes</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Rich-text notes organized by subject tags and folders. One-click AI summarization, key takeaways extraction, and markdown export.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800 hover:border-rose-500/40 transition group">
            <div className="w-12 h-12 rounded-2xl bg-rose-600/20 text-rose-400 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
              <Users className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-white mb-2">Live Virtual Study Rooms</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Join synchronized study rooms with classmates. Share study goals, chat about difficult assignment questions, and maintain study discipline.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800 hover:border-amber-500/40 transition group">
            <div className="w-12 h-12 rounded-2xl bg-amber-600/20 text-amber-400 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
              <Zap className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-white mb-2">Gamified XP & Daily Streaks</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Earn XP for deep focus intervals, quiz scores, and flashcard repetitions. Unlock achievement trophies and track long-term academic progress.
            </p>
          </div>
        </div>
      </section>

      {/* How it Works Section */}
      <section id="how-it-works" className="py-20 px-6 bg-slate-900/40 border-y border-slate-800/80">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14 space-y-2">
            <h2 className="text-xs font-bold uppercase tracking-wider text-violet-400">Step-by-Step</h2>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white">How StudySphere Accelerates Learning</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { step: '01', title: 'Personalize Syllabus', desc: 'Select your level (High School or University), input current subjects, and specify daily target hours.' },
              { step: '02', title: 'Learn with AI Tutor', desc: 'Ask complex questions, get tailored analogies, practice exercises, and Socratic hints on tough concepts.' },
              { step: '03', title: 'Retain via Recall', desc: 'Automatically generate flashcards and topic quizzes from your notes. Review using spaced intervals.' },
              { step: '04', title: 'Conquer Examinations', desc: 'Track mastery progress bars, weak topics, and complete mock tests with full confidence.' },
            ].map(item => (
              <div key={item.step} className="p-5 rounded-2xl bg-slate-950 border border-slate-800">
                <span className="text-2xl font-mono font-bold text-violet-400 mb-2 block">{item.step}</span>
                <h4 className="text-sm font-bold text-white mb-1.5">{item.title}</h4>
                <p className="text-xs text-slate-400 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Sample Student Testimonials */}
      <section className="py-20 px-6 max-w-6xl mx-auto">
        <div className="text-center mb-14 space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 text-[11px] font-medium text-slate-300">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Sample Student Feedback Profiles</span>
          </div>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-white">Designed by Students, Built for Results</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {sampleTestimonials.map(t => (
            <div key={t.name} className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
              <div className="space-y-3 mb-6">
                <div className="flex gap-1 text-amber-400">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-amber-400" />)}
                </div>
                <p className="text-xs text-slate-300 leading-relaxed italic">&quot;{t.comment}&quot;</p>
              </div>

              <div className="flex items-center gap-3 pt-4 border-t border-slate-800/80">
                <img src={t.avatar} alt={t.name} className="w-9 h-9 rounded-full object-cover border border-violet-500/40" />
                <div>
                  <p className="text-xs font-bold text-white">{t.name}</p>
                  <p className="text-[10px] text-slate-400">{t.role} • {t.institution}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing Preview */}
      <section id="pricing" className="py-20 px-6 bg-slate-900/30 border-t border-slate-800">
        <div className="max-w-5xl mx-auto text-center mb-14 space-y-2">
          <h2 className="text-xs font-bold uppercase tracking-wider text-violet-400">Transparent Plans</h2>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-white">Choose Your Study Trajectory</h3>
          <p className="text-xs text-slate-400">All plans include Android app installability, notes, and community access.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {/* Free Plan */}
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 text-left flex flex-col justify-between">
            <div>
              <h4 className="text-base font-bold text-white mb-1">Free Plan</h4>
              <p className="text-xs text-slate-400 mb-4">Core essentials for everyday study.</p>
              <div className="text-3xl font-extrabold text-white mb-6">$0 <span className="text-xs text-slate-400 font-normal">/ month</span></div>

              <ul className="space-y-2.5 text-xs text-slate-300 mb-8">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Basic course access</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Standard AI tutor queries</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Unlimited digital notes</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Community channels</li>
              </ul>
            </div>

            <button
              onClick={() => { demoLogin('student'); setIsLandingPage(false); }}
              className="w-full py-2.5 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition"
            >
              Get Started Free
            </button>
          </div>

          {/* Pro Plan */}
          <div className="p-6 rounded-3xl bg-gradient-to-b from-violet-950/60 to-slate-900 border-2 border-violet-500 text-left flex flex-col justify-between relative shadow-xl shadow-violet-900/30">
            <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-violet-600 text-white text-[10px] font-bold uppercase tracking-wider">
              Most Popular
            </span>
            <div>
              <h4 className="text-base font-bold text-white mb-1">Pro Scholar</h4>
              <p className="text-xs text-violet-300 mb-4">For serious academic & test prep.</p>
              <div className="text-3xl font-extrabold text-white mb-6">$9.99 <span className="text-xs text-slate-400 font-normal">/ month</span></div>

              <ul className="space-y-2.5 text-xs text-slate-200 mb-8">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-violet-400" /> Everything in Free</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-violet-400" /> High-yield Socratic reasoning</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-violet-400" /> AI-generated revision timetables</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-violet-400" /> Weak-topic error analytics</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-violet-400" /> Spaced repetition flashcards</li>
              </ul>
            </div>

            <button
              onClick={() => { demoLogin('student'); setActiveTab('pricing'); setIsLandingPage(false); }}
              className="w-full py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold transition shadow-md shadow-violet-900/50"
            >
              Start 14-Day Pro Trial
            </button>
          </div>

          {/* Premium Plan */}
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 text-left flex flex-col justify-between">
            <div>
              <h4 className="text-base font-bold text-white mb-1">Ultimate Academic</h4>
              <p className="text-xs text-slate-400 mb-4">Mastery across multiple disciplines.</p>
              <div className="text-3xl font-extrabold text-white mb-6">$19.99 <span className="text-xs text-slate-400 font-normal">/ month</span></div>

              <ul className="space-y-2.5 text-xs text-slate-300 mb-8">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Everything in Pro</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Unlimited AI tutor requests</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Custom exam predictor drills</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Priority educator support</li>
              </ul>
            </div>

            <button
              onClick={() => { demoLogin('student'); setActiveTab('pricing'); setIsLandingPage(false); }}
              className="w-full py-2.5 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition"
            >
              Upgrade to Ultimate
            </button>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-6 max-w-3xl mx-auto">
        <div className="text-center mb-12 space-y-2">
          <h2 className="text-xs font-bold uppercase tracking-wider text-violet-400">Questions & Answers</h2>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-white">Frequently Asked Questions</h3>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, index) => (
            <div key={index} className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden">
              <button
                onClick={() => setActiveFaq(activeFaq === index ? null : index)}
                className="w-full p-4 text-left flex items-center justify-between text-xs sm:text-sm font-semibold text-white hover:text-violet-300 transition"
              >
                <span>{faq.q}</span>
                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${activeFaq === index ? 'rotate-180' : ''}`} />
              </button>
              {activeFaq === index && (
                <div className="px-4 pb-4 text-xs text-slate-400 leading-relaxed border-t border-slate-800/60 pt-3">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-12 px-6 mt-auto">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6 text-xs text-slate-500">
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded-lg bg-violet-600 flex items-center justify-center text-white">
              <Sparkles className="w-3 h-3" />
            </div>
            <span className="font-bold text-white">StudySphere</span>
            <span>• Empowering students worldwide</span>
          </div>

          <div className="flex items-center gap-6">
            <button onClick={() => { demoLogin('student'); setIsLandingPage(false); }} className="hover:text-slate-300 transition">Enter App</button>
            <a href="#features" className="hover:text-slate-300 transition">Features</a>
            <a href="#pricing" className="hover:text-slate-300 transition">Pricing</a>
            <button onClick={() => demoLogin('admin')} className="hover:text-slate-300 transition">Admin Portal</button>
          </div>
        </div>
      </footer>
    </div>
  );
};
