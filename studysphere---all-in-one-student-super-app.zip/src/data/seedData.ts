import { UserProfile, Course, Note, Task, Flashcard, Quiz, CommunityPost, StudyRoom, Badge, DailyMission, NotificationItem } from '../types';

export const INITIAL_USER: UserProfile = {
  id: 'usr-student-1',
  name: 'Alex Rivera',
  email: 'alex.rivera@campus.edu',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  role: 'student',
  educationLevel: 'undergraduate',
  institution: 'State Polytechnic & University',
  subjects: ['Cellular Biology', 'Calculus II', 'Data Structures', 'Microeconomics'],
  learningGoals: ['Maintain a 3.8+ GPA', 'Master Algorithms', 'Prepare for MCAT & Finals'],
  preferredSchedule: 'evening',
  dailyHoursTarget: 4,
  academicChallenges: ['Complex proofs', 'Retaining biochemical pathways'],
  streakDays: 7,
  lastActiveDate: new Date().toISOString().split('T')[0],
  streakProtected: true,
  totalXp: 1850,
  level: 6,
  tier: 'pro',
  subscriptionRenewalDate: '2026-11-20',
  onboardingCompleted: true,
  createdAt: '2026-09-01',
};

export const INITIAL_COURSES: Course[] = [
  {
    id: 'course-bio-101',
    title: 'Cellular Respiration & Metabolic Pathways',
    description: 'Deep dive into Glycolysis, the Krebs cycle, and oxidative phosphorylation with high-yield exam insights.',
    subject: 'Cellular Biology',
    level: 'undergraduate',
    instructor: 'Dr. Sarah Chen, Ph.D.',
    thumbnail: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=600&auto=format&fit=crop&q=80',
    enrolledStudentsCount: 3420,
    rating: 4.9,
    isBookmarked: true,
    progressPercent: 66,
    lessons: [
      {
        id: 'bio-l1',
        title: 'Overview of Cellular Metabolism & ATP Coupling',
        durationMinutes: 18,
        objectives: [
          'Understand thermodynamic coupling in biological reactions',
          'Identify structural components of Adenosine Triphosphate (ATP)',
          'Distinguish between substrate-level and oxidative phosphorylation'
        ],
        content: `### 1. Thermodynamic Coupling
Biological organisms defy spontaneous entropy increase through energy coupling: exergonic catabolic reactions drive endergonic anabolic synthesis.

**Key Formula:**
$$\\Delta G = \\Delta H - T\\Delta S$$

When ATP is hydrolyzed:
$$\\text{ATP} + \\text{H}_2\\text{O} \\rightarrow \\text{ADP} + \\text{P}_i \\quad (\\Delta G^{\\circ'} = -30.5 \\text{ kJ/mol})$$

### 2. High-Yield Exam Concept
Notice how standard free energy changes under physiological conditions ($\\Delta G$) are often even more negative (-50 kJ/mol) due to intracellular concentrations of ATP, ADP, and $P_i$.`,
        practiceExercise: {
          prompt: 'Why is ATP considered the universal energy currency rather than phosphoenolpyruvate (PEP), which has higher free energy of hydrolysis?',
          sampleAnswer: 'ATP sits at an intermediate energy level (-30.5 kJ/mol). Higher compounds like PEP can phosphorylate ADP into ATP, while ATP can phosphorylate lower-energy compounds like glucose-6-phosphate. Its kinetic stability without enzymes prevents spontaneous waste.',
          hint: 'Think about intermediate energetic positioning on the phosphorylation potential scale.'
        },
        isCompleted: true,
      },
      {
        id: 'bio-l2',
        title: 'Glycolysis: The 10 Enzymatic Steps & Regulation',
        durationMinutes: 25,
        objectives: [
          'Map out the preparatory and payoff phases of Glycolysis',
          'Highlight the irreversible regulatory checkpoints: Hexokinase, PFK-1, and Pyruvate Kinase',
          'Calculate the net yield of ATP and NADH per glucose molecule'
        ],
        content: `### The Glycolytic Pathway
Glycolysis occurs in the cytosol and does not require molecular oxygen.

**Phases:**
1. **Preparatory Phase (Steps 1–5):** Consumes 2 ATP to activate glucose and split it into two 3-carbon trioses.
2. **Payoff Phase (Steps 6–10):** Generates 4 ATP and 2 NADH.
**Net Balance:**
$$\\text{Glucose} + 2\\text{NAD}^+ + 2\\text{ADP} + 2\\text{P}_i \\rightarrow 2\\text{Pyruvate} + 2\\text{NADH} + 2\\text{H}^+ + 2\\text{ATP} + 2\\text{H}_2\\text{O}$$

### Key Regulatory Checkpoint: PFK-1
Phosphofructokinase-1 (PFK-1) is the master pacemaker of glycolysis.
- **Inhibited by:** High ATP, Citrate
- **Activated by:** AMP, Fructose 2,6-bisphosphate (F-2,6-BP)`,
        practiceExercise: {
          prompt: 'What happens to the rate of glycolysis if intracellular levels of ATP skyrocket while ADP plummets?',
          sampleAnswer: 'Glycolysis slows down because high ATP allosterically inhibits PFK-1 and Pyruvate Kinase, preventing unnecessary carbon consumption.',
          hint: 'Look at the allosteric feedback regulators of PFK-1.'
        },
        isCompleted: true,
      },
      {
        id: 'bio-l3',
        title: 'Electron Transport Chain & ATP Synthase Rotor Mechanics',
        durationMinutes: 30,
        objectives: [
          'Trace electron flow through Complexes I, II, III, and IV',
          'Explain the chemiosmotic proton-motive force across the inner mitochondrial membrane',
          'Understand how the F0 and F1 subunits of ATP Synthase synthesize ATP'
        ],
        content: `### Chemiosmosis & The Proton Gradient
The electron transport chain transfers electrons from NADH and FADH2 to molecular oxygen ($O_2$), generating water while pumping protons into the intermembrane space.

- Complex I: Pumps 4 $H^+$
- Complex III: Pumps 4 $H^+$
- Complex IV: Pumps 2 $H^+$

The resulting electrochemical gradient drives protons back through the $F_0$ rotor of ATP Synthase, rotating the $F_1$ catalytic head to produce ATP.`,
        isCompleted: false,
      }
    ]
  },
  {
    id: 'course-calc-201',
    title: 'Calculus II: Integration Techniques & Infinite Series',
    description: 'Master Integration by Parts, Partial Fractions, Taylor Series, and radius of convergence with interactive drills.',
    subject: 'Calculus II',
    level: 'undergraduate',
    instructor: 'Prof. Marcus Vance',
    thumbnail: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=600&auto=format&fit=crop&q=80',
    enrolledStudentsCount: 4890,
    rating: 4.8,
    isBookmarked: false,
    progressPercent: 40,
    lessons: [
      {
        id: 'calc-l1',
        title: 'Integration by Parts & The Tabular Method',
        durationMinutes: 20,
        objectives: ['Derive integration by parts from the product rule', 'Apply LIATE rule for choosing u and dv', 'Use the tabular shortcut for polynomial-exponential products'],
        content: `### Formula
$$\\int u \\, dv = uv - \\int v \\, du$$

**LIATE Priority for selecting $u$:**
1. **L**ogarithmic
2. **I**nverse Trigonometric
3. **A**lgebraic (polynomials)
4. **T**rigonometric
5. **E**xponential`,
        isCompleted: true,
      },
      {
        id: 'calc-l2',
        title: 'Taylor & Maclaurin Series Expansions',
        durationMinutes: 25,
        objectives: ['Formulate Taylor polynomial approximations', 'Derive standard expansions for e^x, sin(x), cos(x)', 'Determine interval and radius of convergence via Ratio Test'],
        content: `### Definition
$$f(x) = \\sum_{n=0}^{\\infty} \\frac{f^{(n)}(a)}{n!} (x - a)^n$$

For $a = 0$ (Maclaurin Series):
$$e^x = \\sum_{n=0}^{\\infty} \\frac{x^n}{n!} = 1 + x + \\frac{x^2}{2!} + \\dots$$`,
        isCompleted: false,
      }
    ]
  },
  {
    id: 'course-cs-301',
    title: 'Data Structures & Algorithms in Practice',
    description: 'Graph algorithms, balanced binary trees, dynamic programming paradigms, and Big-O computational analysis.',
    subject: 'Data Structures',
    level: 'undergraduate',
    instructor: 'Elena Rostova, M.Sc.',
    thumbnail: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=600&auto=format&fit=crop&q=80',
    enrolledStudentsCount: 6200,
    rating: 4.95,
    isBookmarked: true,
    progressPercent: 75,
    lessons: [
      {
        id: 'cs-l1',
        title: 'Graph Traversal: BFS vs DFS and Cycle Detection',
        durationMinutes: 22,
        objectives: ['Implement BFS using a queue', 'Implement DFS using recursion and stack', 'Detect cycles in directed and undirected graphs'],
        content: `### Breadth-First Search (BFS)
Traverses level by level. Ideal for shortest-path on unweighted graphs.
**Time Complexity:** $O(V + E)$
**Space Complexity:** $O(V)$`,
        isCompleted: true,
      }
    ]
  }
];

export const INITIAL_NOTES: Note[] = [
  {
    id: 'note-1',
    userId: 'usr-student-1',
    title: 'Biochemistry: Enzyme Kinetics & Michaelis-Menten',
    subject: 'Cellular Biology',
    tags: ['enzymes', 'biochem', 'mcat-prep', 'formulas'],
    isPinned: true,
    isFavorite: true,
    content: `# Enzyme Kinetics & The Michaelis-Menten Model

## Key Assumptions
1. Steady-state approximation: Rate of ES complex formation equals rate of breakdown.
2. Initial velocity condition: Product concentration is negligible initially.

## Michaelis-Menten Equation:
V0 = (Vmax * [S]) / (Km + [S])

- **Km (Michaelis Constant):** Substrate concentration at which velocity is half of Vmax. Reflects enzyme affinity (lower Km = higher substrate affinity).
- **Kcat (Turnover Number):** Vmax / [E]total
- **Catalytic Efficiency:** Kcat / Km

## Lineweaver-Burk Double Reciprocal Plot:
1/V0 = (Km/Vmax) * (1/[S]) + 1/Vmax
- Y-intercept: 1/Vmax
- X-intercept: -1/Km
- Slope: Km / Vmax

## Types of Inhibition:
1. **Competitive:** Km increases, Vmax unchanged. Overcome by high [S].
2. **Non-competitive:** Km unchanged, Vmax decreases. Allosteric site binding.
3. **Uncompetitive:** Both Km and Vmax decrease in equal ratio.`,
    summary: 'Mastery overview of Michaelis-Menten kinetics, Lineweaver-Burk plots, and enzyme inhibition mechanisms for upcoming biology midterms.',
    history: [
      {
        id: 'v1',
        timestamp: '2026-10-15T14:30:00Z',
        title: 'Biochemistry: Enzyme Kinetics Draft',
        content: '# Enzyme Kinetics\n\nInitial notes from lecture 4.\nV0 = (Vmax * [S]) / (Km + [S])\nReview assumptions about steady state.',
        wordCount: 22,
        changeDescription: 'Initial lecture notes',
      },
      {
        id: 'v2',
        timestamp: '2026-10-16T10:15:00Z',
        title: 'Biochemistry: Enzyme Kinetics & Michaelis-Menten',
        content: '# Enzyme Kinetics & The Michaelis-Menten Model\n\n## Key Assumptions\n1. Steady-state approximation\n2. Initial velocity condition\n\n## Equations:\nV0 = (Vmax * [S]) / (Km + [S])\nKm = substrate conc at half Vmax.',
        wordCount: 35,
        changeDescription: 'Added Lineweaver-Burk derivation',
      },
      {
        id: 'v3',
        timestamp: '2026-10-17T09:15:00Z',
        title: 'Biochemistry: Enzyme Kinetics & Michaelis-Menten',
        content: `# Enzyme Kinetics & The Michaelis-Menten Model

## Key Assumptions
1. Steady-state approximation: Rate of ES complex formation equals rate of breakdown.
2. Initial velocity condition: Product concentration is negligible initially.

## Michaelis-Menten Equation:
V0 = (Vmax * [S]) / (Km + [S])

- **Km (Michaelis Constant):** Substrate concentration at which velocity is half of Vmax. Reflects enzyme affinity (lower Km = higher substrate affinity).
- **Kcat (Turnover Number):** Vmax / [E]total
- **Catalytic Efficiency:** Kcat / Km

## Lineweaver-Burk Double Reciprocal Plot:
1/V0 = (Km/Vmax) * (1/[S]) + 1/Vmax
- Y-intercept: 1/Vmax
- X-intercept: -1/Km
- Slope: Km / Vmax

## Types of Inhibition:
1. **Competitive:** Km increases, Vmax unchanged. Overcome by high [S].
2. **Non-competitive:** Km unchanged, Vmax decreases. Allosteric site binding.
3. **Uncompetitive:** Both Km and Vmax decrease in equal ratio.`,
        summary: 'Mastery overview of Michaelis-Menten kinetics, Lineweaver-Burk plots, and enzyme inhibition mechanisms for upcoming biology midterms.',
        wordCount: 128,
        changeDescription: 'Added competitive & uncompetitive inhibition rules',
      }
    ],
    createdAt: '2026-10-15T14:30:00Z',
    updatedAt: '2026-10-17T09:15:00Z',
  },
  {
    id: 'note-2',
    userId: 'usr-student-1',
    title: 'Calculus: Convergence Tests Cheat Sheet',
    subject: 'Calculus II',
    tags: ['math', 'series', 'exam-prep'],
    isPinned: true,
    isFavorite: false,
    content: `# Infinite Series Convergence Criteria

1. **Divergence Test (n-th term test):**
   If lim (n->inf) a_n != 0, the series diverges. Note: If limit is 0, test is INCONCLUSIVE!
2. **Geometric Series:**
   Sum of r^n converges iff |r| < 1. Sum = a / (1 - r).
3. **p-Series Test:**
   Sum of 1 / n^p converges iff p > 1.
4. **Ratio Test:**
   lim |a_(n+1) / a_n| = L. If L < 1 (converges), L > 1 (diverges), L = 1 (inconclusive). Excellent for factorials and exponentials.
5. **Alternating Series Test (Leibniz):**
   Series (-1)^n b_n converges if b_n is decreasing and lim b_n = 0.`,
    summary: 'Summary of 5 essential convergence tests with test selection heuristics.',
    createdAt: '2026-10-12T11:00:00Z',
    updatedAt: '2026-10-14T16:20:00Z',
  },
  {
    id: 'note-3',
    userId: 'usr-student-1',
    title: 'Microeconomics: Price Elasticity & Consumer Surplus',
    subject: 'Microeconomics',
    tags: ['economics', 'elasticity', 'markets'],
    isPinned: false,
    isFavorite: true,
    content: `# Price Elasticity of Demand (PED)

PED = (% Change in Quantity Demanded) / (% Change in Price)

- |PED| > 1: Elastic demand (luxury goods, many substitutes)
- |PED| < 1: Inelastic demand (necessities, insulin, gasoline)
- |PED| = 1: Unit elastic (total revenue maximized)

## Deadweight Loss (DWL)
Represents lost social welfare caused by market inefficiencies such as monopolies, taxes, or price ceilings.`,
    createdAt: '2026-10-10T15:20:00Z',
    updatedAt: '2026-10-10T15:20:00Z',
  }
];

export const INITIAL_TASKS: Task[] = [
  {
    id: 'task-1',
    title: 'Review Cellular Respiration Quiz Corrections',
    subject: 'Cellular Biology',
    dueDate: '2026-10-19',
    estimatedMinutes: 45,
    priority: 'urgent',
    completed: false,
    type: 'exam_prep',
  },
  {
    id: 'task-2',
    title: 'Complete Calculus Integration Problem Set #6',
    subject: 'Calculus II',
    dueDate: '2026-10-20',
    estimatedMinutes: 90,
    priority: 'high',
    completed: false,
    type: 'assignment',
  },
  {
    id: 'task-3',
    title: 'Memorize 25 MCAT Biochemistry Flashcards',
    subject: 'Cellular Biology',
    dueDate: '2026-10-19',
    estimatedMinutes: 30,
    priority: 'medium',
    completed: true,
    type: 'revision',
  },
  {
    id: 'task-4',
    title: 'Read Microeconomics Chapter 7: Perfect Competition',
    subject: 'Microeconomics',
    dueDate: '2026-10-22',
    estimatedMinutes: 60,
    priority: 'low',
    completed: false,
    type: 'reading',
  },
  {
    id: 'task-5',
    title: 'Implement Dijkstra’s Algorithm in Python',
    subject: 'Data Structures',
    dueDate: '2026-10-23',
    estimatedMinutes: 120,
    priority: 'high',
    completed: false,
    type: 'assignment',
  }
];

export const INITIAL_FLASHCARDS: Flashcard[] = [
  {
    id: 'fc-1',
    subject: 'Cellular Biology',
    deckId: 'deck-bio',
    question: 'What is the net ATP yield of aerobic cellular respiration per glucose molecule?',
    answer: 'Approximately 30 to 32 ATP molecules (2 from glycolysis, 2 from citric acid cycle, ~26-28 from oxidative phosphorylation).',
    intervalDays: 4,
    easeFactor: 2.5,
    reviewCount: 3,
  },
  {
    id: 'fc-2',
    subject: 'Cellular Biology',
    deckId: 'deck-bio',
    question: 'Which enzyme catalyzes the committed, rate-limiting step of glycolysis?',
    answer: 'Phosphofructokinase-1 (PFK-1), allosterically activated by AMP & F-2,6-BP, inhibited by ATP & Citrate.',
    intervalDays: 7,
    easeFactor: 2.6,
    reviewCount: 5,
  },
  {
    id: 'fc-3',
    subject: 'Calculus II',
    deckId: 'deck-calc',
    question: 'What is the standard Maclaurin series for sin(x)?',
    answer: 'sin(x) = x - (x^3)/3! + (x^5)/5! - (x^7)/7! + ... = sum_{n=0}^inf [(-1)^n * x^(2n+1) / (2n+1)!]',
    intervalDays: 2,
    easeFactor: 2.3,
    reviewCount: 2,
  },
  {
    id: 'fc-4',
    subject: 'Data Structures',
    deckId: 'deck-cs',
    question: 'What is the worst-case time complexity of quicksort and how is it mitigated?',
    answer: 'O(N^2) when the pivot chosen is always the extreme minimum or maximum. Mitigated by randomized pivot selection or median-of-three.',
    intervalDays: 5,
    easeFactor: 2.5,
    reviewCount: 4,
  },
  {
    id: 'fc-5',
    subject: 'Microeconomics',
    deckId: 'deck-econ',
    question: 'What characterizes a firm in long-run competitive equilibrium?',
    answer: 'Price = Marginal Cost = Minimum Average Total Cost (P = MC = min ATC). Economic profit is zero.',
    intervalDays: 3,
    easeFactor: 2.4,
    reviewCount: 2,
  }
];

export const INITIAL_QUIZZES: Quiz[] = [
  {
    id: 'quiz-bio-1',
    title: 'Cellular Respiration Mastery Assessment',
    subject: 'Cellular Biology',
    topic: 'Metabolic Energy & ATP Synthase',
    difficulty: 'medium',
    timeLimitMinutes: 10,
    questions: [
      {
        id: 'qb1',
        question: 'During glycolysis, which reaction directly involves substrate-level phosphorylation?',
        options: [
          'Conversion of Glucose to Glucose-6-phosphate',
          'Phosphoglycerate kinase converting 1,3-bisphosphoglycerate to 3-phosphoglycerate',
          'PFK-1 converting Fructose-6-phosphate to Fructose-1,6-bisphosphate',
          'Isomerization of DHAP to G3P'
        ],
        correctIndex: 1,
        explanation: 'Phosphoglycerate kinase transfers a high-energy phosphate from 1,3-BPG directly to ADP, producing ATP without requiring oxygen.'
      },
      {
        id: 'qb2',
        question: 'Where do protons accumulate to create the proton-motive force in eukaryotic mitochondria?',
        options: [
          'Mitochondrial matrix',
          'Intermembrane space',
          'Inner mitochondrial membrane interior',
          'Cytoplasmic cytosol'
        ],
        correctIndex: 1,
        explanation: 'Complexes I, III, and IV pump protons from the matrix into the intermembrane space, creating a low pH / high positive charge there.'
      },
      {
        id: 'qb3',
        question: 'What is the effect of an uncoupling agent (like 2,4-DNP) on cellular respiration?',
        options: [
          'Stops electron transport chain completely',
          'Inhibits glycolysis at hexokinase',
          'Allows electron transport to proceed while dissipating proton gradient as heat, halting ATP synthesis',
          'Increases ATP production efficiency by 50%'
        ],
        correctIndex: 2,
        explanation: 'DNP carries protons across the inner membrane, collapsing the proton gradient. Oxygen consumption continues at elevated rates, but energy is lost as heat instead of driving ATP Synthase.'
      }
    ]
  },
  {
    id: 'quiz-calc-1',
    title: 'Techniques of Integration Speed Challenge',
    subject: 'Calculus II',
    topic: 'Integration by Parts & Partial Fractions',
    difficulty: 'hard',
    timeLimitMinutes: 8,
    questions: [
      {
        id: 'qc1',
        question: 'Evaluate the integral: ∫ x * e^(2x) dx',
        options: [
          '(x/2)*e^(2x) - (1/4)*e^(2x) + C',
          '(x^2 / 2) * e^(2x) + C',
          'x*e^(2x) - 2*e^(2x) + C',
          '(1/2)*e^(2x) + C'
        ],
        correctIndex: 0,
        explanation: 'Let u = x, dv = e^(2x)dx. Then du = dx, v = (1/2)e^(2x). ∫u dv = (x/2)e^(2x) - ∫(1/2)e^(2x)dx = (x/2)e^(2x) - (1/4)e^(2x) + C.'
      },
      {
        id: 'qc2',
        question: 'What is the radius of convergence for the series sum_{n=1}^inf (x^n / n)?',
        options: ['R = 0', 'R = 1', 'R = infinity', 'R = 2'],
        correctIndex: 1,
        explanation: 'Applying the ratio test: lim |a_(n+1)/a_n| = lim |x^(n+1)/(n+1) * n/x^n| = |x| lim (n/(n+1)) = |x|. For convergence, |x| < 1, so R = 1.'
      }
    ]
  }
];

export const INITIAL_COMMUNITY_POSTS: CommunityPost[] = [
  {
    id: 'post-1',
    authorId: 'usr-charlotte',
    authorName: 'Charlotte Bennett',
    authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    authorRole: 'Senior Pre-Med',
    channel: '#biology-squad',
    subject: 'Cellular Biology',
    title: 'Intuitive trick to remember the Citric Acid Cycle intermediates!',
    content: `Struggling with Krebs cycle memorization? Here is the mnemonic that saved my grade in biochem:

**"Can I Keep Selling Substances For Money, Officer?"**

- **C**itrate
- **I**socitrate
- **K**etoglutarate (alpha)
- **S**uccinyl-CoA
- **S**uccinate
- **F**umarate
- **M**alate
- **O**xaloacetate

Also remember: NADH is made at Steps 3, 4, and 8. GTP/ATP at Step 5. FADH2 at Step 6! Hope this helps everyone revising for midterms this week!`,
    tags: ['KrebsCycle', 'Mnemonics', 'BiochemHelp'],
    likes: 42,
    hasLiked: true,
    isBookmarked: true,
    createdAt: '2026-10-17T18:10:00Z',
    comments: [
      {
        id: 'c1',
        authorId: 'usr-marcus',
        authorName: 'Marcus Vance',
        authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        authorRole: 'Biochem Sophomore',
        content: 'This mnemonic is absolute gold. Saved me 3 hours of rote flashcard grinding.',
        createdAt: '2026-10-17T19:30:00Z',
        likes: 8,
      },
      {
        id: 'c2',
        authorId: 'usr-student-1',
        authorName: 'Alex Rivera',
        authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        authorRole: 'Student',
        content: 'Thank you Charlotte! Added directly to my StudySphere notes.',
        createdAt: '2026-10-18T08:15:00Z',
        likes: 3,
      }
    ]
  },
  {
    id: 'post-2',
    authorId: 'usr-david',
    authorName: 'David Kim',
    authorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    authorRole: 'CS Junior',
    channel: '#tech-coders',
    subject: 'Data Structures',
    title: 'Visualizing Dijkstra vs A* Search for coding interviews',
    content: `When asked about shortest path on weighted graphs, think of Dijkstra as expanding an isotropic circle (uniform cost wave), while A* injects an admissible heuristic (h(n)) that stretches the wave directly toward the target goal.

If your heuristic h(n) <= true distance, A* is mathematically guaranteed to be optimal!`,
    tags: ['Algorithms', 'Graphs', 'Interviews'],
    likes: 29,
    hasLiked: false,
    isBookmarked: false,
    createdAt: '2026-10-16T11:45:00Z',
    comments: []
  }
];

export const INITIAL_STUDY_ROOMS: StudyRoom[] = [
  {
    id: 'room-1',
    name: '24/7 Silent Deep Focus Library',
    subject: 'All Subjects',
    description: 'Camera on/off, strictly silent ambient study with shared Pomodoro timers.',
    activeCount: 18,
    maxMembers: 30,
    isPrivate: false,
    currentTopic: 'Pomodoro Interval #3 - Focus Phase',
    timerMinutes: 21,
    members: [
      { name: 'Alex Rivera (You)', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80', status: 'Focusing on Cellular Biology' },
      { name: 'Charlotte B.', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80', status: 'Reviewing Flashcards' },
      { name: 'David Kim', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80', status: 'Solving Tree Problems' },
      { name: 'Amina Noor', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80', status: 'Reading Chapter 4' },
    ]
  },
  {
    id: 'room-2',
    name: 'MCAT & Pre-Med Bio Cram Group',
    subject: 'Cellular Biology',
    description: 'Active discussion on enzyme kinetics, metabolism, and question dissections.',
    activeCount: 7,
    maxMembers: 12,
    isPrivate: false,
    currentTopic: 'Lineweaver-Burk Inhibitor Plots',
    timerMinutes: 14,
    members: [
      { name: 'Charlotte B.', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80', status: 'Explaining Question #3' },
      { name: 'Siddharth M.', avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80', status: 'Taking Notes' }
    ]
  },
  {
    id: 'room-3',
    name: 'Calculus II Problem Solving War Room',
    subject: 'Calculus II',
    description: 'Grinding integration by parts and trigonometric substitution drills together.',
    activeCount: 5,
    maxMembers: 10,
    isPrivate: false,
    currentTopic: 'Section 7.3 Trig Substitution',
    timerMinutes: 18,
    members: [
      { name: 'Marcus Vance', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80', status: 'Working on Problem #12' }
    ]
  }
];

export const INITIAL_BADGES: Badge[] = [
  {
    id: 'badge-streak-7',
    title: '7-Day Streak Warrior',
    description: 'Studied consistently for 7 consecutive days without breaking flow.',
    icon: '🔥',
    unlockedAt: '2026-10-18',
    category: 'streak',
  },
  {
    id: 'badge-pomo-10',
    title: 'Pomodoro Virtuoso',
    description: 'Completed 10 deep focus intervals with zero distractions.',
    icon: '⏱️',
    unlockedAt: '2026-10-16',
    category: 'pomodoro',
  },
  {
    id: 'badge-quiz-ace',
    title: 'Quiz Ace',
    description: 'Scored 100% on a Hard difficulty practice exam.',
    icon: '🎯',
    unlockedAt: '2026-10-14',
    category: 'quiz',
  },
  {
    id: 'badge-ai-scholar',
    title: 'Socratic Thinker',
    description: 'Completed 5 Socratic dialogue sessions with StudySphere AI.',
    icon: '🧠',
    unlockedAt: '2026-10-17',
    category: 'notes',
  },
  {
    id: 'badge-community-star',
    title: 'Community Beacon',
    description: 'Received 20+ likes from classmates on helpful explanations.',
    icon: '🌟',
    unlockedAt: undefined,
    category: 'community',
  },
  {
    id: 'badge-flash-master',
    title: 'Active Recall Titan',
    description: 'Reviewed 100 flashcards across multiple subject decks.',
    icon: '🃏',
    unlockedAt: undefined,
    category: 'notes',
  }
];

export const INITIAL_DAILY_MISSIONS: DailyMission[] = [
  {
    id: 'mis-1',
    title: 'Complete 1 Pomodoro Focus Session (25 min)',
    rewardXp: 50,
    completed: true,
    icon: '⏱️',
  },
  {
    id: 'mis-2',
    title: 'Review 10 Spaced Repetition Flashcards',
    rewardXp: 40,
    completed: true,
    icon: '🃏',
  },
  {
    id: 'mis-3',
    title: 'Ask StudySphere AI 1 academic question',
    rewardXp: 30,
    completed: false,
    icon: '🤖',
  },
  {
    id: 'mis-4',
    title: 'Score 80%+ on an end-of-topic quiz',
    rewardXp: 60,
    completed: false,
    icon: '🎯',
  }
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    title: '🔥 Daily Streak Preserved!',
    message: 'Awesome work Alex! You reached a 7-day study streak today. +50 bonus XP awarded.',
    type: 'streak',
    timestamp: '10 mins ago',
    read: false,
  },
  {
    id: 'notif-2',
    title: '📅 Exam Approaching: Cellular Biology Midterm',
    message: 'Your midterm is scheduled in 5 days. Recommended: review Enzyme Kinetics flashcard deck.',
    type: 'exam',
    timestamp: '2 hours ago',
    read: false,
    actionUrl: 'revision',
  },
  {
    id: 'notif-3',
    title: '💬 Charlotte replied to your comment in #biology-squad',
    message: '"Thanks for the tip on the Lineweaver-Burk intercepts!"',
    type: 'community',
    timestamp: 'Yesterday',
    read: true,
    actionUrl: 'community',
  }
];
