import React, { useState } from 'react';
import {
  User,
  Settings,
  Download,
  RotateCcw,
  Shield,
  Bell,
  Moon,
  Sun,
  BookOpen,
  Award,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const ProfileSettings: React.FC = () => {
  const {
    user,
    updateProfile,
    theme,
    setTheme,
    resetAllData,
    notes,
    tasks,
    flashcards,
    quizAttempts,
    badges,
  } = useApp();

  const [name, setName] = useState(user?.name || '');
  const [institution, setInstitution] = useState(user?.institution || '');
  const [dailyHours, setDailyHours] = useState(user?.dailyHoursTarget || 4);
  const [preferredSchedule, setPreferredSchedule] = useState(user?.preferredSchedule || 'evening');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name,
      institution,
      dailyHoursTarget: dailyHours,
      preferredSchedule,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleExportData = () => {
    const backup = {
      profile: user,
      notes,
      tasks,
      flashcards,
      quizAttempts,
      exportedAt: new Date().toISOString(),
      platform: 'StudySphere All-in-One Super App',
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `StudySphere_Backup_${user?.name.replace(/\s+/g, '_')}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleResetData = () => {
    if (confirm('Are you sure you want to reset all local changes and restore seed demo data?')) {
      resetAllData();
      window.location.reload();
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
          <Settings className="w-6 h-6 text-violet-400" />
          <span>User Profile & Academic Preferences</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Customize your syllabus profile, notification quiet hours, theme, and data export.
        </p>
      </div>

      {/* Profile Overview Card */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-center gap-6">
        <img
          src={user?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
          alt={user?.name}
          className="w-20 h-20 rounded-full object-cover border-2 border-violet-500 ring-4 ring-violet-500/20"
        />
        <div className="space-y-1 text-center sm:text-left flex-1">
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
            <h2 className="text-lg font-bold text-white">{user?.name}</h2>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-violet-600/30 text-violet-300 border border-violet-500/40 uppercase">
              {user?.tier || 'Pro'}
            </span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 capitalize">
              {user?.role}
            </span>
          </div>
          <p className="text-xs text-slate-400">{user?.email}</p>
          <p className="text-xs text-slate-400">{user?.institution} • Level {user?.level} Scholar ({user?.totalXp} XP)</p>
        </div>
      </div>

      {/* Unlocked Badges Showcase */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Achievements & Badges</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {badges.map(b => (
            <div
              key={b.id}
              className={`p-3.5 rounded-2xl border text-xs flex items-center gap-3 ${
                b.unlockedAt
                  ? 'bg-slate-950 border-slate-800 text-slate-200'
                  : 'bg-slate-950/40 border-slate-800/60 text-slate-600 opacity-60'
              }`}
            >
              <span className="text-2xl">{b.icon}</span>
              <div>
                <p className="font-bold text-white">{b.title}</p>
                <p className="text-[10px] text-slate-400 leading-tight">{b.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Edit Form */}
      <form onSubmit={handleSave} className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Academic Details</h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Display Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none focus:border-violet-500"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">School / Institution</label>
            <input
              type="text"
              value={institution}
              onChange={(e) => setInstitution(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none focus:border-violet-500"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Daily Study Hours Target ({dailyHours}h)</label>
            <input
              type="range"
              min="1"
              max="8"
              step="0.5"
              value={dailyHours}
              onChange={(e) => setDailyHours(parseFloat(e.target.value))}
              className="w-full accent-violet-500"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Peak Concentration Time</label>
            <select
              value={preferredSchedule}
              onChange={(e) => setPreferredSchedule(e.target.value as any)}
              className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none"
            >
              <option value="morning">Morning (06:00 - 12:00)</option>
              <option value="afternoon">Afternoon (12:00 - 17:00)</option>
              <option value="evening">Evening (17:00 - 22:00)</option>
              <option value="night">Late Night (22:00+)</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2">
          {savedSuccess && (
            <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-4 h-4" /> Changes saved successfully!
            </span>
          )}
          <button
            type="submit"
            className="ml-auto px-5 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs transition shadow-md shadow-violet-900/40 cursor-pointer"
          >
            Save Preferences
          </button>
        </div>
      </form>

      {/* Theme & Data Controls */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Application Preferences</h3>

        <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs">
          <div className="flex items-center gap-2">
            {theme === 'dark' ? <Moon className="w-4 h-4 text-violet-400" /> : <Sun className="w-4 h-4 text-amber-400" />}
            <span className="text-slate-200 font-medium">Interface Color Theme</span>
          </div>

          <div className="flex rounded-xl bg-slate-900 p-1 border border-slate-800 text-xs">
            <button
              onClick={() => setTheme('dark')}
              className={`px-3 py-1 rounded-lg font-semibold transition ${theme === 'dark' ? 'bg-violet-600 text-white' : 'text-slate-400'}`}
            >
              Dark Mode
            </button>
            <button
              onClick={() => setTheme('light')}
              className={`px-3 py-1 rounded-lg font-semibold transition ${theme === 'light' ? 'bg-violet-600 text-white' : 'text-slate-400'}`}
            >
              Light Mode
            </button>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
          <button
            onClick={handleExportData}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-slate-700 bg-slate-950 hover:bg-slate-800 text-slate-300 text-xs font-semibold transition"
          >
            <Download className="w-4 h-4" />
            <span>Export All Notes & Progress (JSON)</span>
          </button>

          <button
            onClick={handleResetData}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-rose-500/30 bg-rose-950/20 hover:bg-rose-950/40 text-rose-300 text-xs font-semibold transition"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset Demo Data</span>
          </button>
        </div>
      </div>
    </div>
  );
};
