import React, { useState } from 'react';
import {
  FileText,
  Search,
  Plus,
  Pin,
  Star,
  Trash2,
  Sparkles,
  Brain,
  Download,
  FileType,
  History,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Note } from '../../types';
import { generateNotesSummary } from '../../services/aiService';
import { ExportModal } from './ExportModal';
import { VersionHistoryModal } from './VersionHistoryModal';
import { exportNoteToPdf, exportNoteToMarkdown } from '../../utils/exportUtils';

export const NotesManager: React.FC = () => {
  const {
    notes,
    addNote,
    updateNote,
    deleteNote,
    togglePinNote,
    toggleFavoriteNote,
    addFlashcard,
    addQuiz,
    setActiveTab,
    user,
  } = useApp();

  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(notes[0]?.id || null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState('All');
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isVersionHistoryOpen, setIsVersionHistoryOpen] = useState(false);

  const selectedNote = notes.find(n => n.id === selectedNoteId) || notes[0];

  const subjects = ['All', ...new Set(notes.map(n => n.subject))];

  const filteredNotes = notes.filter(n => {
    const matchesSubject = selectedSubjectFilter === 'All' || n.subject === selectedSubjectFilter;
    const matchesSearch = n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          n.content.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSubject && matchesSearch;
  });

  const handleCreateNew = () => {
    const newNote = addNote({
      title: 'Untitled Study Note',
      content: '# New Concept\n\nStart typing notes, definitions, formulas, or copy-paste lecture transcripts here...',
      subject: user?.subjects[0] || 'General Studies',
      tags: ['revision'],
      isPinned: false,
      isFavorite: false,
    });
    setSelectedNoteId(newNote.id);
  };

  const handleAISummarize = async () => {
    if (!selectedNote || isSummarizing) return;
    setIsSummarizing(true);
    try {
      const result = await generateNotesSummary({
        noteTitle: selectedNote.title,
        noteContent: selectedNote.content,
        subject: selectedNote.subject,
      });

      updateNote(selectedNote.id, {
        summary: result.summary,
      });

      // If flashcards were extracted, import them into the deck
      if (result.flashcards && result.flashcards.length > 0) {
        result.flashcards.forEach(fc => {
          addFlashcard({
            subject: selectedNote.subject,
            deckId: 'deck-' + selectedNote.id,
            question: fc.question,
            answer: fc.answer,
          });
        });
        alert(`AI summarized your note and generated ${result.flashcards.length} flashcards in your deck!`);
      } else {
        alert('Executive summary generated successfully!');
      }
    } catch {
      alert('Failed to generate summary.');
    } finally {
      setIsSummarizing(false);
    }
  };

  const handleQuickExportSummaryPdf = () => {
    if (!selectedNote || !selectedNote.summary) return;
    exportNoteToPdf({
      title: selectedNote.title,
      subject: selectedNote.subject,
      content: selectedNote.content,
      summary: selectedNote.summary,
      authorName: user?.name || 'Alex Rivera',
      tags: selectedNote.tags,
      createdAt: selectedNote.createdAt,
      scope: 'summary_only',
    });
  };

  const handleQuickExportSummaryMd = () => {
    if (!selectedNote || !selectedNote.summary) return;
    exportNoteToMarkdown({
      title: selectedNote.title,
      subject: selectedNote.subject,
      content: selectedNote.content,
      summary: selectedNote.summary,
      authorName: user?.name || 'Alex Rivera',
      tags: selectedNote.tags,
      createdAt: selectedNote.createdAt,
      scope: 'summary_only',
    });
  };

  const handleCreateQuizFromNote = () => {
    if (!selectedNote) return;
    addQuiz({
      id: 'quiz-' + Date.now(),
      title: `Assessment: ${selectedNote.title}`,
      subject: selectedNote.subject,
      topic: selectedNote.title,
      difficulty: 'medium',
      timeLimitMinutes: 8,
      questions: [
        {
          id: 'q1',
          question: `What is the primary thesis of "${selectedNote.title}"?`,
          options: [
            'Systematic relationship and operational mechanisms',
            'Arbitrary historical trivia',
            'Random unsupported conjecture',
            'None of the above'
          ],
          correctIndex: 0,
          explanation: 'As identified in the study notes, this concept establishes consistent operational laws.',
        },
      ],
    });
    setActiveTab('revision');
  };

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col md:flex-row max-w-7xl mx-auto p-3 sm:p-6 gap-4">
      {/* Left Sidebar: Notes List */}
      <div className="w-full md:w-80 flex flex-col rounded-3xl bg-slate-900 border border-slate-800 p-4 space-y-3 shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-bold text-white">Digital Notebook</h2>
          </div>
          <button
            onClick={handleCreateNew}
            className="p-1.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white transition cursor-pointer"
            title="Create New Note"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search notes or tags..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500"
          />
        </div>

        {/* Subject Filter */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 text-xs">
          {subjects.map(subj => (
            <button
              key={subj}
              onClick={() => setSelectedSubjectFilter(subj)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition cursor-pointer shrink-0 ${
                selectedSubjectFilter === subj
                  ? 'bg-violet-600 text-white font-semibold'
                  : 'bg-slate-950 text-slate-400 hover:text-white'
              }`}
            >
              {subj}
            </button>
          ))}
        </div>

        {/* Notes Scroll List */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1">
          {filteredNotes.map(n => {
            const isSelected = selectedNote?.id === n.id;

            return (
              <div
                key={n.id}
                onClick={() => setSelectedNoteId(n.id)}
                className={`p-3 rounded-2xl border transition cursor-pointer relative group text-left ${
                  isSelected
                    ? 'bg-violet-950/30 border-violet-500/60 shadow-sm'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-violet-300 font-medium">
                    {n.subject}
                  </span>
                  <div className="flex items-center gap-1">
                    {n.isPinned && <Pin className="w-3 h-3 text-amber-400 fill-amber-400" />}
                    {n.isFavorite && <Star className="w-3 h-3 text-amber-400 fill-amber-400" />}
                  </div>
                </div>

                <h4 className="text-xs font-semibold text-white truncate">{n.title}</h4>
                <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">{n.content.replace(/[#*]/g, '')}</p>

                <div className="flex items-center justify-between text-[9px] text-slate-500 mt-2">
                  <span>{n.updatedAt.split('T')[0]}</span>
                  <span>{n.tags.join(', ')}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right Column: Note Editor */}
      {selectedNote ? (
        <div className="flex-1 flex flex-col rounded-3xl bg-slate-900 border border-slate-800 p-4 sm:p-6 overflow-hidden">
          {/* Header Controls */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800 shrink-0">
            <div className="flex-1">
              <input
                type="text"
                value={selectedNote.title}
                onChange={(e) => updateNote(selectedNote.id, { title: e.target.value })}
                className="w-full text-base sm:text-lg font-bold text-white bg-transparent outline-none focus:border-b focus:border-violet-500 font-sans"
              />
              <div className="flex items-center gap-2 mt-1">
                <span className="text-[11px] text-slate-400">Subject:</span>
                <input
                  type="text"
                  value={selectedNote.subject}
                  onChange={(e) => updateNote(selectedNote.id, { subject: e.target.value })}
                  className="text-[11px] font-semibold text-violet-300 bg-slate-950 px-2 py-0.5 rounded border border-slate-800 outline-none"
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => togglePinNote(selectedNote.id)}
                className={`p-2 rounded-xl border transition ${
                  selectedNote.isPinned
                    ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                }`}
                title="Pin Note"
              >
                <Pin className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => toggleFavoriteNote(selectedNote.id)}
                className={`p-2 rounded-xl border transition ${
                  selectedNote.isFavorite
                    ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                }`}
                title="Favorite Note"
              >
                <Star className="w-3.5 h-3.5" />
              </button>

              {/* Version History Button */}
              <button
                onClick={() => setIsVersionHistoryOpen(true)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 text-xs font-semibold transition cursor-pointer shadow-xs"
                title="View note revision timeline and restore previous versions"
              >
                <History className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline">History</span>
                {(selectedNote.history?.length || 0) > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-cyan-950 text-cyan-300 text-[10px] border border-cyan-800/60 font-mono">
                    {selectedNote.history?.length}
                  </span>
                )}
              </button>

              {/* Enhanced Export Document Button */}
              <button
                onClick={() => setIsExportModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-violet-600/20 hover:bg-violet-600/30 border border-violet-500/40 text-violet-300 text-xs font-semibold transition cursor-pointer shadow-xs"
                title="Export as PDF or Markdown"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export PDF / MD</span>
              </button>

              <button
                onClick={() => deleteNote(selectedNote.id)}
                className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-rose-400 transition"
                title="Delete Note"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* AI Actions Ribbon */}
          <div className="py-2.5 px-3 my-3 rounded-2xl bg-slate-950/80 border border-slate-800/80 flex flex-wrap items-center justify-between gap-2 shrink-0">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-violet-400" />
              <span className="text-xs font-semibold text-slate-300">AI Note Enhancements:</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleAISummarize}
                disabled={isSummarizing}
                className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-violet-600 hover:bg-violet-500 disabled:opacity-50 text-white text-xs font-semibold transition cursor-pointer"
              >
                <Sparkles className={`w-3 h-3 ${isSummarizing ? 'animate-spin' : ''}`} />
                <span>{isSummarizing ? 'Summarizing...' : 'Summarize & Extract Flashcards'}</span>
              </button>

              <button
                onClick={handleCreateQuizFromNote}
                className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-indigo-200 text-xs font-semibold transition cursor-pointer"
              >
                <Brain className="w-3 h-3" />
                <span>Create Quiz</span>
              </button>
            </div>
          </div>

          {/* AI Executive Summary with Quick Export Buttons */}
          {selectedNote.summary && (
            <div className="p-4 mb-3 rounded-2xl bg-violet-950/20 border border-violet-500/30 space-y-2 text-xs shrink-0 max-h-48 overflow-y-auto">
              <div className="flex items-center justify-between text-violet-400 font-bold">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> AI Executive Study Summary
                </span>
                {/* Quick export actions for summary */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleQuickExportSummaryPdf}
                    className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-violet-900/60 hover:bg-violet-800 text-[10px] text-violet-200 border border-violet-500/30 transition"
                    title="Download summary as structured PDF"
                  >
                    <FileType className="w-3 h-3 text-violet-400" />
                    <span>Summary PDF</span>
                  </button>
                  <button
                    onClick={handleQuickExportSummaryMd}
                    className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-900 hover:bg-slate-800 text-[10px] text-slate-300 border border-slate-700 transition"
                    title="Download summary as Markdown file"
                  >
                    <FileText className="w-3 h-3 text-emerald-400" />
                    <span>Summary MD</span>
                  </button>
                </div>
              </div>
              <div className="text-slate-300 leading-relaxed whitespace-pre-wrap">{selectedNote.summary}</div>
            </div>
          )}

          {/* Markdown Content Editor */}
          <div className="flex-1 overflow-y-auto">
            <textarea
              value={selectedNote.content}
              onChange={(e) => updateNote(selectedNote.id, { content: e.target.value })}
              placeholder="Write rich notes here (Markdown supported: # Headings, - Lists, equations)..."
              className="w-full h-full p-2 bg-transparent text-slate-200 text-xs sm:text-sm leading-relaxed outline-none resize-none font-sans"
            />
          </div>

          {/* Export Modal Dialog */}
          <ExportModal
            note={selectedNote}
            authorName={user?.name || 'Alex Rivera'}
            isOpen={isExportModalOpen}
            onClose={() => setIsExportModalOpen(false)}
          />

          {/* Version History Modal Dialog */}
          <VersionHistoryModal
            note={selectedNote}
            isOpen={isVersionHistoryOpen}
            onClose={() => setIsVersionHistoryOpen(false)}
          />
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center text-slate-500 text-xs rounded-3xl bg-slate-900 border border-slate-800">
          <FileText className="w-12 h-12 text-slate-700 mb-2" />
          <span>Select or create a study note to begin writing.</span>
        </div>
      )}
    </div>
  );
};
