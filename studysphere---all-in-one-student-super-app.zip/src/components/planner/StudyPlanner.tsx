import React, { useState, useEffect } from 'react';
import {
  Calendar as CalendarIcon,
  CheckCircle2,
  Plus,
  Trash2,
  Clock,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  AlertTriangle,
  Coffee,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Task } from '../../types';
import { generateStudyPlanFromAI } from '../../services/aiService';

export const StudyPlanner: React.FC = () => {
  const {
    tasks,
    addTask,
    toggleTask,
    deleteTask,
    awardXp,
    user,
  } = useApp();

  const [calendarView, setCalendarView] = useState<'day' | 'week' | 'month'>('week');
  const [filterSubject, setFilterSubject] = useState('All');

  // New task form state
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskSubject, setNewTaskSubject] = useState(user?.subjects[0] || 'General Studies');
  const [newTaskDue, setNewTaskDue] = useState('2026-10-21');
  const [newTaskMinutes, setNewTaskMinutes] = useState(45);
  const [newTaskPriority, setNewTaskPriority] = useState<'low' | 'medium' | 'high' | 'urgent'>('medium');

  // Pomodoro Focus Timer state
  const [pomoMode, setPomoMode] = useState<'focus' | 'short_break' | 'long_break'>('focus');
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [sessionsCompleted, setSessionsCompleted] = useState(1);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // AI Timetable Generator Modal
  const [isAiPlanOpen, setIsAiPlanOpen] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);
  const [generatedPlan, setGeneratedPlan] = useState<any>(null);

  // Pomodoro countdown effect
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (isRunning && timeLeft === 0) {
      // Completed interval
      if (pomoMode === 'focus') {
        awardXp(50, 'Completed Pomodoro Focus Interval');
        setSessionsCompleted(prev => prev + 1);
        setPomoMode('short_break');
        setTimeLeft(5 * 60);
        alert('🎉 Focus session completed! Take a 5-minute restorative break.');
      } else {
        setPomoMode('focus');
        setTimeLeft(25 * 60);
        alert('Break ended! Ready to focus on your next goal?');
      }
      setIsRunning(false);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, timeLeft, pomoMode, awardXp]);

  const switchPomoMode = (mode: 'focus' | 'short_break' | 'long_break') => {
    setIsRunning(false);
    setPomoMode(mode);
    if (mode === 'focus') setTimeLeft(25 * 60);
    else if (mode === 'short_break') setTimeLeft(5 * 60);
    else setTimeLeft(15 * 60);
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    addTask({
      title: newTaskTitle,
      subject: newTaskSubject,
      dueDate: newTaskDue,
      estimatedMinutes: newTaskMinutes,
      priority: newTaskPriority,
      type: 'assignment',
    });

    setNewTaskTitle('');
    setIsAddingTask(false);
  };

  const handleGenerateAiPlan = async () => {
    setAiGenerating(true);
    try {
      const plan = await generateStudyPlanFromAI({
        subjects: user?.subjects || ['Cellular Biology', 'Calculus II'],
        dailyHours: user?.dailyHoursTarget || 4,
        exams: ['Cellular Biology Midterm (5 days)', 'Calculus Exam (12 days)'],
        targetGoal: user?.learningGoals[0] || 'Top GPA',
      });
      setGeneratedPlan(plan);
    } catch {
      alert('Failed to generate timetable.');
    } finally {
      setAiGenerating(false);
    }
  };

  const handleApplyAiBlocks = () => {
    if (!generatedPlan?.blocks) return;
    generatedPlan.blocks.slice(0, 4).forEach((b: any) => {
      addTask({
        title: `AI Block: ${b.activity}`,
        subject: b.focus,
        dueDate: '2026-10-20',
        estimatedMinutes: parseInt(b.duration) || 60,
        priority: b.priority === 'High' ? 'urgent' : 'medium',
        type: 'exam_prep',
      });
    });
    alert('Imported AI schedule blocks into your active study planner!');
    setIsAiPlanOpen(false);
  };

  const filteredTasks = tasks.filter(t => filterSubject === 'All' || t.subject === filterSubject);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <CalendarIcon className="w-6 h-6 text-violet-400" />
            <span>Smart Study Planner & Pomodoro</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Plan deadlines, balance cognitive intervals, and generate optimized AI revision timetables.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => { setIsAiPlanOpen(true); handleGenerateAiPlan(); }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-violet-600/20 border border-violet-500/40 text-violet-300 hover:bg-violet-600/30 text-xs font-semibold transition cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-violet-400" />
            <span>Generate AI Timetable</span>
          </button>

          <button
            onClick={() => setIsAddingTask(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold transition shadow-md shadow-violet-900/40 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Study Task</span>
          </button>
        </div>
      </div>

      {/* Grid: Left Column Pomodoro Focus Engine, Right Column Task Planner */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Pomodoro Focus Timer Card */}
        <div className="rounded-3xl bg-slate-900 border border-slate-800 p-6 flex flex-col justify-between space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-rose-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">Pomodoro Focus Timer</span>
            </div>
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="text-slate-400 hover:text-white"
              title="Ambient audio chime"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-violet-400" /> : <VolumeX className="w-4 h-4" />}
            </button>
          </div>

          {/* Mode Switcher */}
          <div className="flex rounded-2xl bg-slate-950 p-1 border border-slate-800 text-xs">
            <button
              onClick={() => switchPomoMode('focus')}
              className={`flex-1 py-1.5 rounded-xl font-semibold transition cursor-pointer ${
                pomoMode === 'focus' ? 'bg-violet-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Focus (25m)
            </button>
            <button
              onClick={() => switchPomoMode('short_break')}
              className={`flex-1 py-1.5 rounded-xl font-semibold transition cursor-pointer ${
                pomoMode === 'short_break' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Short Break (5m)
            </button>
            <button
              onClick={() => switchPomoMode('long_break')}
              className={`flex-1 py-1.5 rounded-xl font-semibold transition cursor-pointer ${
                pomoMode === 'long_break' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Long (15m)
            </button>
          </div>

          {/* Huge Timer Clock */}
          <div className="text-center py-4">
            <div className="text-5xl sm:text-6xl font-mono font-extrabold text-white tracking-tight drop-shadow-md">
              {formatTimer(timeLeft)}
            </div>
            <p className="text-xs text-slate-400 mt-2">
              {pomoMode === 'focus' ? 'Stay immersed with zero tab switching' : 'Stretch, hydrate, and relax your eyes'}
            </p>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-3">
            <button
              onClick={() => setIsRunning(!isRunning)}
              className={`px-8 py-3 rounded-2xl font-bold text-xs flex items-center gap-2 transition shadow-lg cursor-pointer ${
                isRunning
                  ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-900/30'
                  : 'bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white shadow-violet-900/40'
              }`}
            >
              {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
              <span>{isRunning ? 'Pause Interval' : 'Start Focus Session'}</span>
            </button>

            <button
              onClick={() => switchPomoMode(pomoMode)}
              className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-white transition"
              title="Reset Timer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          {/* Stats footer */}
          <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span>Intervals today: <strong className="text-white">{sessionsCompleted}</strong></span>
            <span className="text-amber-400 font-semibold">+50 XP per completed session</span>
          </div>
        </div>

        {/* Right Column (2 Cols): Task Manager & Calendar */}
        <div className="lg:col-span-2 space-y-4">
          {/* Calendar View Toggle & Subject Filter */}
          <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">View:</span>
              <div className="flex rounded-xl bg-slate-950 p-1 border border-slate-800 text-xs">
                {(['day', 'week', 'month'] as const).map(v => (
                  <button
                    key={v}
                    onClick={() => setCalendarView(v)}
                    className={`px-3 py-1 rounded-lg capitalize font-medium transition cursor-pointer ${
                      calendarView === v ? 'bg-violet-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-400">Subject:</span>
              <select
                value={filterSubject}
                onChange={(e) => setFilterSubject(e.target.value)}
                className="px-2.5 py-1 rounded-xl bg-slate-950 border border-slate-800 text-violet-300 outline-none"
              >
                <option value="All">All Subjects</option>
                {user?.subjects.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>

          {/* New Task Inline Modal/Form */}
          {isAddingTask && (
            <form onSubmit={handleCreateTask} className="p-5 rounded-3xl bg-slate-900 border border-violet-500/50 space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Schedule New Academic Task</h4>
              <div>
                <input
                  type="text"
                  required
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  placeholder="Task title (e.g. Read Chapter 4 & Solve Problem Set #2)"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 outline-none focus:border-violet-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">Subject</label>
                  <input
                    type="text"
                    required
                    value={newTaskSubject}
                    onChange={(e) => setNewTaskSubject(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">Due Date</label>
                  <input
                    type="date"
                    required
                    value={newTaskDue}
                    onChange={(e) => setNewTaskDue(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">Priority</label>
                  <select
                    value={newTaskPriority}
                    onChange={(e) => setNewTaskPriority(e.target.value as any)}
                    className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddingTask(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold"
                >
                  Save Task
                </button>
              </div>
            </form>
          )}

          {/* Task List */}
          <div className="rounded-3xl bg-slate-900 border border-slate-800 p-5 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Scheduled Academic Items ({filteredTasks.length})</h3>

            <div className="space-y-2">
              {filteredTasks.length === 0 ? (
                <div className="text-center py-10 text-slate-500 text-xs">
                  No pending tasks in this filter. Tap &quot;Add Study Task&quot; to organize your syllabus.
                </div>
              ) : (
                filteredTasks.map(t => (
                  <div
                    key={t.id}
                    className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800/80 hover:border-slate-700 transition"
                  >
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => toggleTask(t.id)}
                        className={`w-5 h-5 rounded-lg border flex items-center justify-center transition cursor-pointer ${
                          t.completed
                            ? 'bg-emerald-500 border-emerald-500 text-white'
                            : 'border-slate-700 hover:border-violet-500 text-transparent'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      </button>

                      <div>
                        <p className={`text-xs font-semibold ${t.completed ? 'line-through text-slate-500' : 'text-slate-100'}`}>
                          {t.title}
                        </p>
                        <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                          <span className="px-1.5 py-0.2 rounded bg-slate-800 text-violet-300">{t.subject}</span>
                          <span>Due: {t.dueDate}</span>
                          <span>• {t.estimatedMinutes} min</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded-full capitalize ${
                          t.priority === 'urgent'
                            ? 'bg-rose-500/20 text-rose-300'
                            : t.priority === 'high'
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {t.priority}
                      </span>

                      <button
                        onClick={() => deleteTask(t.id)}
                        className="p-1 rounded text-slate-500 hover:text-rose-400"
                        title="Delete Task"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* AI Timetable Modal */}
      {isAiPlanOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={() => setIsAiPlanOpen(false)}>
          <div
            className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 shadow-2xl text-slate-100 max-h-[85vh] overflow-y-auto space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-violet-400" />
                <h3 className="text-base font-bold text-white">AI-Optimized Revision Timetable</h3>
              </div>
              <button onClick={() => setIsAiPlanOpen(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            {aiGenerating ? (
              <div className="py-12 text-center space-y-3">
                <Sparkles className="w-8 h-8 text-violet-400 animate-spin mx-auto" />
                <p className="text-xs text-slate-300">Computing optimal cognitive load distribution for your subjects...</p>
              </div>
            ) : generatedPlan ? (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-violet-950/20 border border-violet-500/30 text-xs space-y-1">
                  <h4 className="font-bold text-violet-300">{generatedPlan.planTitle}</h4>
                  <p className="text-slate-300 leading-relaxed">{generatedPlan.strategy}</p>
                </div>

                <div className="space-y-2">
                  <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Suggested Weekly Blocks</h5>
                  {generatedPlan.blocks?.map((block: any, i: number) => (
                    <div key={i} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-semibold text-white">{block.day} • {block.focus}</span>
                        <p className="text-[11px] text-slate-400">{block.activity}</p>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-violet-300 font-mono">{block.duration}</span>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                  <button
                    onClick={() => setIsAiPlanOpen(false)}
                    className="px-4 py-2 text-xs text-slate-400 hover:text-white"
                  >
                    Close
                  </button>
                  <button
                    onClick={handleApplyAiBlocks}
                    className="px-5 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold transition shadow-md shadow-violet-900/40"
                  >
                    Import Schedule into My Planner
                  </button>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
};
