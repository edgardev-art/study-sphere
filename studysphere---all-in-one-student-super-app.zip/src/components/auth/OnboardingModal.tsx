import React, { useState } from 'react';
import { Sparkles, ArrowRight, Check, School, BookOpen, Target, Clock, AlertCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { EducationLevel } from '../../types';

export const OnboardingModal: React.FC = () => {
  const { isOnboardingModalOpen, completeOnboarding, user } = useApp();

  const [step, setStep] = useState(1);
  const [educationLevel, setEducationLevel] = useState<EducationLevel>(user?.educationLevel || 'undergraduate');
  const [institution, setInstitution] = useState(user?.institution || '');
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>(user?.subjects || ['Cellular Biology', 'Calculus II']);
  const [learningGoals, setLearningGoals] = useState<string[]>(user?.learningGoals || ['Maintain a 3.8+ GPA']);
  const [preferredSchedule, setPreferredSchedule] = useState<'morning' | 'afternoon' | 'evening' | 'night'>(user?.preferredSchedule || 'evening');
  const [dailyHoursTarget, setDailyHoursTarget] = useState(user?.dailyHoursTarget || 3);
  const [academicChallenges, setAcademicChallenges] = useState<string[]>(user?.academicChallenges || ['Complex proofs']);

  if (!isOnboardingModalOpen) return null;

  const subjectOptions = [
    'Cellular Biology',
    'Calculus II',
    'Data Structures',
    'Microeconomics',
    'Organic Chemistry',
    'Physics (Mechanics)',
    'World History',
    'Cognitive Psychology',
    'Literature & Composition',
    'Statistics & Probability',
  ];

  const goalOptions = [
    'Maintain a 3.8+ GPA / Top Honors',
    'Prepare for Medical / Law / Grad Entrance (MCAT/LSAT/GRE)',
    'Deep Conceptual Understanding',
    'Stop Procrastinating & Build Daily Streak',
    'Ace Upcoming Final Exams',
    'Learn to Code & Build Projects',
  ];

  const challengeOptions = [
    'Procrastination & Distractions',
    'Complex Mathematical Proofs / Formulas',
    'Rote Memorization of Pathways / Anatomy',
    'Exam Anxiety & Time Crunch',
    'Organizing Dispersed Study Notes',
    'Balancing Work and Academic Schedule',
  ];

  const toggleArrayItem = (list: string[], item: string, setter: (val: string[]) => void) => {
    if (list.includes(item)) {
      setter(list.filter(i => i !== item));
    } else {
      setter([...list, item]);
    }
  };

  const handleFinish = () => {
    completeOnboarding({
      educationLevel,
      institution,
      subjects: selectedSubjects.length > 0 ? selectedSubjects : ['General Studies'],
      learningGoals,
      preferredSchedule,
      dailyHoursTarget,
      academicChallenges,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-3xl p-6 sm:p-8 shadow-2xl text-slate-100 flex flex-col">
        {/* Progress Bar & Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span className="flex items-center gap-1.5 font-semibold text-violet-400">
              <Sparkles className="w-3.5 h-3.5" /> Personalizing StudySphere
            </span>
            <span>Step {step} of 4</span>
          </div>
          <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-violet-600 to-indigo-500 transition-all duration-300"
              style={{ width: `${(step / 4) * 100}%` }}
            />
          </div>
        </div>

        {/* Step 1: Education Level & School */}
        {step === 1 && (
          <div className="space-y-4">
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <School className="w-5 h-5 text-violet-400" /> What are you studying right now?
              </h3>
              <p className="text-xs text-slate-400">This calibrates AI tutor depth, practice questions, and pacing.</p>
            </div>

            <div className="grid grid-cols-2 gap-2.5 pt-2">
              {[
                { id: 'high_school', label: 'Secondary / High School', sub: 'GCSE, A-Levels, AP, IB' },
                { id: 'undergraduate', label: 'University / Undergraduate', sub: "Bachelor's degree & Pre-Med" },
                { id: 'postgraduate', label: 'Postgraduate / Master / PhD', sub: 'Advanced research & specialty' },
                { id: 'independent', label: 'Independent Learner', sub: 'Self-paced professional study' },
              ].map(lvl => (
                <button
                  key={lvl.id}
                  type="button"
                  onClick={() => setEducationLevel(lvl.id as EducationLevel)}
                  className={`p-3.5 rounded-2xl text-left border transition cursor-pointer ${
                    educationLevel === lvl.id
                      ? 'bg-violet-600/20 border-violet-500 text-white shadow-sm'
                      : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <p className="text-xs font-semibold">{lvl.label}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{lvl.sub}</p>
                </button>
              ))}
            </div>

            <div className="pt-2">
              <label className="block text-xs font-medium text-slate-300 mb-1">Institution or School (Optional)</label>
              <input
                type="text"
                value={institution}
                onChange={(e) => setInstitution(e.target.value)}
                placeholder="e.g. Oxford, Stanford, State Polytechnic"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500"
              />
            </div>
          </div>
        )}

        {/* Step 2: Subjects Studied */}
        {step === 2 && (
          <div className="space-y-4">
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-indigo-400" /> Choose your primary subjects
              </h3>
              <p className="text-xs text-slate-400">Select all subjects currently in your active term syllabus.</p>
            </div>

            <div className="flex flex-wrap gap-2 pt-2 max-h-60 overflow-y-auto">
              {subjectOptions.map(subj => {
                const selected = selectedSubjects.includes(subj);
                return (
                  <button
                    key={subj}
                    type="button"
                    onClick={() => toggleArrayItem(selectedSubjects, subj, setSelectedSubjects)}
                    className={`px-3 py-2 rounded-xl text-xs font-medium border transition cursor-pointer flex items-center gap-1.5 ${
                      selected
                        ? 'bg-violet-600 text-white border-violet-500 shadow-xs'
                        : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    {selected && <Check className="w-3.5 h-3.5" />}
                    <span>{subj}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 3: Goals & Study Time Target */}
        {step === 3 && (
          <div className="space-y-4">
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Target className="w-5 h-5 text-emerald-400" /> What are your main goals?
              </h3>
              <p className="text-xs text-slate-400">Your AI study planner will optimize daily schedules around these targets.</p>
            </div>

            <div className="space-y-2 pt-1">
              {goalOptions.map(goal => {
                const selected = learningGoals.includes(goal);
                return (
                  <button
                    key={goal}
                    type="button"
                    onClick={() => toggleArrayItem(learningGoals, goal, setLearningGoals)}
                    className={`w-full p-2.5 rounded-xl text-left text-xs border transition cursor-pointer flex items-center justify-between ${
                      selected
                        ? 'bg-emerald-950/30 border-emerald-500/60 text-emerald-200'
                        : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span>{goal}</span>
                    {selected && <Check className="w-4 h-4 text-emerald-400 shrink-0" />}
                  </button>
                );
              })}
            </div>

            <div className="pt-2">
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-slate-300 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-violet-400" /> Daily Target Study Hours:
                </span>
                <span className="font-bold text-violet-300">{dailyHoursTarget} hours / day</span>
              </div>
              <input
                type="range"
                min="1"
                max="8"
                step="0.5"
                value={dailyHoursTarget}
                onChange={(e) => setDailyHoursTarget(parseFloat(e.target.value))}
                className="w-full accent-violet-500 cursor-pointer"
              />
            </div>
          </div>
        )}

        {/* Step 4: Academic Challenges & Schedule */}
        {step === 4 && (
          <div className="space-y-4">
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-amber-400" /> Current Academic Challenges
              </h3>
              <p className="text-xs text-slate-400">We will tailor your Pomodoro breaks and AI Socratic modes to support you.</p>
            </div>

            <div className="space-y-2 pt-1">
              {challengeOptions.map(ch => {
                const selected = academicChallenges.includes(ch);
                return (
                  <button
                    key={ch}
                    type="button"
                    onClick={() => toggleArrayItem(academicChallenges, ch, setAcademicChallenges)}
                    className={`w-full p-2.5 rounded-xl text-left text-xs border transition cursor-pointer flex items-center justify-between ${
                      selected
                        ? 'bg-amber-950/30 border-amber-500/60 text-amber-200'
                        : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span>{ch}</span>
                    {selected && <Check className="w-4 h-4 text-amber-400 shrink-0" />}
                  </button>
                );
              })}
            </div>

            <div className="pt-2">
              <label className="block text-xs font-medium text-slate-300 mb-1.5">When is your focus sharpest?</label>
              <div className="grid grid-cols-4 gap-1.5 text-center text-xs">
                {(['morning', 'afternoon', 'evening', 'night'] as const).map(time => (
                  <button
                    key={time}
                    type="button"
                    onClick={() => setPreferredSchedule(time)}
                    className={`py-2 rounded-xl capitalize font-medium border transition cursor-pointer ${
                      preferredSchedule === time
                        ? 'bg-violet-600 text-white border-violet-500'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {time}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Footer Navigation */}
        <div className="mt-8 pt-4 border-t border-slate-800 flex items-center justify-between">
          {step > 1 ? (
            <button
              type="button"
              onClick={() => setStep(step - 1)}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition cursor-pointer"
            >
              Back
            </button>
          ) : (
            <div />
          )}

          {step < 4 ? (
            <button
              type="button"
              onClick={() => setStep(step + 1)}
              className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold transition cursor-pointer"
            >
              <span>Continue</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleFinish}
              className="flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white text-xs font-bold transition shadow-lg shadow-violet-900/50 cursor-pointer"
            >
              <span>Enter StudySphere (+150 XP)</span>
              <Sparkles className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
