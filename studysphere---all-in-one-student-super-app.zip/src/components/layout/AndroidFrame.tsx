import React from 'react';
import { Wifi, BatteryMedium, Signal } from 'lucide-react';

interface AndroidFrameProps {
  children: React.ReactNode;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-2 sm:p-6 overflow-hidden">
      {/* Device Body Container */}
      <div className="relative w-full max-w-[420px] h-[890px] max-h-[96vh] bg-slate-900 rounded-[48px] p-3 shadow-2xl border-4 border-slate-700/80 ring-1 ring-white/10 flex flex-col">
        {/* Outer Edge Antenna bands & buttons simulation */}
        <div className="absolute -left-[7px] top-28 w-[3px] h-12 bg-slate-600 rounded-l-md" />
        <div className="absolute -right-[7px] top-24 w-[3px] h-16 bg-slate-600 rounded-r-md" />
        <div className="absolute -right-[7px] top-44 w-[3px] h-10 bg-slate-600 rounded-r-md" />

        {/* Screen Bezel & Screen Area */}
        <div className="relative w-full h-full bg-slate-950 rounded-[40px] overflow-hidden flex flex-col border border-slate-800">
          {/* Android Status Bar */}
          <div className="h-9 w-full bg-slate-950/90 backdrop-blur-md px-6 flex items-center justify-between z-30 select-none text-slate-300 text-xs font-semibold shrink-0">
            {/* Clock */}
            <span>12:05</span>

            {/* Front Camera Punch-hole */}
            <div className="absolute left-1/2 -translate-x-1/2 top-2 w-4 h-4 rounded-full bg-black border border-slate-800 flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-slate-900" />
            </div>

            {/* Status Icons: 5G, Wifi, Battery */}
            <div className="flex items-center gap-1.5 text-slate-300">
              <Signal className="w-3.5 h-3.5" />
              <Wifi className="w-3.5 h-3.5" />
              <span className="text-[10px] text-emerald-400 font-mono">94%</span>
              <BatteryMedium className="w-4 h-4 text-emerald-400" />
            </div>
          </div>

          {/* Android App Content Area */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden relative flex flex-col bg-slate-950 text-slate-100">
            {children}
          </div>

          {/* Android Bottom Gesture Pill Bar */}
          <div className="h-6 w-full bg-slate-950 flex items-center justify-center shrink-0 z-30">
            <div className="w-32 h-1 bg-slate-600 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
};
