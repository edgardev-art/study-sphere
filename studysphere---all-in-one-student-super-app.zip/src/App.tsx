import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { BottomNav } from './components/layout/BottomNav';
import { AndroidFrame } from './components/layout/AndroidFrame';
import { GlobalSearchModal } from './components/layout/GlobalSearchModal';
import { NotificationsModal } from './components/layout/NotificationsModal';
import { AuthModal } from './components/auth/AuthModal';
import { OnboardingModal } from './components/auth/OnboardingModal';
import { LandingPage } from './components/landing/LandingPage';
import { StudentDashboard } from './components/dashboard/StudentDashboard';
import { AITutor } from './components/tutor/AITutor';
import { CourseCatalog } from './components/courses/CourseCatalog';
import { NotesManager } from './components/notes/NotesManager';
import { StudyPlanner } from './components/planner/StudyPlanner';
import { RevisionHub } from './components/revision/RevisionHub';
import { CommunityHub } from './components/community/CommunityHub';
import { StudyRooms } from './components/community/StudyRooms';
import { SubscriptionView } from './components/pricing/SubscriptionView';
import { ProfileSettings } from './components/profile/ProfileSettings';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { OfflineBanner } from './components/common/OfflineBanner';

const AppContent: React.FC = () => {
  const {
    isLandingPage,
    activeTab,
    viewMode,
  } = useApp();

  if (isLandingPage) {
    return (
      <>
        <LandingPage />
        <AuthModal />
        <OfflineBanner />
      </>
    );
  }

  // Active view router
  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <StudentDashboard />;
      case 'tutor':
        return <AITutor />;
      case 'courses':
        return <CourseCatalog />;
      case 'notes':
        return <NotesManager />;
      case 'planner':
        return <StudyPlanner />;
      case 'revision':
        return <RevisionHub />;
      case 'community':
        return <CommunityHub />;
      case 'study-rooms':
        return <StudyRooms />;
      case 'pricing':
        return <SubscriptionView />;
      case 'profile':
        return <ProfileSettings />;
      case 'admin':
        return <AdminDashboard />;
      default:
        return <StudentDashboard />;
    }
  };

  // Android View Mode: Render inside Android Smartphone Frame
  if (viewMode === 'android') {
    return (
      <AndroidFrame>
        <Header />
        <main className="flex-1 overflow-y-auto">
          {renderActiveView()}
        </main>
        <BottomNav />
        <GlobalSearchModal />
        <NotificationsModal />
        <AuthModal />
        <OnboardingModal />
        <OfflineBanner />
      </AndroidFrame>
    );
  }

  // Responsive Full-Screen SaaS View Mode
  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 font-sans selection:bg-violet-600 selection:text-white">
      <Header />

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar on desktop */}
        <div className="hidden md:flex">
          <Sidebar />
        </div>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto pb-16 md:pb-6">
          {renderActiveView()}
        </main>
      </div>

      {/* Bottom Navigation on mobile/tablet viewports */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-30">
        <BottomNav />
      </div>

      {/* Global Overlays & Modals */}
      <GlobalSearchModal />
      <NotificationsModal />
      <AuthModal />
      <OnboardingModal />
      <OfflineBanner />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
