import { jsPDF } from 'jspdf';

export interface NoteExportOptions {
  title: string;
  subject: string;
  content: string;
  summary?: string;
  authorName?: string;
  tags?: string[];
  createdAt?: string;
  scope: 'full' | 'summary_only' | 'content_only';
}

/**
 * Clean markdown symbols for plain text PDF rendering
 */
function cleanMarkdownForPdf(md: string): string[] {
  const lines = md.split('\n');
  const cleaned: string[] = [];

  for (const rawLine of lines) {
    let line = rawLine.trimEnd();

    // Check headings
    if (line.startsWith('# ')) {
      cleaned.push('');
      cleaned.push(`SECTION: ${line.replace(/^#+\s*/, '').toUpperCase()}`);
      cleaned.push('');
      continue;
    }
    if (line.startsWith('## ')) {
      cleaned.push('');
      cleaned.push(`• ${line.replace(/^#+\s*/, '')}`);
      continue;
    }
    if (line.startsWith('### ')) {
      cleaned.push(`  - ${line.replace(/^#+\s*/, '')}`);
      continue;
    }

    // Replace bold/italic markers
    line = line.replace(/\*\*(.*?)\*\*/g, '$1');
    line = line.replace(/\*(.*?)\*/g, '$1');
    line = line.replace(/__(.*?)__/g, '$1');
    line = line.replace(/_(.*?)_/g, '$1');
    line = line.replace(/`{1,3}(.*?)`{1,3}/g, '$1');

    cleaned.push(line);
  }

  return cleaned;
}

/**
 * Generate a beautifully styled, structured multi-page PDF document
 */
export function exportNoteToPdf(options: NoteExportOptions) {
  const {
    title,
    subject,
    content,
    summary,
    authorName = 'StudySphere Student',
    tags = [],
    createdAt = new Date().toISOString(),
    scope = 'full',
  } = options;

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const marginX = 20;
  const contentWidth = pageWidth - marginX * 2;
  let currentY = 22;

  const addHeaderAndFooter = (pageNum: number) => {
    // Header bar
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(140, 140, 150);
    doc.text('StudySphere Academic Ecosystem • Digital Learning Notebook', marginX, 12);
    doc.text(subject.toUpperCase(), pageWidth - marginX, 12, { align: 'right' });
    doc.setDrawColor(220, 225, 235);
    doc.setLineWidth(0.3);
    doc.line(marginX, 15, pageWidth - marginX, 15);

    // Footer
    doc.line(marginX, pageHeight - 15, pageWidth - marginX, pageHeight - 15);
    doc.text('Generated with StudySphere • AI Student Super App', marginX, pageHeight - 10);
    doc.text(`Page ${pageNum}`, pageWidth - marginX, pageHeight - 10, { align: 'right' });
  };

  const checkPageBreak = (neededHeight: number): boolean => {
    if (currentY + neededHeight > pageHeight - 22) {
      doc.addPage();
      currentY = 24;
      addHeaderAndFooter(doc.getNumberOfPages());
      return true;
    }
    return false;
  };

  // Setup first page header
  addHeaderAndFooter(1);

  // 1. Cover Brand Badge
  doc.setFillColor(99, 102, 241); // Indigo-500
  doc.roundedRect(marginX, currentY, 28, 6.5, 1.5, 1.5, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(255, 255, 255);
  doc.text('STUDYSPHERE', marginX + 3.5, currentY + 4.5);
  currentY += 11;

  // 2. Document Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(19);
  doc.setTextColor(15, 23, 42); // Slate-900
  const titleLines = doc.splitTextToSize(title, contentWidth);
  doc.text(titleLines, marginX, currentY);
  currentY += titleLines.length * 8;

  // 3. Metadata Box
  doc.setFillColor(248, 250, 252); // Slate-50
  doc.setDrawColor(226, 232, 240); // Slate-200
  doc.roundedRect(marginX, currentY, contentWidth, 14, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text('Subject:', marginX + 4, currentY + 5.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(99, 102, 241);
  doc.text(subject, marginX + 18, currentY + 5.5);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('Author:', marginX + 70, currentY + 5.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(authorName, marginX + 83, currentY + 5.5);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('Date:', marginX + 130, currentY + 5.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(createdAt.split('T')[0], marginX + 140, currentY + 5.5);

  if (tags.length > 0) {
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(71, 85, 105);
    doc.text('Tags:', marginX + 4, currentY + 10.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text(tags.map(t => `#${t}`).join('  '), marginX + 15, currentY + 10.5);
  }

  currentY += 20;

  // 4. AI-Generated Executive Summary Section (if scope allows)
  if ((scope === 'full' || scope === 'summary_only') && summary) {
    checkPageBreak(30);

    // Section title
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(79, 70, 229); // Violet-600
    doc.text('AI EXECUTIVE STUDY SUMMARY', marginX, currentY);
    currentY += 4;

    const summaryCleanLines = cleanMarkdownForPdf(summary);
    const summaryText = summaryCleanLines.join('\n');
    const splitSummary = doc.splitTextToSize(summaryText, contentWidth - 8);
    const summaryBoxHeight = splitSummary.length * 4.6 + 8;

    // Light purple background container
    doc.setFillColor(245, 243, 255); // Violet-50
    doc.setDrawColor(199, 210, 254); // Violet-200
    doc.roundedRect(marginX, currentY, contentWidth, summaryBoxHeight, 2, 2, 'FD');

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(30, 27, 75); // Dark Violet
    doc.text(splitSummary, marginX + 4, currentY + 6);

    currentY += summaryBoxHeight + 8;
  }

  // If summary_only scope, finish here
  if (scope === 'summary_only') {
    doc.save(`${title.replace(/\s+/g, '_')}_AI_Summary.pdf`);
    return;
  }

  // 5. Main Note Content Section
  checkPageBreak(20);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(15, 23, 42);
  doc.text('FULL STUDY NOTES & DETAILED ANALYSIS', marginX, currentY);
  currentY += 6;

  const cleanedLines = cleanMarkdownForPdf(content);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(51, 65, 85); // Slate-700

  for (const rawLine of cleanedLines) {
    if (rawLine === '') {
      currentY += 3;
      continue;
    }

    const isSectionHeader = rawLine.startsWith('SECTION:');
    const isSubHeader = rawLine.startsWith('• ');

    if (isSectionHeader) {
      checkPageBreak(12);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.setTextColor(15, 23, 42);
      doc.text(rawLine.replace('SECTION: ', ''), marginX, currentY);
      currentY += 6;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9.5);
      doc.setTextColor(51, 65, 85);
      continue;
    }

    if (isSubHeader) {
      checkPageBreak(8);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(67, 56, 202); // Indigo-700
      doc.text(rawLine, marginX, currentY);
      currentY += 5;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9.5);
      doc.setTextColor(51, 65, 85);
      continue;
    }

    const wrappedLines = doc.splitTextToSize(rawLine, contentWidth);
    for (const line of wrappedLines) {
      checkPageBreak(6);
      doc.text(line, marginX, currentY);
      currentY += 4.8;
    }
  }

  // Save PDF
  const filename = `${title.replace(/[^a-zA-Z0-9_-]/g, '_')}_StudySphere.pdf`;
  doc.save(filename);
}

/**
 * Generate a clean, well-formatted Markdown file download
 */
export function exportNoteToMarkdown(options: NoteExportOptions) {
  const {
    title,
    subject,
    content,
    summary,
    authorName = 'StudySphere Student',
    tags = [],
    createdAt = new Date().toISOString(),
    scope = 'full',
  } = options;

  let md = '';

  // Frontmatter
  md += `---\n`;
  md += `title: "${title}"\n`;
  md += `subject: "${subject}"\n`;
  md += `author: "${authorName}"\n`;
  md += `date: "${createdAt.split('T')[0]}"\n`;
  md += `tags: [${tags.map(t => `"${t}"`).join(', ')}]\n`;
  md += `generator: "StudySphere AI Student Super App"\n`;
  md += `---\n\n`;

  // Title
  md += `# ${title}\n\n`;
  md += `**Subject:** ${subject} | **Date:** ${createdAt.split('T')[0]}\n\n`;

  // AI Summary if available and within scope
  if ((scope === 'full' || scope === 'summary_only') && summary) {
    md += `## 🤖 AI Executive Study Summary\n\n`;
    md += `> ${summary.split('\n').join('\n> ')}\n\n`;
    md += `---\n\n`;
  }

  // Main Note Content
  if (scope !== 'summary_only') {
    md += `## Study Notes\n\n`;
    md += content;
    md += `\n\n---\n*Exported from StudySphere All-in-One Learning Ecosystem.*\n`;
  }

  const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  const suffix = scope === 'summary_only' ? '_AI_Summary' : '';
  link.download = `${title.replace(/[^a-zA-Z0-9_-]/g, '_')}${suffix}.md`;
  link.click();
  URL.revokeObjectURL(url);
}
