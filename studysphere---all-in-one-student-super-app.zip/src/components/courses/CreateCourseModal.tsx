import React, { useState } from 'react';
import { X, Plus, BookOpen } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { EducationLevel, Lesson } from '../../types';

export const CreateCourseModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { createCourse, user } = useApp();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [subject, setSubject] = useState(user?.subjects[0] || 'General Studies');
  const [level, setLevel] = useState<EducationLevel>(user?.educationLevel || 'undergraduate');
  const [instructor, setInstructor] = useState(user?.name || 'Educator');
  const [lessons, setLessons] = useState<Lesson[]>([
    {
      id: 'l1',
      title: 'Introduction & Core Foundations',
      durationMinutes: 20,
      objectives: ['Master fundamental definitions and terminology', 'Understand key historical and theoretical context'],
      content: '### Foundational Principles\nStart by establishing the core theoretical framework and mathematical or biochemical equations.',
      isCompleted: false,
    },
  ]);

  if (!isOpen) return null;

  const handleAddLesson = () => {
    setLessons([
      ...lessons,
      {
        id: 'l' + (lessons.length + 1),
        title: `Lesson ${lessons.length + 1}: Applied Deep Dive`,
        durationMinutes: 25,
        objectives: ['Explore real-world problem sets', 'Master exam deduction strategies'],
        content: '### Detailed Mechanics & Problem Sets\nStep-by-step analytical methods to evaluate complex scenarios.',
        isCompleted: false,
      },
    ]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    createCourse({
      title,
      description,
      subject,
      level,
      instructor,
      thumbnail: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=600&auto=format&fit=crop&q=80',
      lessons,
      isBookmarked: false,
      progressPercent: 0,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={onClose}>
      <div
        className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 shadow-2xl text-slate-100 flex flex-col max-h-[85vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-violet-400" />
            <h3 className="text-base font-bold text-white">Create Course Curriculum</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Course Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Organic Chemistry: Synthesis Mechanisms"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Subject</label>
              <input
                type="text"
                required
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g. Chemistry"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Instructor Name</label>
              <input
                type="text"
                required
                value={instructor}
                onChange={(e) => setInstructor(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Course Description & Overview</label>
            <textarea
              required
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Explain the objectives, prerequisite knowledge, and syllabus breakdown..."
              className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500"
            />
          </div>

          {/* Lessons Section */}
          <div className="pt-2 border-t border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">Course Lessons ({lessons.length})</span>
              <button
                type="button"
                onClick={handleAddLesson}
                className="flex items-center gap-1 text-xs text-violet-400 hover:text-violet-300 font-semibold cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Lesson</span>
              </button>
            </div>

            <div className="space-y-2">
              {lessons.map((l, index) => (
                <div key={l.id} className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-semibold text-white">{index + 1}. {l.title}</span>
                    <p className="text-[10px] text-slate-400">{l.durationMinutes} mins • {l.objectives.length} objectives</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs transition shadow-md shadow-violet-900/40 cursor-pointer mt-4"
          >
            Publish Course (+100 XP)
          </button>
        </form>
      </div>
    </div>
  );
};
