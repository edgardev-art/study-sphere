import React from 'react';
import {
  LayoutDashboard,
  Bot,
  BookOpen,
  FileText,
  CalendarCheck,
  Brain,
  Users,
  Video,
  CreditCard,
  Settings,
  ShieldAlert,
  Sparkles,
  LogOut,
  HelpCircle,
} from 'lucide-react';
import { useApp, ActiveTab } from '../../context/AppContext';

export const Sidebar: React.FC<{ isCollapsed?: boolean; onToggleCollapse?: () => void }> = () => {
  const { activeTab, setActiveTab, user, logout, setIsLandingPage } = useApp();

  const navItems: Array<{ id: ActiveTab; label: string; icon: React.FC<{ className?: string }>; badge?: string; badgeColor?: string }> = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'tutor', label: 'AI Tutor', icon: Bot, badge: 'Smart', badgeColor: 'bg-violet-500/20 text-violet-300' },
    { id: 'courses', label: 'Courses & LMS', icon: BookOpen },
    { id: 'notes', label: 'Digital Notes', icon: FileText },
    { id: 'planner', label: 'Study Planner', icon: CalendarCheck, badge: 'Pomodoro', badgeColor: 'bg-emerald-500/20 text-emerald-300' },
    { id: 'revision', label: 'Flashcards & Quizzes', icon: Brain },
    { id: 'community', label: 'Community', icon: Users },
    { id: 'study-rooms', label: 'Study Rooms', icon: Video, badge: 'Live', badgeColor: 'bg-rose-500/20 text-rose-300' },
    { id: 'pricing', label: 'Subscription', icon: CreditCard },
    { id: 'profile', label: 'Profile & Settings', icon: Settings },
  ];

  if (user?.role === 'admin') {
    navItems.push({
      id: 'admin',
      label: 'Admin Console',
      icon: ShieldAlert,
      badge: 'Admin',
      badgeColor: 'bg-amber-500/20 text-amber-300',
    });
  }

  return (
    <aside className="w-64 border-r border-slate-800 bg-slate-950/95 flex flex-col justify-between shrink-0 select-none py-4 px-3">
      {/* Navigation Links */}
      <div className="space-y-6">
        <div className="px-3">
          <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Main Menu</p>
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsLandingPage(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all group cursor-pointer ${
                  isActive
                    ? 'bg-violet-600/15 text-violet-300 border border-violet-500/30 shadow-sm shadow-violet-900/20 font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/70 border border-transparent'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 transition-colors ${isActive ? 'text-violet-400' : 'text-slate-400 group-hover:text-slate-300'}`} />
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-semibold ${item.badgeColor || 'bg-slate-800 text-slate-300'}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Promo & Account Card */}
      <div className="space-y-3 pt-4 border-t border-slate-800">
        {/* Pro Banner */}
        {user?.tier !== 'premium' && (
          <div className="p-3 rounded-2xl bg-gradient-to-br from-violet-900/40 via-indigo-950/60 to-slate-900 border border-violet-500/20 text-xs">
            <div className="flex items-center gap-1.5 text-violet-300 font-semibold mb-1">
              <Sparkles className="w-3.5 h-3.5 text-violet-400" />
              <span>Unlock Premium</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-2.5">
              Unlimited AI reasoning, mock exam predictor, and audio flashcards.
            </p>
            <button
              onClick={() => setActiveTab('pricing')}
              className="w-full py-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 text-white font-semibold text-[11px] transition"
            >
              Upgrade Plan
            </button>
          </div>
        )}

        {/* User Card */}
        {user && (
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-900/60 border border-slate-800">
            <div className="flex items-center gap-2.5 overflow-hidden">
              <img
                src={user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                alt={user.name}
                className="w-8 h-8 rounded-full border border-violet-500/30 object-cover shrink-0"
              />
              <div className="overflow-hidden">
                <p className="text-xs font-semibold text-white truncate">{user.name}</p>
                <p className="text-[10px] text-slate-400 capitalize truncate">{user.role} • {user.educationLevel.replace('_', ' ')}</p>
              </div>
            </div>

            <button
              onClick={logout}
              title="Sign Out"
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </aside>
  );
};
